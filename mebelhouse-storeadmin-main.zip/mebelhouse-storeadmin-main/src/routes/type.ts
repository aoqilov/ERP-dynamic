export type RoutesProps = {
  isAuth: boolean,
};
