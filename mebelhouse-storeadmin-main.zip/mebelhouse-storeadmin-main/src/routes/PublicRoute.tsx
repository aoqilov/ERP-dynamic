import { Navigate, Outlet } from 'react-router-dom';
import { RoutesProps } from './type';
import { ROUTES } from '@/constants';
import { SuspenseWrapper } from './SuspenseWrapper';

export const PublicRoute = ({ isAuth }: RoutesProps) => {
  if (isAuth) {
    <Navigate to={ROUTES.home} />;
  }

  return (
    <SuspenseWrapper>
      <Outlet />
    </SuspenseWrapper>
  );
};
