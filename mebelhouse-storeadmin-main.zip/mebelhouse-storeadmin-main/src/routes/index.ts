export { Routes } from './config-routes';
