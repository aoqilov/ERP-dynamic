import { DefaultLayout } from '@/components/pages/layout';
import { ROUTES } from '@/constants';
import { Navigate, Outlet } from 'react-router-dom';
import { SuspenseWrapper } from './SuspenseWrapper';
import { RoutesProps } from './type';

export const ProtectedRoute = ({ isAuth }: RoutesProps) => {
  if (!isAuth) {
    return <Navigate to={ROUTES.login} />;
  }

  return (
    <DefaultLayout>
      <SuspenseWrapper>
        <Outlet />
      </SuspenseWrapper>
    </DefaultLayout>
  );
};
