import { Spin } from 'antd';
import { FC, PropsWithChildren, Suspense } from 'react';

export const SuspenseWrapper: FC<PropsWithChildren> = ({ children }) => (
  <Suspense fallback={<Spin />}>{children}</Suspense>
);
