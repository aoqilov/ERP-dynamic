import Dev from '@/components/pages/dev/Dev';
import InventoryPage from '@/components/pages/inventory';
import NotFound from '@/components/pages/not-found/NotFound';
import { ReturnPage } from '@/components/pages/return';
import { SalesPage } from '@/components/pages/sales';
import ShowroomProdLogPage from '@/components/pages/showroom-product-log';
import { ROUTES } from '@/constants';
import { useConnection } from '@/lib/hooks/useConnection';
import { Employees } from '@/pages/employees-page';
import { HomePage } from '@/pages/home-page';
import { LoginPage } from '@/pages/login-page';
import { Products } from '@/pages/products-page';
import { Transfer } from '@/pages/transfer-page';
import { useAppSelector } from '@/store/reduxHooks';
import { useGetAllEmployeesQuery } from '@/store/services/employees/employees.api';
import { Roles } from '@/store/services/employees/employees.type';
import { message } from 'antd';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation, useRoutes } from 'react-router-dom';
import { ProtectedRoute } from './ProtectedRoute';
import { PublicRoute } from './PublicRoute';
import ClientsPage from '@/pages/clients-page';
// import { Return } from '@/pages/return-page';
// import { Sales } from '@/components/pages/sales';
// import InvoicesPage from '@/pages/Invoices/Invoices.tsx';

export const Routes = () => {
  const { token } = useAppSelector((state) => state.auth);
  const [isAuth, setIsAuth] = useState(Boolean(token));
  const { t } = useTranslation();
  const [hasShownError, setHasShownError] = useState(false);
  const { data, error, isLoading, refetch } = useGetAllEmployeesQuery({
    token,
    page: 1,
    page_size: 1,
    role: Roles.cashier,
  });
  const [hasHandledError, setHasHandledError] = useState(false);
  // const navigate = useNavigate();
  const location = useLocation();
  const isOnline = useConnection();

  useEffect(() => {
    setIsAuth(Boolean(token));
  }, [token]);

  useEffect(() => {
    if (!isOnline) {
      setHasShownError(true);
      message.error(t('Common.ConnectionError'));
    }
  }, [hasShownError, error]);

  //To navigate user to the login page, when token expired...
  useEffect(() => {
    if (isLoading) return; // Wait until loading is complete

    if (!isOnline) {
      return;
    }

    if (error || data === undefined || data?.status_code !== 200) {
      // if (!hasHandledError) {
      // Handle the error only once
      setIsAuth(false);
      setHasHandledError(true);
      // navigate(ROUTES.login);
      // }
    } else {
      // If data is valid, reset error handling
      setIsAuth(true);
      setHasHandledError(false);
    }
  }, [data, error, isLoading, token, location.pathname, hasHandledError]);

  // Trigger refetch only when pathname changes
  useEffect(() => {
    refetch();
    setHasShownError(false);
  }, [location.pathname, refetch]);

  return useRoutes([
    {
      path: ROUTES.login,
      element: <PublicRoute isAuth={isAuth} />,
      children: [
        {
          path: ROUTES.login,
          element: <LoginPage />,
        },
      ],
    },
    {
      path: ROUTES.home,
      element: <ProtectedRoute isAuth={isAuth} />,
      children: [
        {
          path: ROUTES.home,
          element: <HomePage />,
        },
        {
          path: ROUTES.employees,
          element: <Employees />,
        },
        {
          path: '/warehouse',
          element: <Products />,
        },
        {
          path: '/invoices',
          element: <Dev />,
        },
        {
          path: '/order',
          element: <SalesPage />,
        },
        {
          path: '/discounts',
          element: <Dev />,
        },
        {
          path: '/inventory',
          element: <InventoryPage />,
        },
        {
          path: '/showroom-prod-log',
          element: <ShowroomProdLogPage />,
        },
        {
          path: '/clients',
          element: <ClientsPage />,
        },

        {
          path: '/return-order',
          element: <ReturnPage />,
        },
        {
          path: '/transactions',
          children: [
            {
              path: 'pending',
              element: <Transfer />,
            },
            {
              path: 'accepted',
              element: <Transfer />,
            },
            {
              path: 'rejected',
              element: <Transfer />,
            },
          ],
        },
      ],
    },
    {
      path: '*',
      element: <NotFound />,
    },
  ]);
};
