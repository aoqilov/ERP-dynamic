import { lazy } from 'react';

export const Employees = lazy(() => import('./EmployeesPage'));
