import EmployeesIndex from '@/components/pages/employees/EmployeesIndex';

const EmployeesPage = () => {
  return <EmployeesIndex />;
};

export default EmployeesPage;
