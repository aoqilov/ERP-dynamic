import ProductsIndex from '@/components/pages/products/ProductsIndex';

const ProductsPage = () => {
  return <ProductsIndex />;
};

export default ProductsPage;
