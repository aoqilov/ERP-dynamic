import { lazy } from 'react';

export const Products = lazy(() => import('./ProductsPage'));
