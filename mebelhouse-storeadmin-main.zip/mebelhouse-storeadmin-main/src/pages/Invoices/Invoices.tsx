import { Invoices } from '@/components/pages/Invoices';

const InvoicesPage = () => {
  return <Invoices />
}

export default InvoicesPage
