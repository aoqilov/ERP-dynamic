import { lazy } from 'react';

export const Invoices = () => lazy(()=> import('./Invoices'))
