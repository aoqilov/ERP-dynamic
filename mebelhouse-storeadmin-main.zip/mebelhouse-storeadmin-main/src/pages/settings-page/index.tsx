import SettingsIndex from '@/components/pages/settings/SettingsIndex';

const SettingsPage = () => {
  return <SettingsIndex />;
};

export default SettingsPage;
