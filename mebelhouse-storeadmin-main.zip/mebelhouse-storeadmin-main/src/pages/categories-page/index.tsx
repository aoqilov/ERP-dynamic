import CategoriesIndex from '@/components/pages/category/CategoriesIndex';

const CategoriesPage = () => {
  return <CategoriesIndex />;
};

export default CategoriesPage;
