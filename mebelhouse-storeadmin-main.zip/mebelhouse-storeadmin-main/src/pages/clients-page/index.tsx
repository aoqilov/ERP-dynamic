import ClientsIndex from '@/components/pages/clients/ClientsIndex';

const ClientsPage = () => {
  return <ClientsIndex />;
};

export default ClientsPage;
