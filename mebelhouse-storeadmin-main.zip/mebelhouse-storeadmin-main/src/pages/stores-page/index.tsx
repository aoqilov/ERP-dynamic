import StoresIndex from '@/components/pages/stores/StoresIndex/StoresIndex';

const StoresPage = () => {
  return <StoresIndex />;
};

export default StoresPage;
