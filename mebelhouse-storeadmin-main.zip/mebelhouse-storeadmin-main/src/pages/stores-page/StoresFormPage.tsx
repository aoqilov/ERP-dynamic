import StoresFormIndex from '@/components/pages/stores/StoresForm/StoresFormIndex';

const StoresFormPage = () => {
  return <StoresFormIndex />;
};

export default StoresFormPage;
