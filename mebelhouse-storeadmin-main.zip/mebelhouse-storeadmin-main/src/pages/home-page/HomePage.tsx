import { Home } from '@/components/pages/home';
import { FC } from 'react';

const HomePage: FC = () => {
  return <Home />;
};

HomePage.displayName = 'HomePage';
export default HomePage;
