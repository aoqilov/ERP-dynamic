import { lazy } from "react";

export const Transfer = lazy(() => import('./TransferPage'))