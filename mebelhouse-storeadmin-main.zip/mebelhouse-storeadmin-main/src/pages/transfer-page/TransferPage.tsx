import Transfer from '@/components/pages/transfer/Transfer';

const TransferPage = () => {
  return <Transfer />;
};

export default TransferPage;
