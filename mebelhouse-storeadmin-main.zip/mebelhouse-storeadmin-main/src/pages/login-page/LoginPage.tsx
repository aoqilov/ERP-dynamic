import Login from '@/components/pages/login/Login';

const LoginPage = () => {
  return <Login />;
};

LoginPage.displayName = 'LoginPage';
export default LoginPage;
