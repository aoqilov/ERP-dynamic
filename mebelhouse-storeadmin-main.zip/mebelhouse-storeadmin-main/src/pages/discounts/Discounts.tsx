import Discounts from '@/components/pages/discounts/Discounts';

const DiscountsPage = () => {
  return <Discounts />;
};

export default DiscountsPage;
