import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { SERVER_URL } from '@/lib/consts/url.consts';
import { createUrl } from '@/lib/utils/formatters/formatter-url/url-builder';
import { createInvalidatesTags, getHeaderAuthorization } from '../api.helpers';
import { TGetAllSalesParam, TGetAllSalesResponse } from './sales.type';

// consts
const BASE_URL = SERVER_URL;
const REDUCER_PATH = 'salesApi';
const BASE_PATH = '/sales';
const ROOT_TAG_TYPE = 'salesLogs' as const;
const TAG_TYPES = [ROOT_TAG_TYPE] as const;

const invalidatesTags = createInvalidatesTags(TAG_TYPES);

const rootUrl = createUrl({
  baseUrl: BASE_URL,
  basePath: ['showroom', BASE_PATH],
});

export const salesApi = createApi({
  reducerPath: REDUCER_PATH,
  tagTypes: TAG_TYPES,
  baseQuery: fetchBaseQuery({ baseUrl: rootUrl().origin }),
  endpoints: (builder) => ({
    getAllProductsSales: builder.query<
      TGetAllSalesResponse,
      TGetAllSalesParam & { sets?: boolean }
    >({
      query: ({ token, pagination = false, sets = false, ...queryParams }) => ({
        url: rootUrl({
          queryParams,
          endpoints: [sets ? 'sets' : '', pagination ? 'pagination' : ''],
        }).path,
        headers: getHeaderAuthorization(token!),
      }),
      providesTags: (result) =>
        result
          ? [
              ...(result?.data || []).map(({ id }) => ({
                type: ROOT_TAG_TYPE,
                id,
              })),
              ...invalidatesTags.salesLogs,
            ]
          : invalidatesTags.salesLogs,
      transformResponse(baseQueryReturnValue: TGetAllSalesResponse) {
        return Array.isArray(baseQueryReturnValue?.data)
          ? baseQueryReturnValue
          : { ...baseQueryReturnValue, data: [] };
      },
    }),
    getAllSalesDownload: builder.query<BlobPart, TGetAllSalesParam & { sets?: boolean }>({
      query: ({ token, sets = false, ...queryParams }) => ({
        url: rootUrl({
          queryParams,
          endpoints: [sets ? 'sets/download' : 'download'],
        }).path,
        headers: getHeaderAuthorization(token!),
        responseHandler: (response) => response.blob(),
      }),
    }),
  }),
});

export const { useGetAllProductsSalesQuery, useLazyGetAllSalesDownloadQuery } = salesApi;
