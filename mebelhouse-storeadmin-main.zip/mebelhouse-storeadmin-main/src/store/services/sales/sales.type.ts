import { TBaseRequestParams, TModifiedProduct } from '@/lib/types/common.type';
import { Expand } from '@/lib/types/custom-utility.type';
import { TPaginatedResponse } from '@/lib/types/formatted.types';

export type TSalesQuantityType = {
  color_uz: string;
  color_ru: string;
  quantity: number;
};

export type TProductSalesItem = Omit<
  TModifiedProduct,
  'name_ru' | 'name_uz' | 'quantities' | 'sub_category_name_uz' | 'sub_category_name_ru'
> & {
  product_name_ru: string;
  product_name_uz: string;
  subcategory_name_ru: string;
  quantities: TSalesQuantityType[];
};

export type TSalesLocation = {
  location_name: string;
  products: TProductSalesItem[];
};

export type TSalesItem = {
  id: string;
  order_number: string;
  sold_time: string;
  total_price: string;
  set?: {
    id: string;
    name: string;
  };
  locations: TSalesLocation[];
};

// data list
export type TSalesList = TSalesItem[];

// HTTPS 🚀

// GetAll 🔵
export type TGetAllSalesResponse = TPaginatedResponse<TSalesList>;
export type TGetAllSalesParam = Expand<
  Partial<
    Pick<
      TBaseRequestParams,
      'page_size' | 'page' | 'search' | 'created_at_from' | 'created_at_to' | 'token' | 'pagination'
    >
  >
>;
