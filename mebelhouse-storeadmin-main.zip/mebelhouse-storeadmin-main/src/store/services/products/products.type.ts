import { TBaseApiResponseData } from '@/lib/types/base-response.type';
import { TBaseRequestParams } from '@/lib/types/common.type';
import { Expand } from '@/lib/types/custom-utility.type';
import { TBaseResponseData, TPaginatedResponse } from '@/lib/types/formatted.types';
import { ProductKeysBaseType } from '../product-lists/product-lists.type';
import { TCategoriesItem } from '../categories/categories.type';
import { TSubCategoriesItem } from '../sub-categories/sub-categories.type';
import { PictureItemType } from '@/lib/types/files.type';

export type TProductsLangFields = ['name', 'description'];
// type TMultiLangKeys = CombineLangSuffixFields<TProductsLangFields, LangEnum>;

export type TColorsType = {
  color_id: number;
  color_name: string;
  quantity: number;
};

export type TQuantities = {
  product_id: string;
  color_id: string;
  color_name_ru: string;
  color_name_uz: string;
  color_code: string | null;
  quantity: string;
  marga: string;
  origin_price: string;
  sale_price: string;
  discount: boolean;
  discount_price: string;
};

// data item
export type TProductsItem = Expand<
  TBaseApiResponseData & {
    barcode: string;
    cost_price: string;
    sale_price: string;
    origin_price: string;
    name_uz: string;
    name_ru: string;
    description_uz: string;
    description_ru: string;
    bar_code: string;
    quantity: number;
    marga: number;
    nds: number;
    total_quantity: string;
    discount_price: string;
    category: TCategoriesItem;
    sub_category: TSubCategoriesItem;
    colours: ProductKeysBaseType[];
    brand: ProductKeysBaseType;
    country: ProductKeysBaseType;
    images: PictureItemType[];
    quantities: TQuantities[];
  }
>;

// data listg
export type TProductsList = TProductsItem[];

// HTTPS 🚀

// GetAll 🔵
export type TGetAllProductsResponse = TPaginatedResponse<TProductsList>;
export type TGetAllProductsParam = Partial<
  Pick<
    TBaseRequestParams,
    'page_size' | 'page' | 'category_id' | 'sub_category_id' | 'search' | 'colors'
  >
> & {
  token: string;
};

// GetOne 🔵
export type TGetOneProductsResponse = TBaseResponseData<TProductsItem>;
export type TGetOneProductsParam = Pick<TBaseRequestParams, 'token' | 'id'>;

// Create 🟢
export type TCreateProductsResponse = TBaseResponseData<TProductsItem>;
export type TCreateProductsBody = Omit<TProductsItem, 'key' | 'id' | 'subcategory' | 'pictures'> & {
  subcategory: number;
  pictures: number[];
};
export type TCreateProductsForm = TCreateProductsBody;
export type TCreateProductsParam = Pick<TBaseRequestParams<TCreateProductsBody>, 'token' | 'body'>;

// Update 🟡
export type TUpdateProductsResponse = TBaseResponseData<TProductsItem>;
export type TUpdateProductsBody = Omit<TProductsItem, 'key' | 'id' | 'subcategory' | 'pictures'> & {
  subcategory: number;
  pictures: number[];
};
export type TUpdateProductsForm = TUpdateProductsBody;
export type TUpdateProductsParam = Pick<
  TBaseRequestParams<TUpdateProductsBody>,
  'token' | 'body' | 'id'
>;

// Delete 🔴
export type TDeleteProductsResponse = TBaseResponseData<TProductsItem>;
export type TDeleteProductsParam = Pick<TBaseRequestParams, 'token' | 'id'>;

// Multi Delete 🔴
export type TDeleteMultiProductsResponse = TBaseResponseData<TProductsItem>;
export type TDeleteMultiProductsParam = Pick<
  TBaseRequestParams<{ products: number[] }>,
  'token' | 'body'
>;

//Income

export type TProductIncomeItem = Partial<
  Pick<TProductsItem, 'cost_price' | 'marga' | 'sale_price' | 'quantity'> & {
    product_list: number;
    colors: { id: number; quantity: number }[];
  }
>;

export type TProductIncomeItemList = TProductIncomeItem[];
