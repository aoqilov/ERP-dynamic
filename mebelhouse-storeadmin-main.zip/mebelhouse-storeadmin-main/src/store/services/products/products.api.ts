import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { SERVER_URL } from '@/lib/consts/url.consts';
import { createUrl } from '@/lib/utils/formatters/formatter-url/url-builder';
import { getHeaderAuthorization } from '../api.helpers';
import {
  TCreateProductsParam,
  TCreateProductsResponse,
  TDeleteMultiProductsParam,
  TDeleteMultiProductsResponse,
  TDeleteProductsParam,
  TDeleteProductsResponse,
  TGetAllProductsParam,
  TGetAllProductsResponse,
  TGetOneProductsParam,
  TGetOneProductsResponse,
  TUpdateProductsParam,
  TUpdateProductsResponse,
} from './products.type';

// consts
const BASE_URL = SERVER_URL;
const REDUCER_PATH = 'productsApi';
const BASE_PATH = '/showroom/product';
const ROOT_TAG_TYPE = 'showroom/product' as const;
const TAG_TYPES = [ROOT_TAG_TYPE] as const;
const rootInvalidateTag = [{ type: ROOT_TAG_TYPE, id: 'LIST' }];

// const invalidatesTags = createInvalidatesTags(TAG_TYPES);

const rootUrl = createUrl({
  baseUrl: BASE_URL,
});

export const productsApi = createApi({
  reducerPath: REDUCER_PATH,
  tagTypes: TAG_TYPES,
  baseQuery: fetchBaseQuery({ baseUrl: rootUrl().origin }),
  endpoints: (builder) => ({
    getAllProducts: builder.query<TGetAllProductsResponse, TGetAllProductsParam>({
      query: ({ token, ...queryParams }) => ({
        url: rootUrl({
          endpoints: [BASE_PATH],
          queryParams,
        }).path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result) =>
        result
          ? [
              ...(result?.data || []).map(({ id }) => ({
                type: ROOT_TAG_TYPE,
                id,
              })),
              ...rootInvalidateTag,
            ]
          : rootInvalidateTag,
    }),
    getOneProducts: builder.query<TGetOneProductsResponse, TGetOneProductsParam>({
      query: ({ token, id }) => ({
        url: rootUrl({ endpoints: [BASE_PATH, id] }).path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result, _, { id }) => [
        { type: ROOT_TAG_TYPE, id },
        ...(result ? rootInvalidateTag : []),
      ],
    }),
    createIncomeProducts: builder.mutation<TCreateProductsResponse, TCreateProductsParam>({
      query: ({ body, token }) => ({
        url: rootUrl({ endpoints: [BASE_PATH] }).path,
        method: 'POST',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: rootInvalidateTag,
    }),
    transferProducts: builder.mutation<TCreateProductsResponse, TCreateProductsParam>({
      query: ({ body, token }) => ({
        url: rootUrl({ endpoints: [BASE_PATH] }).path,
        method: 'POST',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: rootInvalidateTag,
    }),
    updateProducts: builder.mutation<TUpdateProductsResponse, TUpdateProductsParam>({
      query: ({ token, body, id }) => ({
        url: rootUrl({ endpoints: [BASE_PATH, id] }).path,
        method: 'PATCH',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: rootInvalidateTag,
    }),
    deleteProducts: builder.mutation<TDeleteProductsResponse, TDeleteProductsParam>({
      query: ({ id, token }) => ({
        url: rootUrl({ endpoints: [BASE_PATH, id] }).path,
        method: 'DELETE',
        headers: getHeaderAuthorization(token),
      }),
      invalidatesTags: rootInvalidateTag,
    }),
    deleteMultiProducts: builder.mutation<TDeleteMultiProductsResponse, TDeleteMultiProductsParam>({
      query: ({ body, token }) => ({
        url: rootUrl({ endpoints: ['multiple-delete', BASE_PATH] }).path,
        method: 'POST',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: rootInvalidateTag,
    }),
  }),
});

export const {
  useGetAllProductsQuery,
  useGetOneProductsQuery,
  useCreateIncomeProductsMutation,
  useUpdateProductsMutation,
  useDeleteProductsMutation,
  useDeleteMultiProductsMutation,
} = productsApi;
