import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { SERVER_URL } from '@/lib/consts/url.consts';
import { createUrl } from '@/lib/utils/formatters/formatter-url/url-builder';
import { createInvalidatesTags, getHeaderAuthorization } from '../api.helpers';
import {
  TCreateExampleParam,
  TCreateExampleResponse,
  TDeleteExampleParam,
  TDeleteExampleResponse,
  TGetAllExampleParam,
  TGetAllExampleResponse,
  TGetOneExampleParam,
  TGetOneExampleResponse,
  TUpdateExampleParam,
  TUpdateExampleResponse,
} from './ex.type';

// consts
const BASE_URL = SERVER_URL;
const REDUCER_PATH = 'exampleApi';
const BASE_PATH = '/example';
const ROOT_TAG_TYPE = 'example' as const;
const TAG_TYPES = [ROOT_TAG_TYPE] as const;

const invalidatesTags = createInvalidatesTags(TAG_TYPES);

const rootUrl = createUrl({
  baseUrl: BASE_URL,
  basePath: [BASE_PATH],
});

export const exampleApi = createApi({
  reducerPath: REDUCER_PATH,
  tagTypes: TAG_TYPES,
  baseQuery: fetchBaseQuery({ baseUrl: rootUrl().origin }),
  endpoints: (builder) => ({
    getAllExample: builder.query<TGetAllExampleResponse, TGetAllExampleParam>({
      query: ({ token }) => ({
        url: rootUrl().path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result) =>
        result
          ? [
              ...(result?.data || []).map(({ id }) => ({
                type: ROOT_TAG_TYPE,
                id,
              })),
              ...invalidatesTags.example,
            ]
          : invalidatesTags.example,
    }),
    getOneExample: builder.query<TGetOneExampleResponse, TGetOneExampleParam>({
      query: ({ token, id }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result, _, { id }) => [
        { type: ROOT_TAG_TYPE, id },
        ...(result ? invalidatesTags.example : []),
      ],
    }),
    createExample: builder.mutation<TCreateExampleResponse, TCreateExampleParam>({
      query: ({ body, token }) => ({
        url: rootUrl().path,
        method: 'POST',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: invalidatesTags.example,
    }),
    updateExample: builder.mutation<TUpdateExampleResponse, TUpdateExampleParam>({
      query: ({ token, body, id }) => ({
        url: rootUrl({ endpoints: [id]}).path,
        method: 'PATCH',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: invalidatesTags.example,
    }),
    deleteExample: builder.mutation<TDeleteExampleResponse, TDeleteExampleParam>({
      query: ({ id, token }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        method: 'DELETE',
        headers: getHeaderAuthorization(token),
      }),
      invalidatesTags: invalidatesTags.example,
    }),
  }),
});

export const {
  useGetAllExampleQuery,
  useGetOneExampleQuery,
  useCreateExampleMutation,
  useUpdateExampleMutation,
  useDeleteExampleMutation,
} = exampleApi;
