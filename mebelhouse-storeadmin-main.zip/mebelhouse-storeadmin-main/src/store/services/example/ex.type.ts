import { TBaseApiResponseData } from '@/lib/types/base-response.type';
import { TBaseRequestParams } from '@/lib/types/common.type';
import { CombineLangSuffixFields, Expand } from '@/lib/types/custom-utility.type';
import { TBaseResponseData } from '@/lib/types/formatted.types';
import { LangEnum } from '@/lib/types/lang.type';

export type TExampleLangFields = ['name', 'title'];

// data item
export type TExampleItem = Expand<
  TBaseApiResponseData & {
    name: string;
  } & CombineLangSuffixFields<TExampleLangFields, LangEnum>
>;

// data list
export type TExampleList = TExampleItem[];

// HTTPS 🚀

// GetAll 🔵
export type TGetAllExampleResponse = TBaseResponseData<TExampleList>;
export type TGetAllExampleParam = Pick<TBaseRequestParams, 'token'>;

// GetOne 🔵
export type TGetOneExampleResponse = TBaseResponseData<TExampleItem>;
export type TGetOneExampleParam = Pick<TBaseRequestParams, 'token' | 'id'>;

// Create 🟢
export type TCreateExampleResponse = TBaseResponseData<TExampleItem>;
export type TCreateExampleBody = never;
export type TCreateExampleForm = TCreateExampleBody;
export type TCreateExampleParam = Pick<TBaseRequestParams<TCreateExampleBody>, 'token' | 'body'>;

// Update 🟡
export type TUpdateExampleResponse = TBaseResponseData<TExampleItem>;
export type TUpdateExampleBody = never;
export type TUpdateExampleForm = TUpdateExampleBody;
export type TUpdateExampleParam = Pick<
  TBaseRequestParams<TUpdateExampleBody>,
  'token' | 'body' | 'id'
>;

// Delete 🔴
export type TDeleteExampleResponse = TBaseResponseData<TExampleItem>;
export type TDeleteExampleParam = Pick<TBaseRequestParams, 'token' | 'id'>;
