import { TBaseRequestParams, TModifiedProduct } from '@/lib/types/common.type';
import { Expand } from '@/lib/types/custom-utility.type';
import { TPaginatedResponse } from '@/lib/types/formatted.types';

export type TShowroomProductItem = Omit<TModifiedProduct, 'quantities'> & {
  quantity: number;
};

export type TShowroomProdLogItem = {
  id: string;
  created_at: string;
  order_check_number: string;
  total_quantity: number;
  products: TShowroomProductItem[];
};

// data list
export type TShowroomProdLogList = TShowroomProdLogItem[];

// HTTPS 🚀

// GetAll 🔵
export type TGetAllShowroomProdLogResponse = TPaginatedResponse<TShowroomProdLogList>;
export type TGetAllShowroomProdLogParam = Expand<
  Partial<
    Pick<
      TBaseRequestParams,
      'page_size' | 'page' | 'search' | 'created_at_from' | 'created_at_to' | 'token'
    >
  >
>;
