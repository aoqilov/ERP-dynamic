import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { SERVER_URL } from '@/lib/consts/url.consts';
import { createUrl } from '@/lib/utils/formatters/formatter-url/url-builder';
import { createInvalidatesTags, getHeaderAuthorization } from '../api.helpers';
import {
  TGetAllShowroomProdLogParam,
  TGetAllShowroomProdLogResponse,
} from './showroom-prod-log.type';

// consts
const BASE_URL = SERVER_URL;
const REDUCER_PATH = 'showroomProdLog';
const BASE_PATH = '/product-logs';
const ROOT_TAG_TYPE = 'showroomProdLog' as const;
const TAG_TYPES = [ROOT_TAG_TYPE] as const;

const invalidatesTags = createInvalidatesTags(TAG_TYPES);

const rootUrl = createUrl({
  baseUrl: BASE_URL,
  basePath: ['showroom', BASE_PATH],
});

export const showroomProdLogApi = createApi({
  reducerPath: REDUCER_PATH,
  tagTypes: TAG_TYPES,
  baseQuery: fetchBaseQuery({ baseUrl: rootUrl().origin }),
  endpoints: (builder) => ({
    getAllShowroomProdLog: builder.query<
      TGetAllShowroomProdLogResponse,
      TGetAllShowroomProdLogParam
    >({
      query: ({ token, ...queryParams }) => ({
        url: rootUrl({ queryParams, }).path,
        headers: getHeaderAuthorization(token!),
      }),
      providesTags: (result) =>
        result
          ? [
              ...(result?.data || []).map(({ id }) => ({
                type: ROOT_TAG_TYPE,
                id,
              })),
              ...invalidatesTags.showroomProdLog,
            ]
          : invalidatesTags.showroomProdLog,
      transformResponse(baseQueryReturnValue: TGetAllShowroomProdLogResponse) {
        return Array.isArray(baseQueryReturnValue?.data)
          ? baseQueryReturnValue
          : { ...baseQueryReturnValue, data: [] };
      },
    }),
  }),
});

export const { useGetAllShowroomProdLogQuery } = showroomProdLogApi;
