import { TBaseApiResponseData } from '@/lib/types/base-response.type';
import { TBaseRequestParams } from '@/lib/types/common.type';
import { CombineLangSuffixFields, Expand } from '@/lib/types/custom-utility.type';
import { TBaseResponseData, TPaginatedResponse } from '@/lib/types/formatted.types';
import { LangEnum } from '@/lib/types/lang.type';
import { TSubCategoriesItem } from '../sub-categories/sub-categories.type';
import { PictureItemType } from '@/lib/types/files.type';
import { TCategoriesItem } from '../categories/categories.type';

export type TProductListsLangFields = ['name', 'description'];
type TMultiLangKeys = CombineLangSuffixFields<TProductListsLangFields, LangEnum>;

export type ProductKeysBaseType = {
  id: number;
  name_ru: string;
  name_uz: string;
  name: string;
  code: string | null;
};

// data item
export type TProductListsItem = Expand<
  TBaseApiResponseData & {
    barcode: string;
    cost_price: string;
    sale_price: string;
    name_uz: string;
    name_ru: string;
    description_uz: string;
    description_ru: string;
    bar_code: string;
    quantity: number;
    marga: number;
    nds: number;
    total_quantity: string;
    discount_price: string;
    category: TCategoriesItem;
    sub_category: TSubCategoriesItem;
    colours: ProductKeysBaseType[];
    brand: ProductKeysBaseType;
    country: ProductKeysBaseType;
    images: PictureItemType[];
  } & TMultiLangKeys
>;

// data list
export type TProductListsList = TProductListsItem[];

// HTTPS 🚀

// GetAll 🔵
export type TGetAllProductListsResponse = TPaginatedResponse<TProductListsList>;
export type TGetAllProductListsParam = Partial<
  Pick<TBaseRequestParams, 'page_size' | 'page' | 'category_id' | 'sub_category_id' | 'search'>
> & {
  token: string;
};

// GetOne 🔵
export type TGetOneProductListsResponse = TBaseResponseData<TProductListsItem>;
export type TGetOneProductListsParam = Pick<TBaseRequestParams, 'token' | 'id'>;

// Create 🟢
export type TCreateProductListsResponse = TBaseResponseData<TProductListsItem>;
export type TCreateProductListsBody = Omit<
  TProductListsItem,
  'key' | 'id' | 'subcategory' | 'pictures'
> & {
  subcategory: number;
  pictures: number[];
};
export type TCreateProductListsForm = TCreateProductListsBody;
export type TCreateProductListsParam = Pick<
  TBaseRequestParams<TCreateProductListsBody>,
  'token' | 'body'
>;

// Update 🟡
export type TUpdateProductListsResponse = TBaseResponseData<TProductListsItem>;
export type TUpdateProductListsBody = Omit<
  TProductListsItem,
  'key' | 'id' | 'subcategory' | 'pictures'
> & {
  subcategory: number;
  pictures: number[];
};
export type TUpdateProductListsForm = TUpdateProductListsBody;
export type TUpdateProductListsParam = Pick<
  TBaseRequestParams<TUpdateProductListsBody>,
  'token' | 'body' | 'id'
>;

// Delete 🔴
export type TDeleteProductListsResponse = TBaseResponseData<TProductListsItem>;
export type TDeleteProductListsParam = Pick<TBaseRequestParams, 'token' | 'id'>;

// Multi Delete 🔴
export type TDeleteMultiProductListsResponse = TBaseResponseData<TProductListsItem>;
export type TDeleteMultiProductListsParam = Pick<
  TBaseRequestParams<{ products: number[] }>,
  'token' | 'body'
>;
