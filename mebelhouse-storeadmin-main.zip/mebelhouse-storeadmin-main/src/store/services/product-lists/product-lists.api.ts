import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { SERVER_URL } from '@/lib/consts/url.consts';
import { createUrl } from '@/lib/utils/formatters/formatter-url/url-builder';
import { getHeaderAuthorization } from '../api.helpers';
import {
  TCreateProductListsParam,
  TCreateProductListsResponse,
  TDeleteMultiProductListsParam,
  TDeleteMultiProductListsResponse,
  TDeleteProductListsParam,
  TDeleteProductListsResponse,
  TGetAllProductListsParam,
  TGetAllProductListsResponse,
  TGetOneProductListsParam,
  TGetOneProductListsResponse,
  TUpdateProductListsParam,
  TUpdateProductListsResponse,
} from './product-lists.type';

// consts
const BASE_URL = SERVER_URL;
const REDUCER_PATH = 'productListsApi';
const BASE_PATH = '/showroom/product';
const ROOT_TAG_TYPE = 'productLists' as const;
const TAG_TYPES = [ROOT_TAG_TYPE] as const;
const rootInvalidateTag = [{ type: ROOT_TAG_TYPE, id: 'LIST' }];

const rootUrl = createUrl({
  baseUrl: BASE_URL,
});

export const productListsApi = createApi({
  reducerPath: REDUCER_PATH,
  tagTypes: TAG_TYPES,
  baseQuery: fetchBaseQuery({ baseUrl: rootUrl().origin }),
  endpoints: (builder) => ({
    getAllProductLists: builder.query<TGetAllProductListsResponse, TGetAllProductListsParam>({
      query: ({ token, ...queryParams }) => ({
        url: rootUrl({
          endpoints: [BASE_PATH],
          queryParams,
        }).path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result) =>
        result
          ? [
              ...(result?.data || []).map(({ id }) => ({
                type: ROOT_TAG_TYPE,
                id,
              })),
              ...rootInvalidateTag,
            ]
          : rootInvalidateTag,
    }),
    getOneProductLists: builder.query<TGetOneProductListsResponse, TGetOneProductListsParam>({
      query: ({ token, id }) => ({
        url: rootUrl({ endpoints: [BASE_PATH, id] }).path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result, _, { id }) => [
        { type: ROOT_TAG_TYPE, id },
        ...(result ? rootInvalidateTag : []),
      ],
    }),
    createProductLists: builder.mutation<TCreateProductListsResponse, TCreateProductListsParam>({
      query: ({ body, token }) => ({
        url: rootUrl({ endpoints: [BASE_PATH] }).path,
        method: 'POST',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: rootInvalidateTag,
    }),
    transferProductLists: builder.mutation<TCreateProductListsResponse, TCreateProductListsParam>({
      query: ({ body, token }) => ({
        url: rootUrl({ endpoints: [BASE_PATH] }).path,
        method: 'POST',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: rootInvalidateTag,
    }),
    updateProductLists: builder.mutation<TUpdateProductListsResponse, TUpdateProductListsParam>({
      query: ({ token, body, id }) => ({
        url: rootUrl({ endpoints: [BASE_PATH, id] }).path,
        method: 'PATCH',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: rootInvalidateTag,
    }),
    deleteProductLists: builder.mutation<TDeleteProductListsResponse, TDeleteProductListsParam>({
      query: ({ id, token }) => ({
        url: rootUrl({ endpoints: [BASE_PATH, id] }).path,
        method: 'DELETE',
        headers: getHeaderAuthorization(token),
      }),
      invalidatesTags: rootInvalidateTag,
    }),
    deleteMultiProductLists: builder.mutation<
      TDeleteMultiProductListsResponse,
      TDeleteMultiProductListsParam
    >({
      query: ({ body, token }) => ({
        url: rootUrl({ endpoints: ['multiple-delete', BASE_PATH] }).path,
        method: 'POST',
        body,
        headers: getHeaderAuthorization(token),
      }),
      invalidatesTags: rootInvalidateTag,
    }),
  }),
});

export const {
  useGetAllProductListsQuery,
  useGetOneProductListsQuery,
  useCreateProductListsMutation,
  useUpdateProductListsMutation,
  useDeleteProductListsMutation,
  useDeleteMultiProductListsMutation,
} = productListsApi;
