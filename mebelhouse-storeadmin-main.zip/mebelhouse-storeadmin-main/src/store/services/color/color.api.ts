import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { SERVER_URL } from '@/lib/consts/url.consts';
import { createUrl } from '@/lib/utils/formatters/formatter-url/url-builder';
import { createInvalidatesTags, getHeaderAuthorization } from '../api.helpers';
import {
  TCreateColorParam,
  TCreateColorResponse,
  TDeleteColorParam,
  TDeleteColorResponse,
  TGetAllColorParam,
  TGetAllColorResponse,
  TGetOneColorParam,
  TGetOneColorResponse,
  TUpdateColorParam,
  TUpdateColorResponse,
} from './color.type';

// consts
const BASE_URL = SERVER_URL;
const REDUCER_PATH = 'colorsApi';
const BASE_PATH = '/colors';
const ROOT_TAG_TYPE = 'colors' as const;
const TAG_TYPES = [ROOT_TAG_TYPE] as const;

const invalidatesTags = createInvalidatesTags(TAG_TYPES);

const rootUrl = createUrl({
  baseUrl: BASE_URL,
  basePath: ['api', 'v1', BASE_PATH],
});

export const colorApi = createApi({
  reducerPath: REDUCER_PATH,
  tagTypes: TAG_TYPES,
  baseQuery: fetchBaseQuery({ baseUrl: rootUrl().origin }),
  endpoints: (builder) => ({
    getAllColor: builder.query<TGetAllColorResponse, TGetAllColorParam>({
      query: () => ({
        url: rootUrl().path,
      }),
      providesTags: (result) =>
        result
          ? [
              ...(result?.data || []).map(({ id }) => ({
                type: ROOT_TAG_TYPE,
                id,
              })),
              ...invalidatesTags.colors,
            ]
          : invalidatesTags.colors,
    }),
    getOneColor: builder.query<TGetOneColorResponse, TGetOneColorParam>({
      query: ({ token, id }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result, _, { id }) => [
        { type: ROOT_TAG_TYPE, id },
        ...(result ? invalidatesTags.colors : []),
      ],
    }),
    createColor: builder.mutation<TCreateColorResponse, TCreateColorParam>({
      query: ({ body, token }) => ({
        url: rootUrl().path,
        method: 'POST',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: invalidatesTags.colors,
    }),
    updateColor: builder.mutation<TUpdateColorResponse, TUpdateColorParam>({
      query: ({ token, body, id }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        method: 'PATCH',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: invalidatesTags.colors,
    }),
    deleteColor: builder.mutation<TDeleteColorResponse, TDeleteColorParam>({
      query: ({ id, token }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        method: 'DELETE',
        headers: getHeaderAuthorization(token),
      }),
      invalidatesTags: invalidatesTags.colors,
    }),
  }),
});

export const {
  useGetAllColorQuery,
  useGetOneColorQuery,
  useCreateColorMutation,
  useUpdateColorMutation,
  useDeleteColorMutation,
} = colorApi;
