import { TBaseApiResponseData } from '@/lib/types/base-response.type';
import { TBaseRequestParams } from '@/lib/types/common.type';
import { CombineLangSuffixFields, Expand } from '@/lib/types/custom-utility.type';
import { TBaseResponseData } from '@/lib/types/formatted.types';
import { LangEnum } from '@/lib/types/lang.type';

export type TColorLangFields = ['name'];
type TMultiLangFields = CombineLangSuffixFields<TColorLangFields, LangEnum>;
// data item
export type TColorItem = Expand<TBaseApiResponseData & { code?: string } & TMultiLangFields>;

// data list
export type TColorList = TColorItem[];

// HTTPS 🚀

// GetAll 🔵
export type TGetAllColorResponse = TBaseResponseData<TColorList>;
export type TGetAllColorParam = void;

// GetOne 🔵
export type TGetOneColorResponse = TBaseResponseData<TColorItem>;
export type TGetOneColorParam = Pick<TBaseRequestParams, 'token' | 'id'>;

// Create 🟢
export type TCreateColorResponse = TBaseResponseData<TColorItem>;
export type TCreateColorBody = TMultiLangFields & {};
export type TCreateColorForm = TCreateColorBody;
export type TCreateColorParam = Pick<TBaseRequestParams<TCreateColorBody>, 'token' | 'body'>;

// Update 🟡
export type TUpdateColorResponse = TBaseResponseData<TColorItem>;
export type TUpdateColorBody = TMultiLangFields & {};
export type TUpdateColorForm = TUpdateColorBody;
export type TUpdateColorParam = Pick<TBaseRequestParams<TUpdateColorBody>, 'token' | 'body' | 'id'>;

// Delete 🔴
export type TDeleteColorResponse = TBaseResponseData<TColorItem>;
export type TDeleteColorParam = Pick<TBaseRequestParams, 'token' | 'id'>;
