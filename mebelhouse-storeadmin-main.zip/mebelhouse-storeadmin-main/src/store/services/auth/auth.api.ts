import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { SERVER_URL } from '@/lib/consts/url.consts';
import { createUrl } from '@/lib/utils/formatters/formatter-url/url-builder';
import {
  TSignInParam,
  TSignInResponse,
} from './auth.type';

const BASE_URL = SERVER_URL;
const REDUCER_PATH = 'authApi';
const BASE_PATH = '/login';

const rootUrl = createUrl({
  baseUrl: BASE_URL,
  basePath: ['showroom', BASE_PATH],
});

export const authApi = createApi({
  reducerPath: REDUCER_PATH,
  baseQuery: fetchBaseQuery({ baseUrl: rootUrl().origin }),
  endpoints: (builder) => ({
    signIn: builder.mutation<TSignInResponse, TSignInParam>({
      query: ({ body }) => ({
        url: rootUrl().path,
        method: 'POST',
        body,
      }),
    }),
  }),
});

export const authApiEndpoints = authApi.endpoints;
export const { useSignInMutation } = authApi;
