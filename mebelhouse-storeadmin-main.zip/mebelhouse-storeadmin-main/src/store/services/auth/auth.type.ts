import { TBaseRequestParams } from '@/lib/types/common.type';
import { Roles } from '../employees/employees.type';

export type TUserLangFields = ['title', 'subtitle'];

// data
export type TAuthItem = {
  data: {
    id: string;
    role: Roles | undefined;
    first_name: string;
    last_name: string;
    phone_number: string;
    token: string;
    store_id: string;
    store_name: string;
  };
};
// request body
export type TAuthBody = {
  username: string;
  password: string;
};

// HTTPS 🚀

// SignIn (login) 🟡
export type TSignInResponse = TAuthItem & {
  status_code: number | undefined;
  message: string | undefined;
};
export type TSignInBody = Pick<TAuthBody, 'username' | 'password'>;
export type TSignInParam = Pick<TBaseRequestParams<TSignInBody>, 'body'>;
