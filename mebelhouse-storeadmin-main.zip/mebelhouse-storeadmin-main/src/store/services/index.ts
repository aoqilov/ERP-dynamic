import { authApi } from './auth/auth.api';
import { brandApi } from './brand/brand.api';
import { categoriesApi } from './categories/categories.api';
import { clientsApi } from './clients/clients.api';
import { colorApi } from './color/color.api';
import { employeesApi } from './employees/employees.api';
import { exampleApi } from './example/ex.api';
import { fileApi } from './files/files.api';
import { inventoryApi } from './inventory/inventory.api';
import { orderApi } from './order/order.api';
import { productListsApi } from './product-lists/product-lists.api';
import { productsSetApi } from './products-set/products-set.api';
import { productsApi } from './products/products.api';
import { regionApi } from './region/region.api';
import { returnApi } from './return/return.api';
import { salesApi } from './sales/sales.api';
import { showroomProdLogApi } from './showroom-prod-log/showroom-prod-log.api';
import { showroomsApi } from './showrooms/showrooms.api';
import { subcategoriesApi } from './sub-categories/sub-categories.api';
import { transferApi } from './transfer/transfer.api';
import { usersApi } from './users/users.api';

export const apiReducers = {
  [transferApi.reducerPath]: transferApi.reducer,
  [inventoryApi.reducerPath]: inventoryApi.reducer,

  [showroomsApi.reducerPath]: showroomsApi.reducer,
  [orderApi.reducerPath]: orderApi.reducer,
  [salesApi.reducerPath]: salesApi.reducer,
  [returnApi.reducerPath]: returnApi.reducer,

  [productsSetApi.reducerPath]: productsSetApi.reducer,
  [categoriesApi.reducerPath]: categoriesApi.reducer,
  [subcategoriesApi.reducerPath]: subcategoriesApi.reducer,
  [authApi.reducerPath]: authApi.reducer,
  [fileApi.reducerPath]: fileApi.reducer,
  [colorApi.reducerPath]: colorApi.reducer,
  [brandApi.reducerPath]: brandApi.reducer,
  [regionApi.reducerPath]: regionApi.reducer,
  [productListsApi.reducerPath]: productListsApi.reducer,
  [productsApi.reducerPath]: productsApi.reducer,
  [showroomProdLogApi.reducerPath]: showroomProdLogApi.reducer,
  [clientsApi.reducerPath]: clientsApi.reducer,

  [usersApi.reducerPath]: usersApi.reducer,
  [exampleApi.reducerPath]: exampleApi.reducer,
  [employeesApi.reducerPath]: employeesApi.reducer,
};

export const apiMiddlewareList = [
  orderApi.middleware,
  salesApi.middleware,
  inventoryApi.middleware,
  returnApi.middleware,
  categoriesApi.middleware,
  productsSetApi.middleware,
  transferApi.middleware,
  showroomsApi.middleware,
  subcategoriesApi.middleware,
  authApi.middleware,
  fileApi.middleware,
  colorApi.middleware,
  brandApi.middleware,
  regionApi.middleware,
  productListsApi.middleware,
  productsApi.middleware,
  employeesApi.middleware,
  clientsApi.middleware,
  showroomProdLogApi.middleware,

  usersApi.middleware,
  exampleApi.middleware,
];
