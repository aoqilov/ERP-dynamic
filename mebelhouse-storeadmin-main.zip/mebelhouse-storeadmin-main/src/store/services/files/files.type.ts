import { TBaseApiResponseData } from '@/lib/types/base-response.type';
import { TBaseRequestParams } from '@/lib/types/common.type';
import { CombineLangSuffixFields, Expand } from '@/lib/types/custom-utility.type';
import { TBaseResponseData } from '@/lib/types/formatted.types';
import { LangEnum } from '@/lib/types/lang.type';

export type TFileLangFields = [];

// data item
export type TFileItem = Expand<
  TBaseApiResponseData & {
    picture: string;
  } & CombineLangSuffixFields<TFileLangFields, LangEnum>
>;

// data list
export type TFileList = TFileItem[];

// HTTPS 🚀

// GetAll 🔵
export type TGetAllFileResponse = TBaseResponseData<TFileList>;
export type TGetAllFileParam = Pick<TBaseRequestParams, 'token'>;

// GetOne 🔵
export type TGetOneFileResponse = TBaseResponseData<TFileItem>;
export type TGetOneFileParam = Pick<TBaseRequestParams, 'token' | 'id'>;

// Create 🟢
export type TCreateFileResponse = TBaseResponseData<TFileItem>;
export type TCreateFileBody = FormData;
export type TCreateFileForm = Pick<TFileItem, 'picture'>;
export type TCreateFileParam = Pick<TBaseRequestParams<TCreateFileBody>, 'token' | 'body'>;

// Update 🟡
export type TUpdateFileResponse = TBaseResponseData<TFileItem>;
export type TUpdateFileBody = Pick<TFileItem, 'picture' | 'id'>;
export type TUpdateFileForm = TUpdateFileBody;
export type TUpdateFileParam = Pick<TBaseRequestParams<TUpdateFileBody>, 'token' | 'body'>;

// Delete 🔴
export type TDeleteFileResponse = TBaseResponseData<TFileItem>;
export type TDeleteFileParam = Pick<TBaseRequestParams, 'token' | 'id'>;
