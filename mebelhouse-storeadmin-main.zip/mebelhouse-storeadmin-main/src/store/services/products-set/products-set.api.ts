import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { SERVER_URL } from '@/lib/consts/url.consts';
import { createUrl } from '@/lib/utils/formatters/formatter-url/url-builder';
import { getHeaderAuthorization } from '../api.helpers';
import {
  TCreateProductsSetParam,
  TCreateProductsSetResponse,
  TDeleteMultiProductsSetParam,
  TDeleteMultiProductsSetResponse,
  TDeleteProductsSetParam,
  TDeleteProductsSetResponse,
  TGetAllProductsSetParam,
  TGetAllProductsSetResponse,
  TGetOneProductsSetParam,
  TGetOneProductsSetResponse,
  TUpdateProductsSetParam,
  TUpdateProductsSetResponse,
} from './products-set.type';

// consts
const BASE_URL = SERVER_URL;
const REDUCER_PATH = 'productSets';
const BASE_PATH = '/admin/product-sets';
const ROOT_TAG_TYPE = 'product-sets' as const;
const TAG_TYPES = [ROOT_TAG_TYPE] as const;
const rootInvalidateTag = [{ type: ROOT_TAG_TYPE, id: 'LIST' }];

// const invalidatesTags = createInvalidatesTags(TAG_TYPES);

const rootUrl = createUrl({
  baseUrl: BASE_URL,
  basePath: [BASE_PATH],
});

export const productsSetApi = createApi({
  reducerPath: REDUCER_PATH,
  tagTypes: TAG_TYPES,
  baseQuery: fetchBaseQuery({ baseUrl: rootUrl().origin }),
  endpoints: (builder) => ({
    getAllProductsSet: builder.query<TGetAllProductsSetResponse, TGetAllProductsSetParam>({
      query: ({ token, page, page_size, search }) => ({
        url: rootUrl({
          queryParams: { page, page_size, search },
        }).path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result) =>
        result
          ? [
              ...(result?.data || []).map(({ id }) => ({
                type: ROOT_TAG_TYPE,
                id,
              })),
              ...rootInvalidateTag,
            ]
          : rootInvalidateTag,
    }),
    getOneProductsSet: builder.query<TGetOneProductsSetResponse, TGetOneProductsSetParam>({
      query: ({ token, id }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result, _, { id }) => [
        { type: ROOT_TAG_TYPE, id },
        ...(result ? rootInvalidateTag : []),
      ],
    }),
    createProductsSet: builder.mutation<TCreateProductsSetResponse, TCreateProductsSetParam>({
      query: ({ body, token }) => ({
        url: rootUrl().path,
        method: 'POST',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: rootInvalidateTag,
    }),
    // transferProductsSet: builder.mutation<TCreateProductsSetResponse, TCreateProductsSetParam>({
    //   query: ({ body, token }) => ({
    //     url: rootUrl().path,
    //     method: 'POST',
    //     headers: getHeaderAuthorization(token),
    //     body,
    //   }),
    //   invalidatesTags: rootInvalidateTag,
    // }),
    updateProductsSet: builder.mutation<TUpdateProductsSetResponse, TUpdateProductsSetParam>({
      query: ({ token, body, id }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        method: 'PATCH',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: rootInvalidateTag,
    }),
    deleteProductsSet: builder.mutation<TDeleteProductsSetResponse, TDeleteProductsSetParam>({
      query: ({ id, token }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        method: 'DELETE',
        headers: getHeaderAuthorization(token),
      }),
      invalidatesTags: rootInvalidateTag,
    }),
    deleteMultiProductsSet: builder.mutation<
      TDeleteMultiProductsSetResponse,
      TDeleteMultiProductsSetParam
    >({
      query: ({ body, token }) => ({
        url: rootUrl({ endpoints: ['multiple-delete'] }).path,
        method: 'POST',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: rootInvalidateTag,
    }),
  }),
});

export const {
  useGetAllProductsSetQuery,
  useGetOneProductsSetQuery,
  useCreateProductsSetMutation,
  useUpdateProductsSetMutation,
  useDeleteProductsSetMutation,
  useDeleteMultiProductsSetMutation,
} = productsSetApi;
