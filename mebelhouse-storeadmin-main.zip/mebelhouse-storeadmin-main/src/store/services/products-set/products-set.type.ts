import { TBaseRequestParams } from '@/lib/types/common.type';
import { CombineLangSuffixFields } from '@/lib/types/custom-utility.type';
import { TBaseResponseData, TPaginatedResponse } from '@/lib/types/formatted.types';
import { LangEnum } from '@/lib/types/lang.type';
import { TSubCategoriesItem } from '../sub-categories/sub-categories.type';

export type TProductSetQuantities = {
  product_id: string;
  set_item_id: string;
  quantity: string;
  discount: boolean;
  discount_price: string;
};

export type TProductSetImages = {
  id: string;
  position: number;
  path: string;
};

type MultiProductNameField = CombineLangSuffixFields<['product_name'], LangEnum>;
type MultiColorNameField = CombineLangSuffixFields<['color_name'], LangEnum>;

// data item

export type TProductsSetInnerItem = MultiProductNameField & {
  id: string;
  origin_price: number;
  sale_price: number;

  subcategory: TSubCategoriesItem;
  images: TProductSetImages[];
  quantities: (MultiColorNameField & TProductSetQuantities)[];
};

export type TProductsSetItem = {
  id: string;
  name: string;
  bar_code: string;
  description: string;
  sale_price: number;
  items: TProductsSetInnerItem[];
};

// data list
export type TProductsSetList = TProductsSetItem[];

// HTTPS 🚀

// GetAll 🔵
export type TGetAllProductsSetResponse = TPaginatedResponse<TProductsSetList>;
export type TGetAllProductsSetParam = Partial<
  Pick<TBaseRequestParams, 'page_size' | 'page' | 'search'>
> & {
  token: string;
};

// GetOne 🔵
export type TGetOneProductsSetResponse = TBaseResponseData<TProductsSetItem>;
export type TGetOneProductsSetParam = Pick<TBaseRequestParams, 'token' | 'id'>;

//BODY
export type TBodyItemType = {
  product: {
    id: string;
  };
  colour: {
    id: string;
  };
  quantity: number;
};

export type TProductsSetBody = Pick<TProductsSetItem, 'name' | 'sale_price'> & {
  items: TBodyItemType[];
};

// Create 🟢
export type TCreateProductsSetResponse = TBaseResponseData<TProductsSetItem>;
export type TCreateProductsSetParam = Pick<TBaseRequestParams<TProductsSetBody>, 'token' | 'body'>;

// Update 🟡
export type TUpdateProductsSetResponse = TBaseResponseData<TProductsSetItem>;
export type TUpdateProductsSetParam = Pick<
  TBaseRequestParams<TProductsSetBody>,
  'token' | 'body' | 'id'
>;

// Delete 🔴
export type TDeleteProductsSetResponse = TBaseResponseData<TProductsSetItem>;
export type TDeleteProductsSetParam = Pick<TBaseRequestParams, 'token' | 'id'>;

// Multi Delete 🔴
export type TDeleteMultiProductsSetResponse = TBaseResponseData<TProductsSetItem>;
export type TDeleteMultiProductsSetParam = Pick<
  TBaseRequestParams<{ ids: string[] }>,
  'token' | 'body'
>;
