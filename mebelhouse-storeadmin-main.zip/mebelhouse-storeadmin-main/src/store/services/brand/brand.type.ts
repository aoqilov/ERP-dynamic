import { TBaseApiResponseData } from '@/lib/types/base-response.type';
import { TBaseRequestParams } from '@/lib/types/common.type';
import { CombineLangSuffixFields, Expand } from '@/lib/types/custom-utility.type';
import { TBaseResponseData } from '@/lib/types/formatted.types';
import { LangEnum } from '@/lib/types/lang.type';

export type TBrandLangFields = ['name'];
type TMultiLangFields = CombineLangSuffixFields<TBrandLangFields, LangEnum>;
// data item
export type TBrandItem = Expand<TBaseApiResponseData & {} & TMultiLangFields>;

// data list
export type TBrandList = TBrandItem[];

// HTTPS 🚀

// GetAll 🔵
export type TGetAllBrandResponse = TBaseResponseData<TBrandList>;
export type TGetAllBrandParam = void;

// GetOne 🔵
export type TGetOneBrandResponse = TBaseResponseData<TBrandItem>;
export type TGetOneBrandParam = Pick<TBaseRequestParams, 'token' | 'id'>;

// Create 🟢
export type TCreateBrandResponse = TBaseResponseData<TBrandItem>;
export type TCreateBrandBody = TMultiLangFields & {};
export type TCreateBrandForm = TCreateBrandBody;
export type TCreateBrandParam = Pick<TBaseRequestParams<TCreateBrandBody>, 'token' | 'body'>;

// Update 🟡
export type TUpdateBrandResponse = TBaseResponseData<TBrandItem>;
export type TUpdateBrandBody = TMultiLangFields & {};
export type TUpdateBrandForm = TUpdateBrandBody;
export type TUpdateBrandParam = Pick<TBaseRequestParams<TUpdateBrandBody>, 'token' | 'body' | 'id'>;

// Delete 🔴
export type TDeleteBrandResponse = TBaseResponseData<TBrandItem>;
export type TDeleteBrandParam = Pick<TBaseRequestParams, 'token' | 'id'>;
