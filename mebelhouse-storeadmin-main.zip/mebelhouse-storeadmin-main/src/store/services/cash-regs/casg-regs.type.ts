import { TBaseApiResponseData } from '@/lib/types/base-response.type';
import { TBaseRequestParams } from '@/lib/types/common.type';
import { TBaseResponseData } from '@/lib/types/formatted.types';

// data list

// HTTPS 🚀

export type TCashRegisterItem = TBaseApiResponseData & {
  name: string;
  cash_code: string;
  is_open: boolean;
};

// // Update 🟡
// export type TUpdateCashRegsResponse = TBaseResponseData<TCashRegsItem>;
// export type TUpdateCashRegsBody = TCashRegsBody;
// export type TUpdateCashRegsForm = TUpdateCashRegsBody;

// export type TUpdateCashRegsParam = Pick<
//   TBaseRequestParams<TUpdateCashRegsBody>,
//   'token' | 'body' | 'id'
// >;

// Delete 🔴
export type TDeleteCashRegsResponse = TBaseResponseData<TCashRegisterItem>;
export type TDeleteCashRegsParam = Pick<TBaseRequestParams, 'token' | 'id'>;
