import { TBaseApiResponseData } from '@/lib/types/base-response.type';
import { TBaseRequestParams } from '@/lib/types/common.type';
import { CombineLangSuffixFields, Expand } from '@/lib/types/custom-utility.type';
import { TBaseResponseData } from '@/lib/types/formatted.types';
import { LangEnum } from '@/lib/types/lang.type';

export type TCategoriesLangFields = ['name'];
type TMultiLangKeys = CombineLangSuffixFields<TCategoriesLangFields, LangEnum>;

// data item
export type TCategoriesItem = Expand<
  TBaseApiResponseData & {
    position: number;
    name_uz: string;
    name_ru: string;
    picture: any;
  } & TMultiLangKeys
>;

// data list
export type TCategoriesList = TCategoriesItem[];

// HTTPS 🚀

// GetAll 🔵
export type TGetAllCategoriesResponse = TBaseResponseData<TCategoriesList>;
export type TGetAllCategoriesParam = Pick<TBaseRequestParams, 'token'>;

// GetOne 🔵
export type TGetOneCategoriesResponse = TBaseResponseData<TCategoriesItem>;
export type TGetOneCategoriesParam = Pick<TBaseRequestParams, 'token' | 'id'>;

// Create 🟢
export type TCreateCategoriesResponse = TBaseResponseData<TCategoriesItem>;
export type TCreateCategoriesBody = Pick<TCategoriesItem, 'position' | keyof TMultiLangKeys>;
export type TCreateCategoriesForm = TCreateCategoriesBody;
export type TCreateCategoriesParam = Pick<
  TBaseRequestParams<TCreateCategoriesBody>,
  'token' | 'body'
>;

// Update 🟡
export type TUpdateCategoriesResponse = TBaseResponseData<TCategoriesItem>;
export type TUpdateCategoriesBody = Pick<TCategoriesItem, 'position' | keyof TMultiLangKeys>;
export type TUpdateCategoriesForm = TUpdateCategoriesBody;
export type TUpdateCategoriesParam = Pick<
  TBaseRequestParams<TUpdateCategoriesBody>,
  'token' | 'body' | 'id'
>;

// Delete 🔴
export type TDeleteCategoriesResponse = TBaseResponseData<TCategoriesItem>;
export type TDeleteCategoriesParam = Pick<TBaseRequestParams, 'token' | 'id'>;
