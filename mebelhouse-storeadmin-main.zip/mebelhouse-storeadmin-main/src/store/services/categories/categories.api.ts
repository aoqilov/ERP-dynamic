import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { SERVER_URL } from '@/lib/consts/url.consts';
import { createUrl } from '@/lib/utils/formatters/formatter-url/url-builder';
import { getHeaderAuthorization } from '../api.helpers';
import {
  TCreateCategoriesParam,
  TCreateCategoriesResponse,
  TDeleteCategoriesParam,
  TDeleteCategoriesResponse,
  TGetAllCategoriesParam,
  TGetAllCategoriesResponse,
  TGetOneCategoriesParam,
  TGetOneCategoriesResponse,
  TUpdateCategoriesParam,
  TUpdateCategoriesResponse,
} from './categories.type';

// consts
const BASE_URL = SERVER_URL;
const REDUCER_PATH = 'categoriesApi';
const BASE_PATH = '/client/categories';
const ROOT_TAG_TYPE = 'categories' as const;
const TAG_TYPES = [ROOT_TAG_TYPE] as const;
const rootInvalidateTag = [{ type: ROOT_TAG_TYPE, id: 'LIST' }];

const rootUrl = createUrl({
  baseUrl: BASE_URL,
  basePath: [BASE_PATH],
});

export const categoriesApi = createApi({
  reducerPath: REDUCER_PATH,
  tagTypes: TAG_TYPES,
  baseQuery: fetchBaseQuery({ baseUrl: rootUrl().origin }),
  endpoints: (builder) => ({
    getAllCategories: builder.query<TGetAllCategoriesResponse, TGetAllCategoriesParam>({
      query: ({ token }) => ({
        url: rootUrl().path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result) =>
        result
          ? [
              ...(result?.data || []).map(({ id }) => ({
                type: ROOT_TAG_TYPE,
                id,
              })),
              ...rootInvalidateTag,
            ]
          : rootInvalidateTag,
    }),
    getOneCategories: builder.query<TGetOneCategoriesResponse, TGetOneCategoriesParam>({
      query: ({ token, id }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result, _, { id }) => [
        { type: ROOT_TAG_TYPE, id },
        ...(result ? rootInvalidateTag : []),
      ],
    }),
    createCategories: builder.mutation<TCreateCategoriesResponse, TCreateCategoriesParam>({
      query: ({ body, token }) => ({
        url: rootUrl().path,
        method: 'POST',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: rootInvalidateTag,
    }),
    updateCategories: builder.mutation<TUpdateCategoriesResponse, TUpdateCategoriesParam>({
      query: ({ token, body, id }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        method: 'PATCH',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: rootInvalidateTag,
    }),
    deleteCategories: builder.mutation<TDeleteCategoriesResponse, TDeleteCategoriesParam>({
      query: ({ id, token }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        method: 'DELETE',
        headers: getHeaderAuthorization(token),
      }),
      invalidatesTags: rootInvalidateTag,
    }),
  }),
});

export const {
  useGetAllCategoriesQuery,
  useGetOneCategoriesQuery,
  useCreateCategoriesMutation,
  useUpdateCategoriesMutation,
  useDeleteCategoriesMutation,
} = categoriesApi;
