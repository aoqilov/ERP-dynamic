import { TBaseRequestParams, TModifiedProduct } from '@/lib/types/common.type';
import { Expand } from '@/lib/types/custom-utility.type';
import { TPaginatedResponse } from '@/lib/types/formatted.types';

export type TOrderQuantityType = {
  color_uz: string;
  color_ru: string;
  quantity: number;
};

export type TProductOrderItem = Omit<
  TModifiedProduct,
  'name_ru' | 'name_uz' | 'quantities' | 'sub_category_name_uz' | 'sub_category_name_ru'
> & {
  product_name_ru: string;
  product_name_uz: string;
  subcategory_name_ru: string;
  quantities: TOrderQuantityType[];
};

export type TOrderLocation = {
  location_name: string;
  products: TProductOrderItem[];
};

export type TOrderItem = {
  id: string;
  order_number: string;
  sold_time: string;
  total_price: string;
  locations: TOrderLocation[];
};

// data list
export type TOrderList = TOrderItem[];

// HTTPS 🚀

// GetAll 🔵
export type TGetAllOrderResponse = TPaginatedResponse<TOrderList>;
export type TGetAllOrderParam = Expand<
  Partial<
    Pick<
      TBaseRequestParams,
      'page_size' | 'page' | 'search' | 'created_at_from' | 'created_at_to' | 'token' | 'pagination'
    >
  >
>;
