import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { SERVER_URL } from '@/lib/consts/url.consts';
import { createUrl } from '@/lib/utils/formatters/formatter-url/url-builder';
import { createInvalidatesTags, getHeaderAuthorization } from '../api.helpers';
import { TGetAllOrderParam, TGetAllOrderResponse } from './order.type';

// consts
const BASE_URL = SERVER_URL;
const REDUCER_PATH = 'orderApi';
const BASE_PATH = '/sales';
const ROOT_TAG_TYPE = 'orderLogs' as const;
const TAG_TYPES = [ROOT_TAG_TYPE] as const;

const invalidatesTags = createInvalidatesTags(TAG_TYPES);

const rootUrl = createUrl({
  baseUrl: BASE_URL,
  basePath: [BASE_PATH],
});

export const orderApi = createApi({
  reducerPath: REDUCER_PATH,
  tagTypes: TAG_TYPES,
  baseQuery: fetchBaseQuery({ baseUrl: rootUrl().origin }),
  endpoints: (builder) => ({
    getAllProductsOrder: builder.query<
      TGetAllOrderResponse,
      TGetAllOrderParam & { sets?: boolean }
    >({
      query: ({ token, pagination = false, sets = false, ...queryParams }) => ({
        url: rootUrl({
          queryParams,
          endpoints: [sets ? 'sets' : '', pagination ? 'pagination' : ''],
        }).path,
        headers: getHeaderAuthorization(token!),
      }),
      providesTags: (result) =>
        result
          ? [
              ...(result?.data || []).map(({ id }) => ({
                type: ROOT_TAG_TYPE,
                id,
              })),
              ...invalidatesTags.orderLogs,
            ]
          : invalidatesTags.orderLogs,
      transformResponse(baseQueryReturnValue: TGetAllOrderResponse) {
        return Array.isArray(baseQueryReturnValue?.data)
          ? baseQueryReturnValue
          : { ...baseQueryReturnValue, data: [] };
      },
    }),
  }),
});

export const { useGetAllProductsOrderQuery } = orderApi;
