import { TBaseRequestParams } from '@/lib/types/common.type';
import { Expand } from '@/lib/types/custom-utility.type';
import { TPaginatedResponse } from '@/lib/types/formatted.types';
import { TProductsItem } from '../products/products.type';

export type TExecuter = {
  id: string;
  username: string;
  first_name: string;
  last_name: string;
};

export type TInventoryItem = {
  old_quantity: string;
  new_quantity: string;
  created_at: string;
  executer: TExecuter;
  product_list: TProductsItem & {
    colour_name_ru: string;
    colour_name_uz: string;
    colour_id: string;
  };
};

// data list
export type TInventoryList = TInventoryItem[];

// HTTPS 🚀

// GetAll 🔵
export type TGetAllInventoryResponse = TPaginatedResponse<TInventoryList>;
export type TGetAllInventoryParam = Expand<
  Partial<
    Pick<
      TBaseRequestParams,
      'page_size' | 'page' | 'search' | 'created_at_from' | 'created_at_to' | 'token'
    >
  >
>;
