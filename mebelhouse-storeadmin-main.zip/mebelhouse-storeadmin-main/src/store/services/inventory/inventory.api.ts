import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { SERVER_URL } from '@/lib/consts/url.consts';
import { createUrl } from '@/lib/utils/formatters/formatter-url/url-builder';
import { createInvalidatesTags, getHeaderAuthorization } from '../api.helpers';
import { TGetAllInventoryParam, TGetAllInventoryResponse } from './inventory.type';

// consts
const BASE_URL = SERVER_URL;
const REDUCER_PATH = 'inventarizationsApi';
const BASE_PATH = '/inventarizations';
const ROOT_TAG_TYPE = 'inventarizations' as const;
const TAG_TYPES = [ROOT_TAG_TYPE] as const;

const invalidatesTags = createInvalidatesTags(TAG_TYPES);

const rootUrl = createUrl({
  baseUrl: BASE_URL,
  basePath: ['showroom', BASE_PATH],
});

export const inventoryApi = createApi({
  reducerPath: REDUCER_PATH,
  tagTypes: TAG_TYPES,
  baseQuery: fetchBaseQuery({ baseUrl: rootUrl().origin }),
  endpoints: (builder) => ({
    getAllInventory: builder.query<TGetAllInventoryResponse, TGetAllInventoryParam>({
      query: ({ token, ...queryParams }) => ({
        url: rootUrl({ queryParams, endpoints: ['pagination'] }).path,
        headers: getHeaderAuthorization(token!),
      }),
      providesTags: (result) =>
        result
          ? [
              ...(result?.data || []).map(({ id }) => ({
                type: ROOT_TAG_TYPE,
                id,
              })),
              ...invalidatesTags.inventarizations,
            ]
          : invalidatesTags.inventarizations,
      transformResponse(baseQueryReturnValue: TGetAllInventoryResponse) {
        return Array.isArray(baseQueryReturnValue?.data)
          ? baseQueryReturnValue
          : { ...baseQueryReturnValue, data: [] };
      },
    }),
  }),
});

export const { useGetAllInventoryQuery } = inventoryApi;
