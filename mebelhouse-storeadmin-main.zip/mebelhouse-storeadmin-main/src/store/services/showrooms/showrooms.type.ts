import { TBaseApiResponseData } from '@/lib/types/base-response.type';
import { TBaseRequestParams } from '@/lib/types/common.type';
import { Expand } from '@/lib/types/custom-utility.type';
import { TBaseResponseData, TPaginatedResponse } from '@/lib/types/formatted.types';

export type TShowroomsLangFields = ['name'];
type TMultiLangFields = { name: string };

// data item
export type TShowroomsItem = Expand<TBaseApiResponseData & {} & TMultiLangFields>;

// data list
export type TShowroomsList = TShowroomsItem[];

// HTTPS 🚀

// GetAll 🔵
export type TGetAllShowroomsResponse = TPaginatedResponse<TShowroomsList>;
export type TGetAllShowroomsParam = Partial<
  Pick<TBaseRequestParams, 'page_size' | 'page' | 'name' | 'address' | 'phone'>
> & { token: string };

// GetOne 🔵
export type TGetOneShowroomsResponse = TBaseResponseData<TShowroomsItem>;
export type TGetOneShowroomsParam = Pick<TBaseRequestParams, 'token' | 'id'>;

// Create 🟢
export type TCreateShowroomsResponse = TBaseResponseData<TShowroomsItem>;
export type TCreateShowroomsBody = Pick<TShowroomsItem, keyof TMultiLangFields> & {
  address: string;
  phone: string;
};
export type TCreateShowroomsForm = TCreateShowroomsBody;
export type TCreateShowroomsParam = Pick<
  TBaseRequestParams<TCreateShowroomsBody>,
  'token' | 'body'
>;

// Update 🟡
export type TUpdateShowroomsResponse = TBaseResponseData<TShowroomsItem>;
export type TUpdateShowroomsBody = Pick<TShowroomsItem, keyof TMultiLangFields> & {
  address: string;
  phone: string;
};
export type TUpdateShowroomsForm = TUpdateShowroomsBody;
export type TUpdateShowroomsParam = Pick<
  TBaseRequestParams<TUpdateShowroomsBody>,
  'token' | 'body' | 'id'
>;

// Delete 🔴
export type TDeleteShowroomsResponse = TBaseResponseData<TShowroomsItem>;
export type TDeleteShowroomsParam = Pick<TBaseRequestParams, 'token' | 'id'>;
