import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { SERVER_URL } from '@/lib/consts/url.consts';
import { createUrl } from '@/lib/utils/formatters/formatter-url/url-builder';
import { createInvalidatesTags, getHeaderAuthorization } from '../api.helpers';
import {
  TCreateShowroomsParam,
  TCreateShowroomsResponse,
  TDeleteShowroomsParam,
  TDeleteShowroomsResponse,
  TGetAllShowroomsParam,
  TGetAllShowroomsResponse,
  TGetOneShowroomsParam,
  TGetOneShowroomsResponse,
  TUpdateShowroomsParam,
  TUpdateShowroomsResponse,
} from './showrooms.type';

// consts
const BASE_URL = SERVER_URL;
const REDUCER_PATH = 'showroomsApi';
const BASE_PATH = '/showrooms';
const ROOT_TAG_TYPE = 'showrooms' as const;
const TAG_TYPES = [ROOT_TAG_TYPE] as const;

const invalidatesTags = createInvalidatesTags(TAG_TYPES);

const rootUrl = createUrl({
  baseUrl: BASE_URL,
  basePath: [BASE_PATH],
});

export const showroomsApi = createApi({
  reducerPath: REDUCER_PATH,
  tagTypes: TAG_TYPES,
  baseQuery: fetchBaseQuery({ baseUrl: rootUrl().origin }),
  endpoints: (builder) => ({
    getAllShowrooms: builder.query<TGetAllShowroomsResponse, TGetAllShowroomsParam>({
      query: ({ token, ...queryParams }) => ({
        url: rootUrl({ queryParams }).path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result) =>
        result
          ? [
              ...(result?.data || []).map(({ id }) => ({
                type: ROOT_TAG_TYPE,
                id,
              })),
              ...invalidatesTags.showrooms,
            ]
          : invalidatesTags.showrooms,
      transformResponse(baseQueryReturnValue: TGetAllShowroomsResponse) {
        return Array.isArray(baseQueryReturnValue?.data)
          ? baseQueryReturnValue
          : { ...baseQueryReturnValue, data: [] };
      },
    }),
    getAllShowroomsSelect: builder.query<TGetAllShowroomsResponse, TGetAllShowroomsParam>({
      query: ({ token }) => ({
        url: rootUrl().path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result) =>
        result
          ? [
              ...(result?.data || []).map(({ id }) => ({
                type: ROOT_TAG_TYPE,
                id,
              })),
              ...invalidatesTags.showrooms,
            ]
          : invalidatesTags.showrooms,
      transformResponse(baseQueryReturnValue: TGetAllShowroomsResponse) {
        return Array.isArray(baseQueryReturnValue?.data)
          ? baseQueryReturnValue
          : { ...baseQueryReturnValue, data: [] };
      },
    }),
    getOneShowrooms: builder.query<TGetOneShowroomsResponse, TGetOneShowroomsParam>({
      query: ({ token, id }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result, _, { id }) => [
        { type: ROOT_TAG_TYPE, id },
        ...(result ? invalidatesTags.showrooms : []),
      ],
    }),
    createShowrooms: builder.mutation<TCreateShowroomsResponse, TCreateShowroomsParam>({
      query: ({ body, token }) => ({
        url: rootUrl().path,
        method: 'POST',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: invalidatesTags.showrooms,
    }),
    updateShowrooms: builder.mutation<TUpdateShowroomsResponse, TUpdateShowroomsParam>({
      query: ({ token, body, id }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        method: 'PATCH',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: invalidatesTags.showrooms,
    }),
    deleteShowrooms: builder.mutation<TDeleteShowroomsResponse, TDeleteShowroomsParam>({
      query: ({ id, token }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        method: 'DELETE',
        headers: getHeaderAuthorization(token),
      }),
      invalidatesTags: invalidatesTags.showrooms,
    }),
  }),
});

export const {
  useGetAllShowroomsQuery,
  useGetOneShowroomsQuery,
  useCreateShowroomsMutation,
  useUpdateShowroomsMutation,
  useDeleteShowroomsMutation,
  useGetAllShowroomsSelectQuery,
} = showroomsApi;
