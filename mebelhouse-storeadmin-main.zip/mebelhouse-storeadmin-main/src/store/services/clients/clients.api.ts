import { SERVER_URL } from '@/lib/consts/url.consts';
import { createUrl } from '@/lib/utils/formatters/formatter-url/url-builder';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { createInvalidatesTags, getHeaderAuthorization } from '../api.helpers';
import {
  TGetAllClientsParam,
  TGetAllClientsResponse,
  TGetOneClientsParam,
  TGetOneClientsResponse,
} from './clients.type';

// consts
const BASE_URL = SERVER_URL;
const REDUCER_PATH = 'clientsApi';
const BASE_PATH = '/clients';
const ROOT_TAG_TYPE = 'clients' as const;
const TAG_TYPES = [ROOT_TAG_TYPE] as const;

const invalidatesTags = createInvalidatesTags(TAG_TYPES);

const rootUrl = createUrl({
  baseUrl: BASE_URL,
  basePath: [BASE_PATH],
});

export const clientsApi = createApi({
  reducerPath: REDUCER_PATH,
  tagTypes: TAG_TYPES,
  baseQuery: fetchBaseQuery({ baseUrl: rootUrl().origin }),
  endpoints: (builder) => ({
    getAllClients: builder.query<TGetAllClientsResponse, TGetAllClientsParam>({
      query: ({ search, token, page, page_size }) => ({
        url: rootUrl({
          queryParams: { search, page, page_size },
        }).path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result) =>
        result
          ? [
              ...(result?.data || []).map(({ id }) => ({
                type: ROOT_TAG_TYPE,
                id,
              })),
              ...invalidatesTags.clients,
            ]
          : invalidatesTags.clients,
    }),
    getOneClients: builder.query<TGetOneClientsResponse, TGetOneClientsParam>({
      query: ({ token, id }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result, _, { id }) => [
        { type: ROOT_TAG_TYPE, id },
        ...(result ? invalidatesTags.clients : []),
      ],
    }),
  }),
});

export const { useGetAllClientsQuery, useGetOneClientsQuery } = clientsApi;
