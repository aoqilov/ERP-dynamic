import { TBaseRequestParams } from '@/lib/types/common.type';
import { TBaseResponseData, TPaginatedResponse } from '@/lib/types/formatted.types';

export type TClientsItem = {
  id?: string;
  name: string;
  phone_number: string;
};

// data list
export type TClientsList = TClientsItem[];

// HTTPS 🚀

// GetAll 🔵
export type TGetAllClientsResponse = TPaginatedResponse<TClientsList>;

export type TGetAllClientsParam = Pick<
  TBaseRequestParams,
  'token' | 'search' | 'page' | 'page_size' | 'pagination'
>;

// GetOne 🔵
export type TGetOneClientsResponse = TBaseResponseData<TClientsItem>;
export type TGetOneClientsParam = Pick<TBaseRequestParams, 'token' | 'id'>;
