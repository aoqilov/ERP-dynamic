export const getHeaderAuthorization = (token: string) => {
  return {
    Authorization: `Bearer ${token}`,
  };
};

type InvalidatesTags<Tags extends string> = {
  [K in Tags]: { type: K; id: string }[];
};

export const createInvalidatesTags = <Tags extends readonly string[]>(tags: Tags) => {
  const result = tags.reduce((acc, tag) => {
    acc[tag as Tags[number]] = [{ type: tag as Tags[number], id: 'LIST' }];
    return acc;
  }, {} as InvalidatesTags<Tags[number]>);

  return result;
};
