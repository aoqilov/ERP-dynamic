import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { SERVER_URL } from '@/lib/consts/url.consts';
import { createUrl } from '@/lib/utils/formatters/formatter-url/url-builder';
import { createInvalidatesTags, getHeaderAuthorization } from '../api.helpers';
import {
  TAcceptTransferParam,
  TAcceptTransferResponse,
  TCancleTransferParam,
  TCancleTransferResponse,
  TCreateTransferParam,
  TCreateTransferResponse,
  TGetAllTransferParam,
  TGetAllTransferResponse,
  TGetOneTransferParam,
  TGetOneTransferResponse,
  TRejectTransferParam,
  TRejectTransferResponse,
} from './transfer.type';

// consts
const BASE_URL = SERVER_URL.replace('admin', '');
const REDUCER_PATH = 'transferApi';
const BASE_PATH = '/transfers';
const ROOT_TAG_TYPE = 'transfer' as const;
const TAG_TYPES = [ROOT_TAG_TYPE] as const;

const invalidatesTags = createInvalidatesTags(TAG_TYPES);

const rootUrl = createUrl({
  baseUrl: BASE_URL,
  basePath: [BASE_PATH],
});

export const transferApi = createApi({
  reducerPath: REDUCER_PATH,
  tagTypes: TAG_TYPES,
  baseQuery: fetchBaseQuery({ baseUrl: rootUrl().origin }),
  endpoints: (builder) => ({
    getAllTransfer: builder.query<TGetAllTransferResponse, TGetAllTransferParam>({
      query: ({ token, pagination = false, ...queryParams }) => ({
        url: rootUrl({ queryParams, endpoints: [pagination ? 'pagination' : ''] }).path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result) =>
        result
          ? [
              ...(result?.data || []).map(({ id }) => ({
                type: ROOT_TAG_TYPE,
                id,
              })),
              ...invalidatesTags.transfer,
            ]
          : invalidatesTags.transfer,
    }),
    getOneTransfer: builder.query<TGetOneTransferResponse, TGetOneTransferParam>({
      query: ({ token, id }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result, _, { id }) => [
        { type: ROOT_TAG_TYPE, id },
        ...(result ? invalidatesTags.transfer : []),
      ],
    }),
    createTransfer: builder.mutation<TCreateTransferResponse, TCreateTransferParam>({
      query: ({ token, body }) => ({
        url: rootUrl({ endpoints: ['in'] }).path,
        method: 'POST',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: invalidatesTags.transfer,
    }),
    acceptTransfer: builder.mutation<TAcceptTransferResponse, TAcceptTransferParam>({
      query: ({ token, body }) => ({
        url: rootUrl({ endpoints: ['client', 'accept'] }).path,
        method: 'POST',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: invalidatesTags.transfer,
    }),
    rejectTransfer: builder.mutation<TRejectTransferResponse, TRejectTransferParam>({
      query: ({ token, body }) => ({
        url: rootUrl({ endpoints: ['client', 'reject'] }).path,
        method: 'POST',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: invalidatesTags.transfer,
    }),
    cancleTransfer: builder.mutation<TCancleTransferResponse, TCancleTransferParam>({
      query: ({ token, body }) => ({
        url: rootUrl({ endpoints: ['client', 'cancel'] }).path,
        method: 'POST',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: invalidatesTags.transfer,
    }),
  }),
});

export const {
  useGetAllTransferQuery,
  useGetOneTransferQuery,
  useAcceptTransferMutation,
  useRejectTransferMutation,
  useCreateTransferMutation,
  useCancleTransferMutation,
} = transferApi;
