import { TBaseApiResponseData } from '@/lib/types/base-response.type';
import { TBaseRequestParams } from '@/lib/types/common.type';
import { TBaseResponseData } from '@/lib/types/formatted.types';
import { TShowroomsItem } from '../showrooms/showrooms.type';
import { LangEnum } from '@/lib/types/lang.type';
import { CombineLangSuffixFields } from '@/lib/types/custom-utility.type';

export type TTransferStatus = 'pending' | 'accepted' | 'rejected' | 'partially' | 'cancelled';
export type TTransferType = 'out' | 'in';

type MultiLangFileds = CombineLangSuffixFields<
  ['sub_category_name' | 'product_colour_name' | 'product_name'],
  LangEnum
>;

export type TTransferInnerItem = {
  product_id: string;
  product_barcode: string;
  origin_price: string;
  sale_price: string;
  marga: string;
  requested_quantity: string;
  accepted_quantity: string;
  rejected_quantity: string;
  reason: null | string;
  product_colour_code: null | string | number;
  status: string;
} & MultiLangFileds;

// data item
export type TTransferItem = Pick<TBaseApiResponseData, 'id' | 'created_at' | 'updated_at'> & {
  status: TTransferStatus;
  showroom: Pick<TShowroomsItem, 'id' | 'name'>;
  items: TTransferInnerItem[];
};

// data list
export type TTransferList = TTransferItem[];

// HTTPS 🚀

type TTransferBody = {
  transfer: { id: string };
  items: {
    product: {
      id: string;
    };
    quantity: number;
    reason?: string;
  }[];
};

// GetAll 🔵
export type TGetAllTransferResponse = TBaseResponseData<TTransferList>;
export type TGetAllTransferParam = Pick<
  TBaseRequestParams,
  | 'token'
  | 'showroom_id'
  | 'page'
  | 'page_size'
  | 'pagination'
  | 'search'
  | 'created_at_from'
  | 'created_at_to'
> & {
  status?: TTransferStatus;
};

// GetOne 🔵
export type TGetOneTransferResponse = TBaseResponseData<TTransferItem>;
export type TGetOneTransferParam = Pick<TBaseRequestParams, 'token' | 'id'>;

// Create 🟡
export type TCreateTransferResponse = TBaseResponseData<[] | {}>;
export type TCreateTransferBody = Pick<TTransferBody, 'items'>;
export type TCreateTransferForm = TCreateTransferBody;
export type TCreateTransferParam = Pick<TBaseRequestParams<TCreateTransferBody>, 'token' | 'body'>;

// Reject 🟡
export type TRejectTransferResponse = TBaseResponseData<[] | {}>;
export type TRejectTransferBody = TTransferBody;
export type TRejectTransferForm = TRejectTransferBody;
export type TRejectTransferParam = Pick<TBaseRequestParams<TRejectTransferBody>, 'token' | 'body'>;

// Accept 🟡
export type TAcceptTransferResponse = TBaseResponseData<[] | {}>;
export type TAcceptTransferBody = TTransferBody;
export type TAcceptTransferForm = TAcceptTransferBody;
export type TAcceptTransferParam = Pick<TBaseRequestParams<TAcceptTransferBody>, 'token' | 'body'>;

// Cancle 🟡
export type TCancleTransferResponse = TBaseResponseData<[] | {}>;
export type TCancleTransferBody = {
  transfer: { id: string };
  reason: string;
};
export type TCancleTransferForm = TCancleTransferBody;
export type TCancleTransferParam = Pick<TBaseRequestParams<TCancleTransferBody>, 'token' | 'body'>;
