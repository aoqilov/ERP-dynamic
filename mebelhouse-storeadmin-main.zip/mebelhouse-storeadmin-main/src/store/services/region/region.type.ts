import { TBaseApiResponseData } from '@/lib/types/base-response.type';
import { TBaseRequestParams } from '@/lib/types/common.type';
import { CombineLangSuffixFields, Expand } from '@/lib/types/custom-utility.type';
import { TBaseResponseData } from '@/lib/types/formatted.types';
import { LangEnum } from '@/lib/types/lang.type';

export type TRegionLangFields = ['name'];
type TMultiLangFields = CombineLangSuffixFields<TRegionLangFields, LangEnum>;
// data item
export type TRegionItem = Expand<TBaseApiResponseData & {} & TMultiLangFields>;

// data list
export type TRegionList = TRegionItem[];

// HTTPS 🚀

// GetAll 🔵
export type TGetAllRegionResponse = TBaseResponseData<TRegionList>;
export type TGetAllRegionParam = void;

// GetOne 🔵
export type TGetOneRegionResponse = TBaseResponseData<TRegionItem>;
export type TGetOneRegionParam = Pick<TBaseRequestParams, 'token' | 'id'>;

// Create 🟢
export type TCreateRegionResponse = TBaseResponseData<TRegionItem>;
export type TCreateRegionBody = TMultiLangFields & {};
export type TCreateRegionForm = TCreateRegionBody;
export type TCreateRegionParam = Pick<TBaseRequestParams<TCreateRegionBody>, 'token' | 'body'>;

// Update 🟡
export type TUpdateRegionResponse = TBaseResponseData<TRegionItem>;
export type TUpdateRegionBody = TMultiLangFields & {};
export type TUpdateRegionForm = TUpdateRegionBody;
export type TUpdateRegionParam = Pick<TBaseRequestParams<TUpdateRegionBody>, 'token' | 'body' | 'id'>;

// Delete 🔴
export type TDeleteRegionResponse = TBaseResponseData<TRegionItem>;
export type TDeleteRegionParam = Pick<TBaseRequestParams, 'token' | 'id'>;
