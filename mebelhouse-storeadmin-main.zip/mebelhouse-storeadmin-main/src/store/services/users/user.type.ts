import { TBaseRequestParams } from '@/lib/types/common.type';
import { CombineLangSuffixFields } from '@/lib/types/custom-utility.type';
import { TBaseResponseData } from '@/lib/types/formatted.types';
import { LangEnum } from '@/lib/types/lang.type';

export type TUserLangFields = ['title', 'subtitle'];

// data
export type TUser = {
  userName: string;
} & CombineLangSuffixFields<TUserLangFields, LangEnum>;

// data list
export type TUsers = TUser[];

// request body
export type TUserBody = {};

// request Form
export type TUserForm = TUserBody & {};

// HTTPS 🚀

// GetAll 🔵
export type TGetAllUsersResponse = TBaseResponseData<TUsers>;
export type TGetAllUsersParam = Pick<TBaseRequestParams, 'token'>;
// GetOne 🔵
export type TGetOneUserResponse = TBaseResponseData<TUser>;
export type TGetOneUserParam = Pick<TBaseRequestParams, 'token' | 'id'>;
// Create 🟢
export type TCreateUserResponse = TBaseResponseData<TUser>;
export type TCreateUserParam = Pick<TBaseRequestParams<TUserBody>, 'token' | 'body'>;
// Update 🟡
export type TUpdateUserResponse = TBaseResponseData<TUser>;
export type TUpdateUserParam = Pick<TBaseRequestParams<TUserBody>, 'token' | 'body' | 'id'>;
// Delete 🔴
export type TDeleteUserResponse = TBaseResponseData<TUser>;
export type TDeleteUserParam = Pick<TBaseRequestParams, 'token' | 'id'>;
