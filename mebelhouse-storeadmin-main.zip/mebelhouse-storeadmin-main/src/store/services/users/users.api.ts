import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { SERVER_URL } from '@/lib/consts/url.consts';
import { createUrl } from '@/lib/utils/formatters/formatter-url/url-builder';
import { createInvalidatesTags, getHeaderAuthorization } from '../api.helpers';

import {
  TCreateUserParam,
  TCreateUserResponse,
  TDeleteUserParam,
  TDeleteUserResponse,
  TGetAllUsersParam,
  TGetAllUsersResponse,
  TUpdateUserParam,
  TUpdateUserResponse,
} from './user.type';

// consts
const BASE_URL = SERVER_URL;
const REDUCER_PATH = 'users';
const BASE_PATH = '/user';
const ROOT_TAG_TYPE = 'users' as const;
const TAG_TYPES = [ROOT_TAG_TYPE, 'test'] as const;

const invalidatesTags = createInvalidatesTags(TAG_TYPES);

const rootUrl = createUrl({
  baseUrl: BASE_URL,
  basePath: [BASE_PATH],
});

export const usersApi = createApi({
  reducerPath: REDUCER_PATH,
  tagTypes: TAG_TYPES,
  baseQuery: fetchBaseQuery({ baseUrl: rootUrl().origin }),
  endpoints: (builder) => ({
    getUsers: builder.query<TGetAllUsersResponse, TGetAllUsersParam>({
      query: ({ token }) => ({
        url: rootUrl().path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result) =>
        result
          ? [
              ...(result.data?.map(({ id }) => ({
                type: ROOT_TAG_TYPE,
                id,
              })) || []),
              ...invalidatesTags.users,
            ]
          : invalidatesTags.users,
    }),
    createUser: builder.mutation<TCreateUserResponse, TCreateUserParam>({
      query: ({ body, token }) => ({
        url: rootUrl().path,
        method: 'POST',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: invalidatesTags.users,
    }),
    updateSelfAccount: builder.mutation<TUpdateUserResponse, TUpdateUserParam>({
      query: ({ token, body }) => ({
        url: rootUrl({ endpoints: ['ex'], queryParams: { id: '' } }).path,
        method: 'PATCH',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: invalidatesTags.users,
    }),
    deleteSelfUser: builder.mutation<TDeleteUserResponse, TDeleteUserParam>({
      query: ({ id, token }) => ({
        url: rootUrl({ endpoints: ['my', id] }).path,
        method: 'DELETE',
        headers: getHeaderAuthorization(token),
      }),
      invalidatesTags: invalidatesTags.users,
    }),
  }),
});
export const {
  useGetUsersQuery,
  useCreateUserMutation,
  useDeleteSelfUserMutation,
  useUpdateSelfAccountMutation,
} = usersApi;
