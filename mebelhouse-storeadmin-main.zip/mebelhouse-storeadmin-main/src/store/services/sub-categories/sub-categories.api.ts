import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { SERVER_URL } from '@/lib/consts/url.consts';
import { createUrl } from '@/lib/utils/formatters/formatter-url/url-builder';
import { createInvalidatesTags, getHeaderAuthorization } from '../api.helpers';
import {
  TCreateSubCategoriesParam,
  TCreateSubCategoriesResponse,
  TDeleteSubCategoriesParam,
  TDeleteSubCategoriesResponse,
  TGetAllSubCategoriesResponse,
  TGetOneSubCategoriesParam,
  TGetOneSubCategoriesResponse,
  TUpdateSubCategoriesParam,
  TUpdateSubCategoriesResponse,
} from './sub-categories.type';

// consts
const BASE_URL = SERVER_URL;
const REDUCER_PATH = 'subcategoriesApi';
const BASE_PATH = '/client/subcategories';
const ROOT_TAG_TYPE = 'subcategories' as const;
const TAG_TYPES = [ROOT_TAG_TYPE] as const;

const invalidatesTags = createInvalidatesTags(TAG_TYPES);

const rootUrl = createUrl({
  baseUrl: BASE_URL,
  basePath: [BASE_PATH],
});

export const subcategoriesApi = createApi({
  reducerPath: REDUCER_PATH,
  tagTypes: TAG_TYPES,
  baseQuery: fetchBaseQuery({ baseUrl: rootUrl().origin }),
  endpoints: (builder) => ({
    getAllSubCategories: builder.query<TGetAllSubCategoriesResponse, { token: string }>({
      query: ({ token }) => ({
        url: rootUrl().path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result) =>
        result
          ? [
              ...(result?.data || []).map(({ id }) => ({
                type: ROOT_TAG_TYPE,
                id,
              })),
              ...invalidatesTags.subcategories,
            ]
          : invalidatesTags.subcategories,
    }),
    getOneSubCategories: builder.query<TGetOneSubCategoriesResponse, TGetOneSubCategoriesParam>({
      query: ({ token, id }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        headers: getHeaderAuthorization(token),
      }),
      providesTags: (result, _, { id }) => [
        { type: ROOT_TAG_TYPE, id },
        ...(result ? invalidatesTags.subcategories : []),
      ],
    }),
    createSubCategories: builder.mutation<TCreateSubCategoriesResponse, TCreateSubCategoriesParam>({
      query: ({ body, token }) => ({
        url: rootUrl().path,
        method: 'POST',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: invalidatesTags.subcategories,
    }),
    updateSubCategories: builder.mutation<TUpdateSubCategoriesResponse, TUpdateSubCategoriesParam>({
      query: ({ token, body, id }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        method: 'PATCH',
        headers: getHeaderAuthorization(token),
        body,
      }),
      invalidatesTags: invalidatesTags.subcategories,
    }),
    deleteSubCategories: builder.mutation<TDeleteSubCategoriesResponse, TDeleteSubCategoriesParam>({
      query: ({ id, token }) => ({
        url: rootUrl({ endpoints: [id] }).path,
        method: 'DELETE',
        headers: getHeaderAuthorization(token),
      }),
      invalidatesTags: invalidatesTags.subcategories,
    }),
  }),
});

export const {
  useGetAllSubCategoriesQuery,
  useGetOneSubCategoriesQuery,
  useCreateSubCategoriesMutation,
  useUpdateSubCategoriesMutation,
  useDeleteSubCategoriesMutation,
} = subcategoriesApi;
