import { TBaseApiResponseData } from '@/lib/types/base-response.type';
import { TBaseRequestParams } from '@/lib/types/common.type';
import { CombineLangSuffixFields, Expand } from '@/lib/types/custom-utility.type';
import { TBaseResponseData } from '@/lib/types/formatted.types';
import { LangEnum } from '@/lib/types/lang.type';
import { TCategoriesItem } from '../categories/categories.type';
import { PictureItemType } from '@/lib/types/files.type';

export type TSubCategoriesLangFields = ['name'];
type TMultiLangKeys = CombineLangSuffixFields<TSubCategoriesLangFields, LangEnum>;

// data item
export type TSubCategoriesItem = Expand<
  TBaseApiResponseData & {
    position: number;
    picture: PictureItemType;
    category: TCategoriesItem;
  } & TMultiLangKeys
>;

// data list
export type TSubCategoriesList = TSubCategoriesItem[];

// HTTPS 🚀

// GetAll 🔵
export type TGetAllSubCategoriesResponse = TBaseResponseData<TSubCategoriesList>;

export type TGetAllSubCategoriesParam = Pick<TBaseRequestParams, 'token'>;

// GetOne 🔵
export type TGetOneSubCategoriesResponse = TBaseResponseData<TSubCategoriesItem>;
export type TGetOneSubCategoriesParam = Pick<TBaseRequestParams, 'token' | 'id'>;

// Create 🟢
export type TCreateSubCategoriesResponse = TBaseResponseData<TSubCategoriesItem>;
export type TCreateSubCategoriesBody = Pick<
  TSubCategoriesItem,
  'position' | keyof TMultiLangKeys
> & { category: number };
export type TCreateSubCategoriesForm = TCreateSubCategoriesBody;
export type TCreateSubCategoriesParam = Pick<
  TBaseRequestParams<TCreateSubCategoriesBody>,
  'token' | 'body'
>;

// Update 🟡
export type TUpdateSubCategoriesResponse = TBaseResponseData<TSubCategoriesItem>;
export type TUpdateSubCategoriesBody = Pick<TSubCategoriesItem, 'position' | keyof TMultiLangKeys>;
export type TUpdateSubCategoriesForm = TUpdateSubCategoriesBody;
export type TUpdateSubCategoriesParam = Pick<
  TBaseRequestParams<TUpdateSubCategoriesBody>,
  'token' | 'body' | 'id'
>;

// Delete 🔴
export type TDeleteSubCategoriesResponse = TBaseResponseData<TSubCategoriesItem>;
export type TDeleteSubCategoriesParam = Pick<TBaseRequestParams, 'token' | 'id'>;
