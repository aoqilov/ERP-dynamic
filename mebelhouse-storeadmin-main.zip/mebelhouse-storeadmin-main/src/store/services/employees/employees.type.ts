import { TBaseRequestParams } from '@/lib/types/common.type';
import { TBaseResponseData } from '@/lib/types/formatted.types';
import { TShowroomsItem } from '../showrooms/showrooms.type';

export type TEmployeesLangFields = ['name'];

export enum GendersType {
  'male' = 'male',
  'female' = 'female',
}
export enum Roles {
  cashier = 'cashier',
  sales = 'sales',
}

export type TCourierItem = {
  id: string;
  car_number: string;
  car_model: string;
  car_brand: string;
};

// data item
export type TEmployeesItem = {
  id?: string;
  first_name: string;
  last_name: string;
  gender: GendersType;
  birth_date: number | null;
  phone_number: string;
  role: Roles;
  username: string;
  password: string;
  showroom_executer: { id: string; showroom: TShowroomsItem & { id: string } }[];
  curier?: TCourierItem;
};

// data list
export type TEmployeesList = TEmployeesItem[];

// HTTPS 🚀

// GetAll 🔵
export type TGetAllEmployeesResponse = TBaseResponseData<TEmployeesList>;

export type TGetAllEmployeesParam = Pick<TBaseRequestParams, 'token' | 'search' | 'page_size' | 'page'> & {
  role: Roles;
};

// GetOne 🔵
export type TGetOneEmployeesResponse = TBaseResponseData<TEmployeesItem>;
export type TGetOneEmployeesParam = Pick<TBaseRequestParams, 'token' | 'id'>;

// Create 🟢
export type TCreateEmployeesResponse = TBaseResponseData<TEmployeesItem>;
export type TCreateEmployeesBody = Omit<TEmployeesItem, 'birth_date' | 'showroom_executer'> & {
  username: string;
  car_number?: string;
  car_model?: string;
  car_brand?: string;
};
export type TCreateEmployeesForm = TCreateEmployeesBody;
export type TCreateEmployeesParam = Pick<
  TBaseRequestParams<TCreateEmployeesBody>,
  'token' | 'body'
>;

// Update 🟡
export type TUpdateEmployeesResponse = TBaseResponseData<TEmployeesItem>;
export type TUpdateEmployeesBody = Partial<Omit<TEmployeesItem, 'birth_date' | 'showroom_executer'> & {
  username: string;
  car_number?: string;
  car_model?: string;
  car_brand?: string;
}>;
export type TUpdateEmployeesForm = TUpdateEmployeesBody;
export type TUpdateEmployeesParam = Pick<
  TBaseRequestParams<TUpdateEmployeesBody>,
  'token' | 'body' | 'id'
>;

// Delete 🔴
export type TDeleteEmployeesResponse = TBaseResponseData<TEmployeesItem>;
export type TDeleteEmployeesParam = Pick<TBaseRequestParams, 'token' | 'id'>;
