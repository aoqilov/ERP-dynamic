import { TBaseRequestParams } from '@/lib/types/common.type';
import { Expand } from '@/lib/types/custom-utility.type';
import { TPaginatedResponse } from '@/lib/types/formatted.types';
import { TCashRegisterItem } from '../cash-regs/casg-regs.type';
import { Roles } from '../employees/employees.type';

export type TReturnQuantityType = {
  product_id: string;
  quantity: string;
  colour_name_uz: string;
  colour_name_ru: string;
};

export type TReturnCashierType = {
  id: string;
  first_name: string;
  last_name: string;
  role: Roles | 'cashier';
};

export type TReturnCashRegType = {
  id: string;
  first_name: string;
  last_name: string;
  role: Roles | 'cashier';
};

export type TReturnQuantity = {
  product_id: string;
  quantity: string;
  colour_name_uz: string;
  colour_name_ru: string;
};

export type TReturnProductsType = {
  id: string;
  product_name_uz: string;
  product_name_ru: string;
  category_name_uz: string;
  category_name_ru: string;
  bar_code: string;
  product_code: string;
  return_product_price: string;
  quantities: TReturnQuantity[];
};

export type TReturnItem = {
  id: string;
  created_at: string;
  reason: string;
  return_total_price: string;
  cashier: TReturnCashierType;
  cash_register: TCashRegisterItem;
  items: TReturnProductsType[];
  set?: {
    id: string;
    name: string;
  };
};

// data list
export type TReturnList = TReturnItem[];

// HTTPS 🚀

// GetAll 🔵
export type TGetAllReturnResponse = TPaginatedResponse<TReturnList>;
export type TGetAllReturnParam = Expand<
  Partial<
    Pick<
      TBaseRequestParams,
      'page_size' | 'page' | 'search' | 'created_at_from' | 'created_at_to' | 'token' | 'pagination'
    >
  >
>;
