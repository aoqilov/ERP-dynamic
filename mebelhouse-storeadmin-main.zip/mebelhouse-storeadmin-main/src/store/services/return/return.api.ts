import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { SERVER_URL } from '@/lib/consts/url.consts';
import { createUrl } from '@/lib/utils/formatters/formatter-url/url-builder';
import { createInvalidatesTags, getHeaderAuthorization } from '../api.helpers';
import { TGetAllReturnParam, TGetAllReturnResponse } from './return.type';

// consts
const BASE_URL = SERVER_URL;
const REDUCER_PATH = 'returnApi';
const BASE_PATH = '/return-order';
const ROOT_TAG_TYPE = 'returnLogs' as const;
const TAG_TYPES = [ROOT_TAG_TYPE] as const;

const invalidatesTags = createInvalidatesTags(TAG_TYPES);

const rootUrl = createUrl({
  baseUrl: BASE_URL,
  basePath: ['showroom', BASE_PATH],
});

export const returnApi = createApi({
  reducerPath: REDUCER_PATH,
  tagTypes: TAG_TYPES,
  baseQuery: fetchBaseQuery({ baseUrl: rootUrl().origin }),
  endpoints: (builder) => ({
    getAllProductsReturn: builder.query<
      TGetAllReturnResponse,
      TGetAllReturnParam & { sets?: boolean }
    >({
      query: ({ token, sets = false, ...queryParams }) => ({
        url: rootUrl({
          queryParams,
          endpoints: [sets ? 'sets' : ''],
        }).path,
        headers: getHeaderAuthorization(token!),
      }),
      providesTags: (result) =>
        result
          ? [
              ...(result?.data || []).map(({ id }) => ({
                type: ROOT_TAG_TYPE,
                id,
              })),
              ...invalidatesTags.returnLogs,
            ]
          : invalidatesTags.returnLogs,
      transformResponse(baseQueryReturnValue: TGetAllReturnResponse) {
        return Array.isArray(baseQueryReturnValue?.data)
          ? baseQueryReturnValue
          : { ...baseQueryReturnValue, data: [] };
      },
    }),
  }),
});

export const { useGetAllProductsReturnQuery } = returnApi;
