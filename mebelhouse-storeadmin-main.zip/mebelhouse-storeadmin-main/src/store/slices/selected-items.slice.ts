import { PayloadAction, createSlice } from '@reduxjs/toolkit';

export type SelectedItemsState = {
  selectedItems: React.Key[] | null;
};

const initialState: SelectedItemsState = {
  selectedItems: [],
};

const selectedItemsSlice = createSlice({
  name: 'selectedItems',
  initialState,
  reducers: {
    setSelectedItems(state, { payload }: PayloadAction<SelectedItemsState>) {
      state.selectedItems = payload.selectedItems;
    },
  },
});

export const { setSelectedItems } = selectedItemsSlice.actions;
export const selectedItemsReducer = selectedItemsSlice.reducer;
