import { PayloadAction, createSlice } from '@reduxjs/toolkit';
import { DefaultOptionType } from 'antd/es/select';

type SelectDataState = {
  data: DefaultOptionType[] | null;
};

const initialState: SelectDataState = {
  data: null,
};

const selectDataSlice = createSlice({
  name: 'selectData',
  initialState,
  reducers: {
    setSelectData(state, { payload }: PayloadAction<SelectDataState>) {
      state.data = payload.data;
    },
  },
});

export const { setSelectData } = selectDataSlice.actions;
export const selectDataReducer = selectDataSlice.reducer;
