import { PayloadAction, createSlice } from '@reduxjs/toolkit';

type FileState = {
  id: number | null;
};

const initialState: FileState = {
  id: null,
};

const fileSlice = createSlice({
  name: 'file',
  initialState,
  reducers: {
    setFile(state, { payload }: PayloadAction<number | null>) {
      state.id = payload;
    },
  },
});

export const { setFile } = fileSlice.actions;
export const fileReducer = fileSlice.reducer;
