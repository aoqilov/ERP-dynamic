import { langReducer } from './lang.slice';
import { sidebarReducer } from './sidebar.slice';
import { themeReducer } from './theme.slice';
import { authReducer } from './auth.slice';
import { modalReducer } from './modal.slice';
import { fileReducer } from './file.slice';
import { selectDataReducer } from './select-data.slice';
import { productsReducer } from './products.slice';
import { selectedItemsReducer } from './selected-items.slice';

export const sliceReducers = {
  lang: langReducer,
  sidebar: sidebarReducer,
  theme: themeReducer,
  auth: authReducer,
  modal: modalReducer,
  file: fileReducer,
  selectData: selectDataReducer,
  products: productsReducer,
  selectedItems: selectedItemsReducer,
};
