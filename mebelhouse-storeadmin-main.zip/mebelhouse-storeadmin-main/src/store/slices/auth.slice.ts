import { PayloadAction, createSlice } from '@reduxjs/toolkit';
import { TAuthItem } from '../services/auth/auth.type';

type AuthState = TAuthItem['data'] | null;

const initialState: AuthState = {
  token: '',
  first_name: '',
  id: '',
  last_name: '',
  phone_number: '',
  role: undefined,
  store_id: '',
  store_name: '',
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setAuth(state, { payload }: PayloadAction<AuthState>) {
      if (payload) {
        // When there is payload (i.e., login action), update the state
        return Object.assign(state, payload);
      } else {
        // Clear the state (i.e., logout action)
        return initialState;
      }
    },
    clearAuth() {
      return initialState;
    },
  },
});

export const { setAuth, clearAuth } = authSlice.actions;
export const authReducer = authSlice.reducer;
