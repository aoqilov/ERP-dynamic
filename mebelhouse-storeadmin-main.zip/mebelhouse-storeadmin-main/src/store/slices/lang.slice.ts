import { LangEnum } from '@/lib/types/lang.type';
import { PayloadAction, createSlice } from '@reduxjs/toolkit';

export type LangState = {
  lang: LangEnum;
};

const initialState: LangState = {
  lang: LangEnum.UZ,
};

export const langSlice = createSlice({
  name: 'lang',
  initialState,
  reducers: {
    setLang: (state, { payload }: PayloadAction<LangEnum>) => {
      state.lang = payload;
    },
  },
});

export const { setLang } = langSlice.actions;
export const langReducer = langSlice.reducer;
