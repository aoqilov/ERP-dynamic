import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { TProductIncomeItemList } from '../services/products/products.type';

type TransferStep = 'list' | 'store';

type TCodeValue = Partial<{
  barCode: string;
  productCode: string;
}>;

export type TProductBarCodePrint = {
  printIsOpen: boolean;
  printValue?: string;
};

type ProductsState = {
  transferStep: TransferStep;
  selectedProductsList: any;
  totalPrice: string;
  codeValue: TCodeValue;
  barCodePrint: TProductBarCodePrint;
};

const initialState: ProductsState = {
  transferStep: 'list',
  selectedProductsList: [],
  totalPrice: '',
  codeValue: { barCode: '', productCode: '' },
  barCodePrint: {
    printIsOpen: false,
    printValue: '',
  },
};

const productsSlice = createSlice({
  name: 'products',
  initialState,
  reducers: {
    // Updated reducer to accept only `transferStep`
    setTransferStep(state, { payload }: PayloadAction<TransferStep>) {
      state.transferStep = payload;
    },
    setSelectedProductsList(state, { payload }: PayloadAction<TProductIncomeItemList>) {
      state.selectedProductsList = payload;
    },
    setTotalPrice(state, { payload }: PayloadAction<ProductsState['totalPrice']>) {
      state.totalPrice = payload;
    },
    setCodeValue(state, { payload }: PayloadAction<TCodeValue>) {
      state.codeValue = {
        ...state.codeValue, // Keep the existing values
        ...payload, // Merge with the new values
      };
    },
    setBarCodePrint(state, { payload }: PayloadAction<TProductBarCodePrint>) {
      state.barCodePrint = {
        ...state.barCodePrint,
        ...payload,
      };
    },
    clearCodeValues(state) {
      {
        (state.codeValue.barCode = ''), (state.codeValue.productCode = '');
      }
    },
  },
});

export const {
  setTransferStep,
  setSelectedProductsList,
  setTotalPrice,
  setCodeValue,
  clearCodeValues,
  setBarCodePrint,
} = productsSlice.actions;
export const productsReducer = productsSlice.reducer;
