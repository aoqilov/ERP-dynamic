import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export type ComponentsNameType =
  | 'stores'
  | 'categories'
  | 'subCategory'
  | 'brand'
  | 'region'
  | 'color'
  | 'productLists'
  | 'productsIncome'
  | 'productsWriteOff'
  | 'productsTransfer'
  | 'excel'
  | 'excelUpload'
  | 'employee'
  | 'store'
  | 'productListsMulti'
  | 'productsIncomeMulti'
  | 'productsSet'
  | '';

export type ModalState = {
  modalIsOpen?: boolean;
  id?: string | string[] | null;
  modalType?: {
    style: 'form' | 'delete' | 'view';
    manipulation?: 'add' | 'edit';
    component: ComponentsNameType;
  } | null;
  data?: any;
};

const initialState: ModalState = {
  modalIsOpen: false,
  id: null,
  modalType: null,
  data: null,
};

const modalSlice = createSlice({
  name: 'modal',
  initialState,
  reducers: {
    openModal(state, { payload }: PayloadAction<ModalState>) {
      state.modalIsOpen = true;
      state.id = payload.id;
      state.modalType = payload.modalType;
      state.data = payload.data;
    },
    closeModal(state) {
      state.modalIsOpen = false;
      state.modalType = null;
    },
  },
});

export const { openModal, closeModal } = modalSlice.actions;
export const modalReducer = modalSlice.reducer;
