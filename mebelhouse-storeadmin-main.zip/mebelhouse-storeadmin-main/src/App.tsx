import { BrowserRouter } from 'react-router-dom';
import './assets/styles/fonts.css';
import './assets/styles/globals.css';
import './assets/styles/reset.css';
import './assets/styles/variables.css';
import './i18n';
import { Routes } from './routes';

function App() {
  return (
    <BrowserRouter>
      <Routes />
    </BrowserRouter>
  );
}

export default App;
