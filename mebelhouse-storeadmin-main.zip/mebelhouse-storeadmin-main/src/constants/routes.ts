export const PUBLIC_ROUTES = {
  login: '/login',
};

export const PROTECTED_ROUTES = {
  home: '/',
  employees: '/employees',
  warehouse: '/warehouse',
};

export const ROUTES = {
  ...PUBLIC_ROUTES,
  ...PROTECTED_ROUTES,
};
