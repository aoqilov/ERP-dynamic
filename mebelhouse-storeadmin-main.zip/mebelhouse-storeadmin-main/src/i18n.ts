import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

import ruTranslation from '../locales/ru.json';
import uzTranslation from '../locales/uz.json';

export const locales = ['ru', 'uz'] as const;
export type Locale = (typeof locales)[number];

i18n.use(initReactI18next).init({
  fallbackLng: 'ru',
  resources: {
    ru: {
      translation: ruTranslation,
    },
    uz: {
      translation: uzTranslation,
    },
  },
});

export default i18n;
