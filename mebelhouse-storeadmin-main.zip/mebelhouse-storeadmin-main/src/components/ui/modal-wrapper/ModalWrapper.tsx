import { ModalStyleType } from '@/lib/types/common.type';
import { useAppDispatch } from '@/store/reduxHooks';
import { closeModal } from '@/store/slices/modal.slice';
import { FormProps, Modal, ModalProps } from 'antd';
import { ButtonProps } from 'antd/lib';
import clsx from 'clsx';
import { ReactNode } from 'react';
import FormContent from '../form-content/FormContent';
import './modal-wrapper.css';

type ModalWrapperProps = ModalProps & {
  modalTitle?: string;
  styleType?: ModalStyleType;
  btnContent?: string;
  btnProps?: ButtonProps;
  formProps?: FormProps;
  children: ReactNode;
};

const ModalWrapper = ({
  modalTitle,
  children,
  styleType = 'default',
  btnProps,
  btnContent,
  formProps,
  styles,
  ...modalProps
}: ModalWrapperProps) => {
  const dispatch = useAppDispatch();
  const handleCancel = () => {
    dispatch(closeModal());
  };

  return (
    <Modal
      footer={null}
      classNames={{
        content: clsx('modal-content', {
          'modal-content-single-btn': styleType === 'singleBtn',
        }),
      }}
      styles={{
        ...styles,
        mask: { backdropFilter: 'blur(1px)', backgroundColor: '#00000010', ...styles?.mask },
      }}
      open={true}
      onCancel={handleCancel}
      {...modalProps}
    >
      <FormContent
        formProps={{ ...formProps }}
        btnContent={btnContent}
        btnProps={{ ...btnProps }}
        modalTitle={modalTitle}
        styleType={styleType}
      >
        {children}
      </FormContent>
    </Modal>
  );
};

export default ModalWrapper;
