import { FC } from 'react';
import { DatePicker } from 'antd';
import { RangePickerProps } from 'antd/lib/date-picker';
import { ICalendar } from '@/components/svgs/svgs';
import dayjs from 'dayjs';
import { t } from 'i18next';
import './my-date-picker.css';

const { RangePicker } = DatePicker;

type MyRangePickerProps = {
  rangePickerProps?: RangePickerProps;
  setDates?: (v: [number | null, number | null]) => void;
};

const MyRangePicker: FC<MyRangePickerProps> = ({ rangePickerProps, setDates }) => {
  const handleDateChange = (dates: [dayjs.Dayjs | null, dayjs.Dayjs | null] | null) => {
    if (dates) {
      const [start, end] = dates;

      const startTimestamp = start ? start.valueOf() : null; // Convert to timestamp
      const endTimestamp = end ? end.valueOf() : null; // Convert to timestamp
      setDates?.([startTimestamp, endTimestamp]);
    } else {
      setDates?.([null, null])    }
  };

  return (
    <RangePicker
      placeholder={[t('Common.Period'), '']}
      suffixIcon={<ICalendar />}
      className="my-date-picker"
      {...rangePickerProps}
      onChange={handleDateChange}
    />
  );
};

export default MyRangePicker;

