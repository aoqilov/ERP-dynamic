//@ts-nocheck

import { ConfigProvider, PaginationProps, Table, TableProps } from 'antd';
import { TableColumnsType } from 'antd/lib'; // Use 'antd/es/table' for better typing
import MyPagination from '../MyPagination/MyPagination';

type MyTableProps<T> = {
  dataSource: T[];
  columns: TableColumnsType<T>;
  paginationProps?: PaginationProps | null;
  tableProps?: TableProps<T>; // Specify the type of tableProps as TableProps<T> and make it optional if needed
};

const MyTable = <T,>({ dataSource, columns, tableProps, paginationProps }: MyTableProps<T>) => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      <ConfigProvider
        theme={{
          components: {
            Table: {
              headerBg: '#FAFAFA',
              headerBorderRadius: 0,
              borderColor: '#E9EAEC',
            },
          },
        }}
      >
        <Table pagination={false} dataSource={dataSource} columns={columns} {...tableProps} />
        {paginationProps && dataSource?.length > 0 && (
          <MyPagination paginationProps={paginationProps} />
        )}
      </ConfigProvider>
    </div>
  );
};

export default MyTable;
