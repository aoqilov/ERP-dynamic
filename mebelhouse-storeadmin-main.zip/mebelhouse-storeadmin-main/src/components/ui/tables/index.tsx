import { Collapse, CollapseProps, Flex, PaginationProps, TableProps } from 'antd';
import { TableColumnsType } from 'antd/lib';
import React from 'react';
import MyTable from './MyTable/MyTable';
import MyTableTitles from './MyTableTitles/MyTableTitles';
import MyPagination from './MyPagination/MyPagination';

type MyTableWrapperProps<T> = {
  topHeader?: React.ReactNode;
  header?: React.ReactNode;
  tableTitles?: { title: string; subTitle: string };
  dataSource: T[];
  columns: TableColumnsType<T>;
  tableProps?: TableProps<T>;
  paginationProps?: PaginationProps | null;
  isCollapse?: boolean;
  collapseItems?: CollapseProps['items'];
};

const MyTableBox = <T,>({
  topHeader,
  header,
  columns,
  tableProps,
  dataSource,
  tableTitles,
  isCollapse,
  collapseItems,
  paginationProps,
}: MyTableWrapperProps<T>) => {
  const { title, subTitle } = tableTitles ?? {};

  return (
    <div>
      <Flex style={{ marginBottom: 24 }} justify={topHeader ? 'space-between' : 'flex-start'}>
        <MyTableTitles title={title || ''} subTitle={subTitle || ''} />
        {topHeader}
      </Flex>

      {header}
      {isCollapse ? (
        <>
          <Collapse size="small" items={collapseItems} />
          {paginationProps && dataSource?.length > 0 && (
            <div style={{ marginTop: 24 }}>
              <MyPagination paginationProps={paginationProps} />
            </div>
          )}
        </>
      ) : (
        <MyTable
          paginationProps={paginationProps || null}
          tableProps={tableProps}
          columns={columns}
          dataSource={dataSource}
        />
      )}
    </div>
  );
};

export default MyTableBox;
