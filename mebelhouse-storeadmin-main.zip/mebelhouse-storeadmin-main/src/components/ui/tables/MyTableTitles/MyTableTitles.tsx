import { Typography, Flex } from 'antd';
import './my-table-titles.css';
const { Title, Paragraph } = Typography;

type MyTableTitlesProps = {
  title: string;
  subTitle: string;
};

const MyTableTitles = ({ title, subTitle }: MyTableTitlesProps) => {
  return (
    <Flex vertical>
      <Title style={{ marginBottom: 8 }} className="table-title" level={2}>
        {title}
      </Title>

      <Paragraph style={{ marginBottom: 0 }} className="table-sub-title" type="secondary">
        {subTitle}
      </Paragraph>
    </Flex>
  );
};

export default MyTableTitles;
