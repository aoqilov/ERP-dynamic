import { Locale } from '@/i18n';
import useQueryParams from '@/lib/hooks/useQueryParams';
import { ConfigProvider, Flex, Pagination, PaginationProps, Typography } from 'antd';
import { useTranslation } from 'react-i18next';

type MyPaginationProps = {
  defaultCurrent?: number;
  total?: number;
  paginationProps?: PaginationProps;
};

const MyPagination = ({}: MyPaginationProps) => {
  const {
    i18n: { language },
  } = useTranslation();

  const { getParam, setParams } = useQueryParams();

  // Fetch pagination data from query params
  const totalElements = +(getParam('total_elements') || 1) || 50;
  const from = +(getParam('from') || 1) || null;
  const to = +(getParam('to') || 1) || null;

  // Viewer info based on the language
  const infoViewer = () => {
    const infoObj = {
      uz: `${from} dan ${to} gacha ${totalElements} ta yozuv ko'rsatilmoqda`,
      ru: `Показано с ${from} по ${to} из ${totalElements} записей`,
    };

    return infoObj[language as Locale];
  };

  const pageSize = Number(getParam('page_size') || 10); // Default to 10 if not in query params

  // Handle page change
  // const onChange: PaginationProps['onChange'] = (page, pageSize) => {
  //   setParams({ current_page: String(page), page_size: String(pageSize) });
  // };

  // // Handle page size change
  // const onShowSizeChange: PaginationProps['onShowSizeChange'] = (current, pageSize) => {
  //   setParams({ current_page: String(current), page_size: String(pageSize) });
  // };

  const onChange: PaginationProps['onChange'] = (page, pageSize) => {
    setParams({ current_page: String(page), page_size: String(pageSize) });
  };

  const onShowSizeChange: PaginationProps['onShowSizeChange'] = (current, pageSize) => {
    setParams({ current_page: String(current), page_size: String(pageSize) });
  };

  return (
    <Flex justify="space-between" wrap align="center" gap={16}>
      <ConfigProvider
        theme={{
          components: {
            Pagination: {
              itemActiveBg: '#F8F8F8',
            },
          },
        }}
      >
        <Pagination
          showSizeChanger
          onShowSizeChange={onShowSizeChange}
          pageSize={pageSize}
          current={Number(getParam('current_page') || 1)}
          onChange={onChange}
          defaultCurrent={1}
          total={totalElements}
          style={{
            fontWeight: 600,
          }}
        />
        <Typography.Text>{infoViewer()}</Typography.Text>
      </ConfigProvider>
    </Flex>
  );
};

export default MyPagination;
