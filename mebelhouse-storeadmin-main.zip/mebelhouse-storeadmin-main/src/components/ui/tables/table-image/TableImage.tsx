import { SERVER_URL } from '@/lib/consts/url.consts';
import { PictureItemType } from '@/lib/types/files.type';
import { removeLastSegments } from '@/lib/utils/common-utils';
import { Image, ImageProps } from 'antd';
import { FC } from 'react';
import { AiOutlineEye } from 'react-icons/ai';

type Props = {
  imgProps: ImageProps;
  images?: PictureItemType[];
};

const TableImage: FC<Props> = ({ imgProps, images = [] }) => {
  const preview = typeof imgProps?.preview === 'boolean' ? {} : imgProps?.preview;

  const imagesList = images.map((item) => {
    return `${removeLastSegments(SERVER_URL, 2)}/images/${item?.path}`;
  });

  if (images.length < 2) {
    return (
      <Image
        style={{ width: 40, height: 40, objectFit: 'contain' }}
        wrapperStyle={{ borderRadius: '8px', overflow: 'hidden' }}
        fallback="/placeHolder.png"
        {...imgProps}
        preview={{ mask: <AiOutlineEye style={{ fontSize: 16 }} />, ...preview }}
      />
    );
  } else {
    return (
      <Image.PreviewGroup items={imagesList}>
        {/* Render the first image as the main image */}
        <Image
          style={{ width: 40, height: 40, objectFit: 'contain' }}
          wrapperStyle={{ borderRadius: '8px', overflow: 'hidden' }}
          src={imagesList[0] ?? '/placeHolder.png'}
          alt={imgProps?.alt}
          fallback="/placeHolder.png"
          preview={{ mask: <AiOutlineEye style={{ fontSize: 16 }} />, ...preview }}
        />
        {/* Render the remaining images for preview, but not visible by default */}
        {/* {images.slice(1).map((src, index) => (
          <Image
            key={index}
            src={`${removeLastSegments(SERVER_URL, 2)}/images/${src}`}
            style={{ display: 'none' }}
          />
        ))} */}
      </Image.PreviewGroup>
    );
  }
};

export default TableImage;
