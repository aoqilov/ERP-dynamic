import { HolderOutlined } from '@ant-design/icons';
import type { DragEndEvent } from '@dnd-kit/core';
import { DndContext } from '@dnd-kit/core';
import type { SyntheticListenerMap } from '@dnd-kit/core/dist/hooks/utilities';
import { restrictToVerticalAxis } from '@dnd-kit/modifiers';
import {
  arrayMove,
  SortableContext,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import type { TableColumnsType, TableProps } from 'antd';
import { Button, Table } from 'antd';
import {
  createContext,
  CSSProperties,
  FC,
  HTMLAttributes,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';

interface RowContextProps {
  setActivatorNodeRef?: (element: HTMLElement | null) => void;
  listeners?: SyntheticListenerMap;
}

const RowContext = createContext<RowContextProps>({});

const DragHandle: FC = () => {
  const { setActivatorNodeRef, listeners } = useContext(RowContext);
  return (
    <Button
      type="text"
      size="small"
      icon={<HolderOutlined />}
      style={{ cursor: 'move' }}
      ref={setActivatorNodeRef}
      {...listeners}
    />
  );
};

interface RowProps extends HTMLAttributes<HTMLTableRowElement> {
  'data-row-key': string;
}

const Row: FC<RowProps> = (props) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    setActivatorNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: props['data-row-key'] });

  const style: CSSProperties = {
    ...props.style,
    transform: CSS.Translate.toString(transform),
    transition,
    ...(isDragging ? { position: 'relative', zIndex: 9999 } : {}),
  };

  const contextValue = useMemo<RowContextProps>(
    () => ({ setActivatorNodeRef, listeners }),
    [setActivatorNodeRef, listeners],
  );

  return (
    <RowContext.Provider value={contextValue}>
      <tr {...props} ref={setNodeRef} style={style} {...attributes} />
    </RowContext.Provider>
  );
};

export type DraggedInfo = { id: number | string; index: number }

type SetDragged = (params: DraggedInfo) => void;

const DraggableTable = <T extends { id: string | number }>({
  rowKey,
  components,
  dataSource: propsDataSource = [],
  columns: propsColumn = [],
  setDragged,
  ...restProps
}: TableProps<T> & { setDragged: SetDragged }) => {
  const [dataSource, setDataSource] = useState<T[]>([...propsDataSource]);

  const [columnWithDrag, setColumnWithDrag] = useState<TableColumnsType<T>>(propsColumn);

  useEffect(() => {
    if (columnWithDrag?.[0]?.key !== 'sort') {
      setColumnWithDrag((prev) => [
        { key: 'sort', align: 'center', width: 60, render: () => <DragHandle /> },
        Table.EXPAND_COLUMN,
        ...prev,
      ]);
    }
  }, []);

  const onDragEnd = ({ active, over }: DragEndEvent) => {
    if (active.id !== over?.id) {
      setDataSource((prevState) => {
        const activeIndex = prevState.findIndex((record) => record?.id === active?.id);
        const overIndex = prevState.findIndex((record) => record?.id === over?.id);
        setDragged({ id: active?.id, index: activeIndex });
        return arrayMove(prevState, activeIndex, overIndex);
      });
    }
  };

  return (
    <DndContext modifiers={[restrictToVerticalAxis]} onDragEnd={onDragEnd}>
      <SortableContext items={dataSource.map((i) => i?.id)} strategy={verticalListSortingStrategy}>
        <Table<T>
          rowKey="id"
          components={{ body: { row: Row } }}
          dataSource={dataSource}
          columns={columnWithDrag}
          // expandable={{ expandedRowRender: () =>  <DraggableTable/>}}
          {...restProps}
        />
      </SortableContext>
    </DndContext>
  );
};

export default DraggableTable;
