'use client';
import { Flex } from 'antd';
import React, { useEffect, useState } from 'react';
import { PiMinus, PiPlus } from 'react-icons/pi';
import ButtonSquare from './buttons/ButtonSquare';

interface NumberInputProps {
  min?: number;
  max?: number;
  step?: number;
  setValue: (value: string) => void;
  value: string;
}

const NumberInput: React.FC<NumberInputProps> = ({
  min = 0,
  max = 10 ** 12,
  step = 1,
  setValue,
  value = '0',
}) => {
  const [localValue, setLocalValue] = useState('0');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;

    if (newValue === '' || (!isNaN(Number(newValue)) && Number(newValue) <= max)) {
      setValue(newValue);
      setLocalValue(newValue);
    }
  };

  useEffect(() => {
    if (value && localValue && value !== localValue) setLocalValue(value);
  }, [value, localValue]);

  const increment = () => {
    setLocalValue((localValue) => {
      const newValue = String(Math.min(Number(localValue || '0') + step, max));
      setValue(newValue);
      return newValue;
    });
  };

  const decrement = () => {
    setLocalValue((localValue) => {
      const newValue = String(Math.max(Number(localValue || '0') - step, min));
      setValue(newValue);
      return newValue;
    });
  };

  const inputWidth = 20 + (value.length > 2 ? value.length : 1) * 10;

  return (
    <Flex gap={8} justify="center">
      <ButtonSquare
        style={{ padding: 0, width: 30, height: 30 }}
        htmlType="button"
        theme="red"
        onClick={decrement}
        disabled={Number(localValue) <= min}
      >
        <PiMinus />
      </ButtonSquare>
      <input
        style={{
          width: inputWidth,
          height: 30,
          textAlign: 'center',
          borderRadius: 6,
        }}
        type="text"
        value={localValue}
        onChange={handleChange}
      />
      <ButtonSquare
        style={{ padding: 0, width: 30, height: 30 }}
        htmlType="button"
        theme="blue"
        onClick={increment}
        disabled={Number(localValue) >= max}
      >
        <PiPlus />
      </ButtonSquare>
    </Flex>
  );
};

export default NumberInput;
