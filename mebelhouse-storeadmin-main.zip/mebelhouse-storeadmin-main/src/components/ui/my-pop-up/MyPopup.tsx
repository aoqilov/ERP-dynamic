import { DownOutlined } from '@ant-design/icons';
import { ConfigProvider, Dropdown, Flex, Space } from 'antd';
import './my-popup.css'; // Import the CSS file

type Props<T> = {
  data: T[];
  keyLabel: keyof T;
  keyNumber: keyof T;
  keyId?: keyof T;
};

const MyPopup = <T extends Record<string, any>>({ data, keyLabel, keyNumber, keyId }: Props<T>) => {
  const convertDataForDropdown = () => {
    return data?.map((item, index) => {
      return {
        key: String(item[keyId || String(index)]),
        label: (
          <Flex className="custom-item">
            <span>{item[keyLabel] as string | number}</span>
            <span>{(item[keyNumber] as string | number) || '-'}</span>
          </Flex>
        ),
      };
    });
  };

  return (
    <ConfigProvider
      theme={{
        token: {
          controlItemBgHover: '#FFF',
        },
      }}
    >
      <Dropdown
        overlayStyle={{ minWidth: 220 }}
        menu={{ items: convertDataForDropdown() }}
        trigger={['click']}
      >
        <a className="my-popup__trigger" onClick={(e) => e.preventDefault()}>
          <Space>
            <DownOutlined />
          </Space>
        </a>
      </Dropdown>
    </ConfigProvider>
  );
};

export default MyPopup;
