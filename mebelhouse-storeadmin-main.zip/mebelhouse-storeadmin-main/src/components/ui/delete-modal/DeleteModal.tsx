import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
import { useDeleteBrandMutation } from '@/store/services/brand/brand.api';
import { useDeleteCategoriesMutation } from '@/store/services/categories/categories.api';
import { useDeleteColorMutation } from '@/store/services/color/color.api';
import {
  useDeleteMultiProductListsMutation,
  useDeleteProductListsMutation,
} from '@/store/services/product-lists/product-lists.api';
import { useDeleteRegionMutation } from '@/store/services/region/region.api';
import { useDeleteShowroomsMutation } from '@/store/services/showrooms/showrooms.api';
import { useDeleteSubCategoriesMutation } from '@/store/services/sub-categories/sub-categories.api';
import { closeModal } from '@/store/slices/modal.slice';
import { Flex, ModalProps, message } from 'antd';
import { useTranslation } from 'react-i18next';
import MyButton from '../buttons/my-button/MyButton';
import ModalWrapper from '../modal-wrapper/ModalWrapper';
import './delete-modal.css';
import {
  useDeleteMultiProductsMutation,
  useDeleteProductsMutation,
} from '@/store/services/products/products.api';
import { useDeleteEmployeesMutation } from '@/store/services/employees/employees.api';

type DeleteModalType = ModalProps & {};

const DeleteModal = ({ ...modalProps }: DeleteModalType) => {
  const { t } = useTranslation();
  const dispatch = useAppDispatch();
  const {
    modal: { id, modalType },
    auth: { token },
    selectedItems: { selectedItems },
  } = useAppSelector((state) => state);

  const [deleteCategory, { isLoading: categoryLoading }] = useDeleteCategoriesMutation();
  const [deleteColor, { isLoading: colorLoading }] = useDeleteColorMutation();
  const [deleteBrand, { isLoading: brandLoading }] = useDeleteBrandMutation();
  const [deleteEmployee, { isLoading: employeeLoading}] = useDeleteEmployeesMutation()
  const [deleteRegion, { isLoading: regionLoading }] = useDeleteRegionMutation();
  const [deleteSubCat, { isLoading: subCatLoading }] = useDeleteSubCategoriesMutation();
  const [deleteProductListItem, { isLoading: productListLoading }] =
    useDeleteProductListsMutation();
  const [deleteProduct, { isLoading: productLoading }] = useDeleteProductsMutation();
  const [deleteMultiProducts, { isLoading: productMultiLoading }] =
    useDeleteMultiProductsMutation();
  const [deleteMultiProductsLists, { isLoading: productListMultiLoading }] =
    useDeleteMultiProductListsMutation();

  const [deleteShowroomsTrigger, deleteShowroomsResult] = useDeleteShowroomsMutation();

  const handleCancel = () => {
    dispatch(closeModal());
  };

  const modelId = id as string;

  const handleOk = async () => {
    let res = null;
    if (modalType?.component === 'categories') {
      res = await deleteCategory({ id: modelId, token });
    } else if (modalType?.component === 'color') {
      res = await deleteColor({ id: modelId, token });
    } else if (modalType?.component === 'brand') {
      res = await deleteBrand({ id: modelId, token });
    } else if (modalType?.component === 'region') {
      res = await deleteRegion({ id: modelId, token });
    } else if (modalType?.component === 'subCategory') {
      res = await deleteSubCat({ id: modelId, token });
    } else if (modalType?.component === 'productLists') {
      res = await deleteProductListItem({ id: modelId, token });
    } else if (modalType?.component === 'productsIncome') {
      res = await deleteProduct({ id: modelId, token });
    } else if (modalType?.component === 'store') {
      res = await deleteShowroomsTrigger({ id: modelId, token });
    } else if (modalType?.component === 'employee') {
      res = await deleteEmployee({ id: modelId, token });
    } else if (modalType?.component === 'productListsMulti') {
      res = await deleteMultiProductsLists({
        body: {
          products: selectedItems as number[],
        },
        token,
      });
    } else if (modalType?.component === 'productsIncomeMulti') {
      res = await deleteMultiProducts({
        body: {
          products: selectedItems as number[],
        },
        token,
      });
    }

    if (res?.data?.status_code === 200) {
      message.success(t('Common.Success'));
      dispatch(closeModal());
    } else {
      message.error(res?.data?.message);
    }
  };

  return (
    <ModalWrapper modalTitle={t('Common.Deleting')} {...modalProps}>
      <p className="delete-modal-text">{t('Common.AreYouSureToDelete')}</p>
      <Flex gap={8} justify="center">
        <MyButton
          disabled={
            categoryLoading ||
            colorLoading ||
            brandLoading ||
            regionLoading ||
            subCatLoading ||
            productListLoading ||
            productLoading ||
            deleteShowroomsResult?.isLoading ||
            productListMultiLoading ||
            productMultiLoading || 
            employeeLoading
          }
          onClick={handleCancel}
          className="delete-modal-cancel-btn"
        >
          {t('Common.Cancel')}
        </MyButton>
        <MyButton
          loading={
            categoryLoading ||
            colorLoading ||
            brandLoading ||
            regionLoading ||
            subCatLoading ||
            productLoading ||
            productListLoading ||
            deleteShowroomsResult?.isLoading ||
            productListMultiLoading ||
            productMultiLoading ||
            employeeLoading
          }
          onClick={handleOk}
          className="delete-modal-submit-btn"
          type="primary"
        >
          Ok
        </MyButton>
      </Flex>
    </ModalWrapper>
  );
};

export default DeleteModal;
