import { flagIcons } from '@/assets/icons/flags';
import { LangEnum } from '@/lib/types/lang.type';
import { Flex, Image } from 'antd';
import { SelectProps } from 'antd/es/select';
import Title from 'antd/es/typography/Title';

const langList = Object.entries(LangEnum);

export const langOptions: SelectProps['options'] = langList.map(([key, lang]) => {
  return {
    value: lang,
    label: (
      <Flex align="center" gap="4px" key={key}>
        <Image
          style={{ display: 'flex' }}
          preview={false}
          src={flagIcons[lang as LangEnum]}
          alt={key}
          width={18}
          height={18}
        />
        <Title
          style={{
            margin: 0,
            textTransform: 'uppercase',
            fontFamily: 'monospace',
          }}
          level={5}
        >
          {key}
        </Title>
      </Flex>
    ),
    style: { fontWeight: 'bold' },
  };
});
