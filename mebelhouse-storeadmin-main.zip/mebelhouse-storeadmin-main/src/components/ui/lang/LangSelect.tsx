import { Select } from 'antd';
import { FC } from 'react';

import { LangEnum } from '@/lib/types/lang.type';
import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
import { setLang } from '@/store/slices/lang.slice';
import { langOptions } from './lang-options';

const LangSelect: FC = () => {
  const { lang } = useAppSelector((state) => state.lang);
  const dispatch = useAppDispatch();

  const handleChange = (value: LangEnum) => {
    if (value !== lang) dispatch(setLang(value));
  };

  return <Select onChange={handleChange} value={lang} options={langOptions} />;
};

export default LangSelect;
