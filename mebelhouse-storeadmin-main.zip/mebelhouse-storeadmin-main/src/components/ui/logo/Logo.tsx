import { Flex, Image } from 'antd';
import Link from 'antd/es/typography/Link';
import LogoIcon from '@/assets/icons/logo.svg';
import { FC } from 'react';

type LogoProps = {
  width?: number;
  height?: number;
  className?: string;
};

const Logo: FC<LogoProps> = ({ width = 40, height = 40, className }) => {
  return (
    <Link className={className} href="/">
      <Flex justify="center">
        <Image preview={false} src={LogoIcon} alt="logo" width={width} height={height} />
      </Flex>
    </Link>
  );
};

export default Logo;
