import { IArrowDown } from '@/components/svgs/svgs';
import { Form, Select, SelectProps } from 'antd';
import { FormItemProps } from 'antd/lib';
import { Fragment } from 'react/jsx-runtime';
import './my-select.css';
import clsx from 'clsx';
const { Item } = Form;

type MySelectProps = SelectProps & {
  label?: string;
  required?: boolean;
  labelClassName?: string;
  isFormItem?: boolean;
  formItemProps?: FormItemProps;
  defaultHeight?: boolean;
  id?: string;
};

const MySelect = ({
  label,
  required = true,
  labelClassName,
  isFormItem = true,
  defaultHeight = true,
  formItemProps,

  id,
  ...selectProps
}: MySelectProps) => {
  const Wrap = isFormItem ? Item : Fragment;
  const FormItemProps = isFormItem ? { ...formItemProps } : {};

  return (
    <Wrap style={{ margin: 0 }} {...FormItemProps}>
      <Select
        suffixIcon={<IArrowDown />}
        style={{ width: '100%' }}
        className={clsx('my-select', {
          'my-select--auto-height': !defaultHeight,
        })}
        size="large"
        {...selectProps}
      />
    </Wrap>
  );
};

export default MySelect;
