import { ModalStyleType } from '@/lib/types/common.type';
import { useAppDispatch } from '@/store/reduxHooks';
import { closeModal } from '@/store/slices/modal.slice';
import { Drawer, FormProps } from 'antd';
import { ButtonProps } from 'antd/lib';
import { FC, ReactNode } from 'react';
import FormContent from '../form-content/FormContent';

type Props = {
  drawerTitle?: string;
  styleType?: ModalStyleType;
  btnContent?: string;
  btnProps?: ButtonProps;
  formProps?: FormProps;
  children: ReactNode;
};

const DrawerWrapper: FC<Props> = ({
  drawerTitle,
  children,
  styleType = 'default',
  btnProps,
  btnContent,
  formProps,
  // ...modalProps
}) => {
  const dispatch = useAppDispatch();
  const onClose = () => {
    dispatch(closeModal());
  };

  return (
    <Drawer width='35vw' closable={false} onClose={onClose} open={true}>
      <FormContent
        formProps={{ ...formProps }}
        btnContent={btnContent}
        btnProps={{ ...btnProps }}
        modalTitle={drawerTitle}
        styleType={styleType}
      >
        {children}
      </FormContent>
    </Drawer>
  );
};

export default DrawerWrapper;
