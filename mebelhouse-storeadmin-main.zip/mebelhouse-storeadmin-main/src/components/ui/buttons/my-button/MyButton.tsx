import { Button, ButtonProps } from 'antd';
import { Link } from 'react-router-dom';
import './my-button.css';
import clsx from 'clsx';

type MyBtnStyleTypes = 'orange' | 'primary' | 'white';

type MyButtonProps = ButtonProps & {
  linkClassName?: string;
  styleType?: MyBtnStyleTypes;
};

const MyButton = ({ linkClassName, styleType, ...btnProps }: MyButtonProps) => {
  if (btnProps?.href) {
    return (
      <Link className={`my-link ${linkClassName}`} to={btnProps.href!}>
        <Button
          className={clsx('my-btn-base my-btn-link', {
            'my-btn-primary': styleType === 'primary',
            'my-btn-orange': styleType === 'orange',
            'my-btn-white': styleType === 'white',
          })}
          {...btnProps}
        >
          {btnProps.children}
        </Button>
      </Link>
    );
  }

  return (
    <Button
      className={clsx('my-btn-base', {
        'my-btn-primary': styleType === 'primary',
        'my-btn-orange': styleType === 'orange',
        'my-btn-white': styleType === 'white',
      })}
      {...btnProps}
    >
      {btnProps.children}
    </Button>
  );
};

export default MyButton;
