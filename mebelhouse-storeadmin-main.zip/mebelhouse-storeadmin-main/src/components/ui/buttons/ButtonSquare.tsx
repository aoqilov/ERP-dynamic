import { Button as ButtonAnt, ButtonProps, ConfigProvider } from 'antd';
import { FC } from 'react';

const buttonColors = {
  red: '#ED0800',
  blue: '#1677FF',
  black: '#2c3e50',
  white: '#ecf0f1',
  yellow: '#FFC107',
  green: '#28A745',
  purple: '#80669d',
  brow: '#8e6a4e',
  gray: '#95a5a6',
};

type Props = ButtonProps & {
  theme?: keyof typeof buttonColors;
};

const ButtonSquare: FC<Props> = ({ theme = 'blue', ...props }) => {
  const buttonColor = buttonColors[theme];
  // const buttonHoverColor = lightenHexColor(buttonDefaultColor, 0);

  return (
    <ConfigProvider
      theme={{
        token: {
          colorPrimary: buttonColor,
        },
        components: {
          Button: {
            colorPrimary: buttonColor,
            colorBgContainerDisabled: '#F6F6F7',
          },
        },
      }}
    >
      <ButtonAnt type="primary" {...props} />
    </ConfigProvider>
  );
};

export default ButtonSquare;
