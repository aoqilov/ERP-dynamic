import React, { useState } from 'react';
import './count-button.css';
import { IMinus, IPlusWhite } from '@/components/svgs/svgs';

type CountButtonProps = {
  initialCount?: number;
  onCountChange?: (count: number) => void;
  limit?: number; // Add this line to accept a limit
};

const CountButton: React.FC<CountButtonProps> = ({ initialCount = 0, onCountChange, limit }) => {
  const [count, setCount] = useState(initialCount);
  const [inputValue, setInputValue] = useState(initialCount.toString());

  const handleDecrement = () => {
    if (count > 0) {
      const newCount = count - 1;
      setCount(newCount);
      setInputValue(newCount.toString());
      onCountChange?.(newCount);
    }
  };

  const handleIncrement = () => {
    if (limit === undefined || count < limit) {
      const newCount = count + 1;
      setCount(newCount);
      setInputValue(newCount.toString());
      onCountChange?.(newCount);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (value === '') {
      setInputValue('');
      return;
    }

    const newValue = parseInt(value, 10);
    if (!isNaN(newValue) && newValue >= 0 && (limit === undefined || newValue <= limit)) {
      setCount(newValue);
      setInputValue(newValue.toString());
      onCountChange?.(newValue);
    } else {
      setInputValue(inputValue); // Keep the old value if new value exceeds limit
    }
  };

  const handleInputBlur = () => {
    if (inputValue === '') {
      setCount(0);
      setInputValue('0');
      onCountChange?.(0);
    }
  };

  return (
    <div className="count-button-container">
      <button
        type="button"
        className="count-button count-button-minus"
        onClick={handleDecrement}
        disabled={count <= 0}
      >
        <IMinus />
      </button>
      <input
        type="number"
        className="count-input"
        value={inputValue}
        onChange={handleInputChange}
        onBlur={handleInputBlur}
        min="0"
        max={limit} // HTML input attribute to restrict maximum value
      />
      <button
        type="button"
        className="count-button count-button-plus"
        onClick={handleIncrement}
        disabled={limit !== undefined && count >= limit}
      >
        <IPlusWhite />
      </button>
    </div>
  );
};

export default CountButton;
