import { Locale } from '@/i18n';
import {
  ALLOWED_TYPE_FILES,
  ALLOWED_TYPE_PHOTOS,
  MAX_MB_FILES,
  MAX_MB_PHOTOS,
} from '@/lib/consts/common';
import { SERVER_URL } from '@/lib/consts/url.consts';
import { langAcceptence, langMaxMb } from '@/lib/utils/langHandlers';
import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
import { useCreateFileMutation, useDeleteFileMutation } from '@/store/services/files/files.api';
import { setFile } from '@/store/slices/file.slice';
import { PlusOutlined } from '@ant-design/icons';
import type { GetProp, UploadFile, UploadProps } from 'antd';
import { Image, Upload, message } from 'antd';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

type FileType = Parameters<GetProp<UploadProps, 'beforeUpload'>>[0];

const getBase64 = (file: FileType): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });

type MyUploadProps = {
  uploadProps?: UploadProps;
  type: 'photo' | 'file';
};

const MyUpload: React.FC<MyUploadProps> = ({ uploadProps, type }) => {
  const [addFile] = useCreateFileMutation();
  const [deleteFile] = useDeleteFileMutation();
  const {
    auth: { token },
    file: { id },
    modal: { data, modalType },
  } = useAppSelector((state) => state);

  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState('');
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const [uploadError, setUploadError] = useState(false);
  const dispatch = useAppDispatch();

  useEffect(() => {
    if (modalType?.manipulation === 'edit') {
      if (modalType.component === 'productLists') {
        dispatch(setFile(data?.pictures?.[0]?.id));
      } else {
        dispatch(setFile(data?.picture?.id));
      }
    }
  }, []);

  const {
    t,
    i18n: { language },
  } = useTranslation();

  // Set initial file if `data.picture.picture` exists
  useEffect(() => {
    if (data?.picture?.picture || data?.pictures?.[0]) {
      setFileList([
        {
          uid: '-1', // Unique identifier for the file
          name: 'existing file', // Placeholder name
          status: 'done', // Indicates the file is already uploaded
          url: data?.picture?.picture || `${SERVER_URL}/${data?.pictures?.[0].picture}`, // Set the URL from the existing file
        },
      ]);
      setPreviewImage(data?.picture?.picture || data?.picture?.[0].picture); // Set preview image
    }
  }, [data]);

  console.log(fileList);

  const handlePreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj as FileType);
    }
    setPreviewImage(file.url || (file.preview as string));
    setPreviewOpen(true);
  };

  const handleChange: UploadProps['onChange'] = async ({ fileList: newFileList }) => {
    if (uploadError) {
      setUploadError(false);
      return;
    }
    setFileList(newFileList);
    const file = newFileList[0];
    if (file.status === 'done' || file.status === 'error') {
      return;
    }
  };

  const beforeUpload = (file: FileType) => {
    let allowedTypes;
    let maxFileSize;

    if (type === 'photo') {
      allowedTypes = ALLOWED_TYPE_PHOTOS;
      maxFileSize = MAX_MB_PHOTOS;
    } else {
      allowedTypes = ALLOWED_TYPE_FILES;
      maxFileSize = MAX_MB_FILES;
    }

    // Extract the file type and check if it is allowed
    const fileType = file.type.split('/')[1];
    const isAllowedType = allowedTypes.includes(fileType);

    if (!isAllowedType) {
      message.error(langAcceptence(language as Locale));
      setUploadError(true);
      return false;
    }

    const isLtMaxSize = file.size / 1024 / 1024 < maxFileSize;
    if (!isLtMaxSize) {
      message.error(langMaxMb(language as Locale));
      setUploadError(true);
      return false;
    }

    return true;
  };

  const onRemove = async () => {
    try {
      const res = await deleteFile({ id: String(id), token });

      if (res.data?.status_code !== 200) {
        message.error(t('Common.Error'));
        return false;
      }
      dispatch(setFile(null));
      return true;
    } catch (error) {
      message.error(t('Common.Error'));
      return false;
    }
  };

  const customRequest = async (options: Record<string, any>) => {
    const { onSuccess, onError } = options;
    const file = fileList[0];
    const formData = new FormData();
    const rawFile = file.originFileObj as File;

    if (rawFile) {
      formData.append('picture', rawFile);

      try {
        const res = await addFile({ body: formData, token });

        if (res.data?.status_code === 201) {
          dispatch(setFile(Number(res.data.data.id)));
          file.url = res.data.data.picture;
          onSuccess(null, file);
        } else {
          message.error(t('Common.ErrorFile'));
          setUploadError(true);
          onError(new Error(t('Common.ErrorFile')));
        }
      } catch (error) {
        message.error(t('Common.ErrorFile'));
        onError(error);
      }
    }
  };

  // Validation logic when a form is submitted or checked
  // const handleValidateUpload = () => {
  //   if (required && fileList.length === 0) {
  //     setUploadError(t('Common.UploadRequired'));
  //     return false; // Validation fails
  //   }
  //   return true; // Validation succeeds
  // };

  const uploadButton = (
    <button style={{ border: 0, background: 'none' }} type="button">
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>
        {t(type === 'photo' ? 'Common.AddImg' : 'Common.SelectFile')}
      </div>
    </button>
  );

  return (
    <>
      <Upload
        customRequest={customRequest}
        fileList={fileList}
        beforeUpload={beforeUpload}
        onPreview={handlePreview}
        onChange={handleChange}
        onRemove={onRemove}
        {...uploadProps}
      >
        {fileList.length >= 1 ? null : uploadButton}
      </Upload>
      {previewImage && (
        <Image
          wrapperStyle={{ display: 'none' }}
          preview={{
            visible: previewOpen,
            onVisibleChange: (visible) => setPreviewOpen(visible),
            afterOpenChange: (visible) => !visible && setPreviewImage(''),
          }}
          src={previewImage}
        />
      )}
      {/* {uploadError && <div style={{ color: 'red' }}>{uploadError}</div>}{' '} */}
      {/* Display error message */}
    </>
  );
};

export default MyUpload;
