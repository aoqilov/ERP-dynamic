import clsx from 'clsx';
import { Form } from 'antd';
import MyButton from '../buttons/my-button/MyButton';
import { FC, ReactNode } from 'react';
import { FormProps } from 'antd';
import { ButtonProps } from 'antd/lib';
import { ModalStyleType } from '@/lib/types/common.type';

type Props = {
  formProps: FormProps;
  styleType: ModalStyleType;
  btnProps: ButtonProps;
  modalTitle?: string;
  children: ReactNode;
  btnContent?: string;
};

const FormContent: FC<Props> = ({
  formProps,
  styleType,
  modalTitle,
  children,
  btnProps,
  btnContent,
}) => {
  return (
    <Form layout="vertical" {...formProps}>
      <div
        className={clsx('', {
          'modal-content-single-btn-child-wrapper': styleType === 'singleBtn',
        })}
      >
        <p className="modal__title">{modalTitle}</p>
        {children}
      </div>
      {styleType === 'singleBtn' && (
        <MyButton className="modal__single-btn" type="primary" {...btnProps}>
          {btnContent}
        </MyButton>
      )}
    </Form>
  );
};

export default FormContent;
