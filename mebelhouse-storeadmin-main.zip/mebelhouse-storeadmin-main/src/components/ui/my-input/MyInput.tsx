import { Patterns } from '@/lib/utils/Patterns';
import { Form, Input, InputProps } from 'antd';
import type { SearchProps, TextAreaProps } from 'antd/es/input';
import type { OTPProps } from 'antd/es/input/OTP';
import { FormItemProps } from 'antd/lib';
import type { PasswordProps } from 'antd/lib/input';
import { FC, Fragment } from 'react';
import './my-input.css';
import PhoneNumberInput from './phone-input/PhoneInput';

const { Item } = Form;

type MyInputType = 'text' | 'password' | 'search' | 'textarea' | 'otp';

type TInputPasswordProps = {
  inputType?: 'password';
} & PasswordProps;

type TInputSearchProps = {
  inputType?: 'search';
} & SearchProps;

type TInputProps = {
  inputType?: 'text';
} & InputProps;

type TInputTextAreaProps = {
  inputType?: 'textarea';
} & TextAreaProps;

type TInputOTPProps = {
  inputType?: 'otp';
} & OTPProps;

type TProps = { isFormItem?: boolean; formItemProps?: FormItemProps } & (
  | TInputPasswordProps
  | TInputProps
  | TInputSearchProps
  | TInputTextAreaProps
  | TInputOTPProps
);

type MyInputProps = TProps & {
  required?: boolean;
  inputType?: MyInputType;
  isPhone?: boolean;
};

const MyInput: FC<MyInputProps> = ({
  id,
  isPhone,
  required = true,
  isFormItem = true,
  inputType = 'text',
  formItemProps,
  ...inputProps
}) => {
  let InputComponent: React.ElementType;
  const { baseValidation } = Patterns();

  switch (inputType) {
    case 'password':
      InputComponent = Input.Password;
      break;
    case 'search':
      InputComponent = Input.Search;
      break;
    case 'textarea':
      InputComponent = Input.TextArea;
      break;
    case 'otp':
      InputComponent = Input.OTP;
      break;
    default:
      InputComponent = Input;
  }

  // Render Item only when isFormItem is true, otherwise render Fragment without additional props
  if (isFormItem) {
    return (
      <Item className="my-input-item" rules={baseValidation} {...formItemProps}>
        {!isPhone ? (
          <InputComponent
            maxLength={(inputProps as InputProps).maxLength || 300}
            className="my-input"
            size="large"
            id={id}
            {...inputProps}
          />
        ) : (
          <PhoneNumberInput />
        )}
      </Item>
    );
  }

  return (
    <Fragment>
      <InputComponent
        maxLength={(inputProps as InputProps).maxLength || 300}
        className="my-input"
        size="large"
        id={id}
        {...inputProps}
      />
    </Fragment>
  );
};

export default MyInput;
