import PhoneInput from 'react-phone-input-2';
import clsx from 'clsx';
import '../my-input.css';
import './phone-input.css';

type PhoneNumberInputProps = {
  value?: string;
  onChange?: (value: string) => void;
};

const PhoneNumberInput: React.FC<PhoneNumberInputProps> = ({ value, onChange }) => {
  return (
    <PhoneInput
      specialLabel=""
      containerClass="w-full"
      country="uz"
      value={value}
      onChange={(phone) => onChange?.(phone ? `+${phone}` : phone)}
      inputClass={clsx('my-input my-phone-input')}
      placeholder=""
      buttonStyle={{ display: 'none' }}
    />
  );
};

export default PhoneNumberInput;
