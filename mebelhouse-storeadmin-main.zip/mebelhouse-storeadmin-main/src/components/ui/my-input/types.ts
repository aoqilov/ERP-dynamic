import { FormItemProps } from "antd";
import { InputProps, PasswordProps, TextAreaProps } from "antd/es/input";
import { OTPProps } from "antd/es/input/OTP";
import { SearchProps } from "antd/lib/input";

export type MyInputType = 'text' | 'password' | 'search' | 'textarea' | 'otp';

export type TInputPasswordProps = {
  inputType?: 'password';
} & PasswordProps;

export type TInputSearchProps = {
  inputType?: 'search';
} & SearchProps;

export type TInputProps = {
  inputType?: 'text';
} & InputProps;

export type TInputTextAreaProps = {
  inputType?: 'textarea';
} & TextAreaProps;

export type TInputOTPProps = {
  inputType?: 'otp';
} & OTPProps;

export type TProps = { isFormItem?: boolean; formItemProps?: FormItemProps } & (
  | TInputPasswordProps
  | TInputProps
  | TInputSearchProps
  | TInputTextAreaProps
  | TInputOTPProps
);

export type MyInputProps = TProps & {
  required?: boolean;
  inputType?: MyInputType;
};
