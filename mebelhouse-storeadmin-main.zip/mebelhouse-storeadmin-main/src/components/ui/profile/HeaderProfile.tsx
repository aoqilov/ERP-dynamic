import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
import { clearAuth } from '@/store/slices/auth.slice';
import { persistor } from '@/store/store';
import { Avatar, Dropdown } from 'antd';
import { FC } from 'react';
import { AiOutlineUser } from 'react-icons/ai';
import { useNavigate } from 'react-router-dom';
import { profileDropdownItems } from './profile-data';
import { ROUTES } from '@/constants';

export const HeaderProfile: FC = () => {
  const user = useAppSelector((state) => state?.auth);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const signOut = () => {
    dispatch(clearAuth());
    persistor.purge();

    navigate(ROUTES.login);
  };

  const profileItems = profileDropdownItems(
    [`${user?.last_name} ${user?.first_name}`, user?.store_name],
    signOut,
  );

  return (
    <Dropdown menu={{ items: profileItems }} trigger={['click']}>
      <button>
        <Avatar size="default" icon={<AiOutlineUser />} />
      </button>
    </Dropdown>
  );
};
