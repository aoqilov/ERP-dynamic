import { MenuProps } from 'antd';

export const profileDropdownItems = (items: string[], signOut: () => void): MenuProps['items'] => {
  const defaultItems: MenuProps['items'] = [
    {
      type: 'divider',
    },
    {
      key: '2',
      danger: true,
      label: 'Выйти',
      onClick: () => signOut(),
    },
  ];

  if (!items?.length) return defaultItems;

  const reversedItems = [...items].reverse();
  reversedItems?.forEach((item) => {
    if (!item?.trim()) return;
    defaultItems.unshift({
      type: 'group',
      label: <span style={{ fontWeight: 'bold' }}>{item || 'None'}</span>,
    });
  });

  return defaultItems;
};
