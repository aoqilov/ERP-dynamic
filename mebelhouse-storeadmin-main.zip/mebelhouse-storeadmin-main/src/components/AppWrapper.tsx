import { useAppSelector } from '@/store/reduxHooks';
import { ReactNode } from 'react';
import DeleteModal from './ui/delete-modal/DeleteModal';

type AppWrapperProps = {
  children: ReactNode;
};

const AppWrapper = ({ children }: AppWrapperProps) => {
  const { modalIsOpen, modalType } = useAppSelector((state) => state.modal);

  return (
    <>
      {children}
      <DeleteModal open={modalType?.style === 'delete' && modalIsOpen} />
    </>
  );
};

export default AppWrapper;
