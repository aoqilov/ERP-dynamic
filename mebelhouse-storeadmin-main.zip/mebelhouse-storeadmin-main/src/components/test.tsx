import { useTranslation } from 'react-i18next';

import '../i18n';
// import { PlusOutlined } from "@ant-design/icons";
// import { EditOutlined } from "@ant-design/icons";

// const { Title, Text, Paragraph } = Typography;

export const Test = () => {
  const { t } = useTranslation();

  // useEffect(() => {
  //   i18n.changeLanguage('ru');
  // }, []);

  // const [value, setValue] = useState('This is initial text');

  return (
    <div>
      <p>{t('click')}</p>

      {/* <Paragraph style={{ fontSize: 50 }} copyable>
        Copyable
      </Paragraph>

      <Paragraph
        style={{ fontSize: 50, width: 500 }}
        editable={{
          tooltip: "Edit me pls",
          icon: <EditOutlined />,
          onChange: setValue,
        }}
      >
        {value}
      </Paragraph> */}

      {/* <Title level={2}>This is a title</Title>

      <Text style={{ fontSize: 50 }} type="danger">
        This is a text
      </Text>
      <Text style={{ fontSize: 50 }} type="danger" disabled>
        This is a text
      </Text>
      <Text style={{ fontSize: 50 }} type="danger" mark>
        This is a text
      </Text>
      <Text style={{ fontSize: 50 }} type="danger" code>
        This is a text
      </Text>
      <Text style={{ fontSize: 50 }} type="danger" keyboard>
        This is a text
      </Text>
      <Text style={{ fontSize: 50 }} type="danger" underline>
        This is a text
      </Text>
      <Text style={{ fontSize: 50 }} type="danger" delete>
        This is a text
      </Text>
      <Text style={{ fontSize: 50 }} type="danger" strong>
        This is a text
      </Text> */}
      {/* <Text style={{ fontSize: 50 }} type="danger" strong>
        This is a text
      </Text> */}

      {/* <Button
        style={{ margin: 500 }}
        size="large"
        type="primary"
        danger
        // icon={<PlusOutlined />}
      >
        <PlusOutlined />
        Create new record
      </Button> */}
      {/* <Form>
        <Space direction="vertical">
          <Input placeholder="Placeholder" required />
          <Button htmlType="submit">Submit</Button>
        </Space>
      </Form> */}
      {/* <Login /> */}
    </div>
  );
};
