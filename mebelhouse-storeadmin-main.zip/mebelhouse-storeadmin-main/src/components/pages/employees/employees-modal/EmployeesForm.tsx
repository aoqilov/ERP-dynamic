import MyInput from '@/components/ui/my-input/MyInput';
import MySelect from '@/components/ui/my-select/MySelect';
import { Locale } from '@/i18n';
import { validateMinMessage } from '@/lib/utils/validations';
import { Flex } from 'antd';
import { FC } from 'react';
import { useTranslation } from 'react-i18next';

type Props = {
  type: 'add' | 'edit' | undefined;
};

const EmployeesForm: FC<Props> = ({ type }) => {
  const {
    t,
    i18n: { language },
  } = useTranslation();

  const genderList = [
    { label: t('Employee.Male'), value: 'male' },
    { label: t('Employee.Female'), value: 'female' },
  ];

  const roleList = [
    { label: t('Employee.Cashier'), value: 'cashier' },
    { label: t('Employee.Sales'), value: 'sales' },
  ];

  return (
    <Flex vertical gap={16} style={{ overflowY: 'auto', maxHeight: '100vh', paddingInline: '4px' }}>
      <MyInput
        formItemProps={{ name: 'first_name', label: t(`Employee.Name`) }}
        title={t(`Employee.Name`)}
        size="large"
        placeholder={t(`Employee.Name`)}
      />
      <MyInput
        formItemProps={{ name: 'last_name', label: t(`Employee.Surname`) }}
        title={t(`Employee.Surname`)}
        size="large"
        placeholder={t(`Employee.Surname`)}
      />

      <MySelect
        required
        formItemProps={{ name: 'gender', label: t('Employee.Gender') }}
        size="large"
        options={genderList}
      />

      <MyInput
        isPhone
        formItemProps={{ name: 'phone_number', label: t(`Employee.PhoneNumber`) }}
        title={t(`Employee.PhoneNumber`)}
        size="large"
        placeholder={t(`Employee.PhoneNumber`)}
      />

      <MySelect
        required={type === 'add'}
        formItemProps={{ name: 'role', label: t('Employee.Duty') }}
        size="large"
        options={roleList}
      />

      <MyInput
        formItemProps={{
          name: 'username',
          label: t(`Employee.Login`),
          rules: [
            { required: true, message: t('Common.Required') },
            {
              min: 6,
              message: validateMinMessage(6, language as Locale),
            },
          ],
        }}
        title={t(`Employee.Login`)}
        size="large"
        placeholder={t(`Employee.Login`)}
      />

      <MyInput
        formItemProps={{
          name: 'password',
          rules: [
            { required: type === 'add', message: t('Common.Required') },
            {
              min: 6,
              message: validateMinMessage(6, language as Locale),
            },
          ],
          label: t(`Employee.Pass`),
        }}
        inputType="password"
        size="large"
        placeholder={t('Employee.Pass')}
      />
    </Flex>
  );
};

export default EmployeesForm;
