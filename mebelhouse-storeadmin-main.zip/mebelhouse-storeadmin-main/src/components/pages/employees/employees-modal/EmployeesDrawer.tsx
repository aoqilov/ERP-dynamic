import DrawerWrapper from '@/components/ui/drawer-wrapper/my-drawer';
import { ModalStyleType } from '@/lib/types/common.type';
import { getErrorMessage } from '@/lib/utils/getErrorMessage';
import { getInitialValue } from '@/lib/utils/getInitialValue';
import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
import {
  useCreateEmployeesMutation,
  useUpdateEmployeesMutation,
} from '@/store/services/employees/employees.api';
import {
  GendersType,
  Roles,
  TCreateEmployeesBody,
} from '@/store/services/employees/employees.type';
import { closeModal } from '@/store/slices/modal.slice';
import { ModalProps, message } from 'antd';
import { useTranslation } from 'react-i18next';
import EmployeesForm from './EmployeesForm';
import MyButton from '@/components/ui/buttons/my-button/MyButton.tsx';

type EmployeesModalProps = ModalProps & {
  styleType?: ModalStyleType;
  btnContent?: string;
};

const EmployeesModal = ({ btnContent }: EmployeesModalProps) => {
  const { t } = useTranslation();
  const {
    modal: { data, modalType, id },
    auth: { token },
  } = useAppSelector((state) => state);
  const dispatch = useAppDispatch();

  const [addEmployee, { isLoading: addLoading }] = useCreateEmployeesMutation();
  const [updateEmployee, { isLoading: updateLoading }] = useUpdateEmployeesMutation();

  const onFinish = async (
    values: Omit<TCreateEmployeesBody, 'showroom'> & { showroom: string },
  ) => {
    const { ...restValues } = values;

    let res = null;

    if (modalType?.manipulation === 'add') {
      const body = structuredClone(restValues);
      res = await addEmployee({ body, token });
    } else {
      let { password, ...body } = restValues;

      res = await updateEmployee({
        body: { ...body, ...(password ? { password } : {}) },
        token,
        id: id as string,
      });
    }

    if (res?.data?.status_code === 201 || res?.data?.status_code === 200) {
      message.success(t('Common.Success'));
      dispatch(closeModal());
    } else {
      // @ts-ignore
      message.error(getErrorMessage(res?.error?.data?.message));
    }
  };

  const getButtonName = () => {
    if (modalType?.manipulation === 'add') {
      return 'Add';
    } else {
      return 'Edit';
    }
  };

  const initialValues = {
    role: getInitialValue(modalType, data?.role, Roles.sales),
    first_name: getInitialValue(modalType, data?.first_name),
    last_name: getInitialValue(modalType, data?.last_name),
    gender: getInitialValue(modalType, data?.gender, GendersType.male),
    phone_number: getInitialValue(modalType, data?.phone_number),
    username: getInitialValue(modalType, data?.username),
    password: '',
  };

  return (
    <DrawerWrapper
      formProps={{ onFinish, initialValues }}
      btnProps={{ htmlType: 'submit' }}
      drawerTitle={t('Employee.AddEmployee')}
      btnContent={btnContent}
    >
      <div style={{ flex: 1 }}>
        <EmployeesForm type={modalType?.manipulation} />
      </div>

      <MyButton
        loading={updateLoading || addLoading}
        style={{ height: 55, width: '100%', marginTop: '24px' }}
        htmlType="submit"
        styleType="orange"
      >
        {t(`Common.${getButtonName()}`)}
      </MyButton>
    </DrawerWrapper>
  );
};

export default EmployeesModal;
