import { IPen, IPlus, ISearch, ITrash } from '@/components/svgs/svgs';
import MyButton from '@/components/ui/buttons/my-button/MyButton';
import MyInput from '@/components/ui/my-input/MyInput';
import MyTableBox from '@/components/ui/tables';
import { Locale } from '@/i18n';
import { langConverterActions } from '@/lib/utils/langHandlers';
import { alphabeticalSort } from '@/lib/utils/sorters/alphabeticalSort';
import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
import { openModal } from '@/store/slices/modal.slice';
import { Flex, Space } from 'antd';
import { ChangeEvent, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import MyContent from '../layout/MyContent';
import MySelect from '@/components/ui/my-select/MySelect';
import { useDebounce } from '@/lib/hooks/useDebounce';
import { useGetAllEmployeesQuery } from '@/store/services/employees/employees.api';
import { Roles, TEmployeesItem, TEmployeesList } from '@/store/services/employees/employees.type';
import type { TableColumnsType } from 'antd';
import EmployeesModal from './employees-modal/EmployeesDrawer';
import useQueryParams from '@/lib/hooks/useQueryParams';

const EmployeesIndex = () => {
  const [searchName, setSearchName] = useState('');
  const [role, setRole] = useState<Roles | ''>('');
  const {
    modal: { modalIsOpen, modalType },
    auth: { token },
  } = useAppSelector((state) => state);
  const debounceSearchName = useDebounce(searchName, 300);
  const { getParam, setParams } = useQueryParams();

  const { data: employeesData, isLoading } = useGetAllEmployeesQuery(
    {
      search: debounceSearchName,
      token: token,
      role: role as Roles,
      page_size: +(getParam('page_size') || 10),
      page: +(getParam('current_page') || 1),
    },
    { skip: !token },
  );

  const {
    t,
    i18n: { language },
  } = useTranslation();
  const dispatch = useAppDispatch();

  const roles: Record<Roles, string> = {
    cashier: 'Cashier',
    sales: 'Sales',
  };

  const columnData = t('Employee.TableColumns', {
    returnObjects: true,
  }) as Array<{
    title: string;
  }>;

  let columns: TableColumnsType<TEmployeesItem> = [
    {
      dataIndex: 'full_name',
      key: 'full_name',
      width: 266,
      sorter: (a: TEmployeesItem, b: TEmployeesItem) =>
        alphabeticalSort(a?.first_name!, b?.first_name!),
      render: (_, record) => (
        <Flex vertical>
          <p>
            {record?.first_name}&nbsp;{record?.last_name}
          </p>
          <span style={{ color: '#A0AEC0', fontSize: 12, lineHeight: '17px' }}>
            {record?.phone_number}
          </span>
        </Flex>
      ),
    },
    {
      dataIndex: 'role',
      key: 'role',
      width: 150,
      sorter: (a: TEmployeesItem, b: TEmployeesItem) => alphabeticalSort(a?.role!, b?.role!),
      render: (text) => t(`Employee.${roles[text as Roles]}`),
    },
    {
      dataIndex: 'name',
      key: 'name',
      width: 150,
      sorter: (a: TEmployeesItem, b: TEmployeesItem) => {
        const showroomA = a?.showroom_executer?.[0]?.showroom?.name || '';
        const showroomB = b?.showroom_executer?.[0]?.showroom?.name || '';
        return showroomA.localeCompare(showroomB);
      },
      render: (_, record) => record?.showroom_executer[0]?.showroom?.name || '',
    },

    {
      dataIndex: 'actions',
      key: 'actions',
      render: (_, record) => (
        <Space size="middle">
          <MyButton
            onClick={() =>
              dispatch(
                openModal({
                  data: employeesData?.data?.find((item) => item?.id === record?.id),
                  modalType: {
                    component: 'employee',
                    style: 'form',
                    manipulation: 'edit',
                  },
                  id: record?.id,
                }),
              )
            }
            style={{ background: 'var(--color-blue)', width: 32, height: 32, border: 'none' }}
            icon={<IPen />}
          />
          <MyButton
            onClick={() => {
              dispatch(
                openModal({
                  id: record?.id,
                  modalType: {
                    component: 'employee',
                    style: 'delete',
                  },
                }),
              );
            }}
            style={{ background: 'var(--color-red)', width: 32, height: 32, border: 'none' }}
            icon={<ITrash />}
          />
        </Space>
      ),
      width: 165,
      align: 'end',
    },
  ];

  columns = columns.map((item, index) => {
    const translation = columnData[index];

    if (index === columns.length - 1) {
      return {
        ...item,
        title: langConverterActions(language as Locale),
      };
    }

    return {
      ...item,
      title: translation?.title,
    };
  });

  const handleSearchChange = (e: ChangeEvent<HTMLInputElement>) => {
    setSearchName(e.target.value);
  };

  const handleRoleChange = (value: Roles) => {
    setRole(value);
  };

  useEffect(() => {
    setParams({
      total_elements: String(employeesData?.total_elements || 10),
      page_size: String(employeesData?.page_size || 10),
      from: String(employeesData?.from || 10),
      to: String(employeesData?.to || 10),
      current_page: String(employeesData?.current_page || 1),
    });
  }, [employeesData]);

  const topHeader = (
    <Flex gap={20}>
      <MyButton
        onClick={() =>
          dispatch(
            openModal({
              modalType: {
                component: 'employee',
                style: 'form',
                manipulation: 'add',
              },
            }),
          )
        }
        styleType="orange"
        icon={<IPlus />}
      >
        {t('Employee.AddEmployee')}
      </MyButton>
    </Flex>
  );

  const header = (
    <Flex gap={16} style={{ marginBottom: 24 }}>
      <MyInput
        onChange={handleSearchChange}
        isFormItem={false}
        size="large"
        placeholder={t('Common.SearchByName')}
        suffix={<ISearch />}
      />
      <MySelect
        onChange={handleRoleChange}
        size="large"
        defaultValue=""
        style={{ width: 200 }}
        options={[
          { value: '', label: t('Employee.AllDuties') },
          { value: 'cashier', label: t('Employee.Cashier') },
          { value: 'sales', label: t('Employee.Sales') },
        ]}
      />
    </Flex>
  );

  return (
    <MyContent>
      <MyTableBox
        columns={columns}
        dataSource={employeesData?.data as TEmployeesList}
        tableTitles={{
          title: t('Employee.Employee'),
          subTitle: t('Employee.ManageEmployee'),
        }}
        tableProps={{ loading: isLoading, rowKey: 'id' }}
        topHeader={topHeader}
        paginationProps={{ total: 10, current: 5 }}
        header={header}
      />
      {modalType?.style === 'form' && modalIsOpen && (
        <EmployeesModal btnContent={t('Common.Save')} styleType="singleBtn" />
      )}
    </MyContent>
  );
};

export default EmployeesIndex;
