export const dataSource = [
  {
    key: '1',
    nameRu: 'Zikr ru1',
    nameUz: 'Zikr1',
  },
  {
    key: '2',
    nameRu: 'Zikr ru2',
    nameUz: 'Zikr2',
  },
  {
    key: '3',
    nameRu: 'Zikr ru3',
    nameUz: 'Zikra',
  },
];
