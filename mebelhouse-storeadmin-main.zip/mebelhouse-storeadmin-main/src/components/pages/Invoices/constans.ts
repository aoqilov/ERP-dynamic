export const data = {
  data: [
    {
      id: 'a2d1ce6e-e661-4ff8-b9c7-ea796eb29156',
      name_uz: 'Test',
      name_ru: 'Test',
      description_uz: 'Test',
      description_ru: 'Test',
      bar_code: '234234324234',
      origin_price: 0,
      sale_price: 0,
      discount_price: 0,
      total_quantity: 0,
      brand: {
        id: '0dfa5b71-563e-4156-8c68-4bcb1e55551b',
        name: 'Mebel-house',
      },
      sub_category: {
        id: 'd7b9cbd1-4294-49e4-9ccf-b3960e618e91',
        name_uz: 'shkaf-u',
        name_ru: 'shkaf-u',
        position: 0,
        category: {
          id: '10cfe0ca-d506-43f8-b950-0483de0fdd9b',
          name_uz: 'Test',
          name_ru: 'Test',
          position: 1,
        },
      },
      country: {
        id: 'ec706d7e-d24d-458b-b239-a107262d0199',
        name_uz: 'Xitoy',
        name_ru: 'Китай',
      },
      colours: [
        {
          id: 'c6e1fbea-e4d3-4691-bca7-f4d6fb615f04',
          name_uz: "Yong'oq",
          name_ru: 'Орех',
          code: null,
        },
        {
          id: '9d3b1ea4-829c-4987-b9ce-a2ab2180e778',
          name_uz: 'Desc',
          name_ru: 'Desc',
          code: null,
        },
      ],
      images: [
        {
          id: 'c1cbd922-e566-4496-b8af-68b85fd71f53',
          file_name: '15740817999023-c349daded512b502701ad98a250bcaa6.jpg',
          path: 'image__bc5f0fdf-5382-43b9-99ea-065411f1c116.jpeg',
          size: 202685,
          mime_type: 'image/jpeg',
        },
      ],
      quantities: [],
    },
  ],

  total_elements: 5,
  total_pages: 1,
  page_size: 10,
  current_page: 1,
  from: 1,
  to: 5,
  status_code: 200,
  message: 'Успешно!',
};
