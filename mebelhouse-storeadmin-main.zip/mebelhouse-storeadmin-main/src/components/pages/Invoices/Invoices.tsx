import { ISearch } from '@/components/svgs/svgs';
import MyInput from '@/components/ui/my-input/MyInput';
import MyTable from '@/components/ui/tables/MyTable/MyTable';
import MyTableTitles from '@/components/ui/tables/MyTableTitles/MyTableTitles';
import { formatTimestamp } from '@/lib/utils/formatters/dateFormatter';
import { makeSpaces } from '@/lib/utils/formatters/makeSpaces';
import { alphabeticalSort } from '@/lib/utils/sorters/alphabeticalSort';
import { Collapse, CollapseProps, Flex, Space, TableColumnsType } from 'antd';
import { useTranslation } from 'react-i18next';
import MyContent from '../layout/MyContent';
import MyPopup from '@/components/ui/my-pop-up/MyPopup';
import Paragraph from 'antd/es/typography/Paragraph';
import { data } from './constans';
import { getNestedValue } from '@/lib/utils/getNestedValue';

export const Invoices = () => {
  const { t } = useTranslation();

  const columns: TableColumnsType<any> = [
    {
      dataIndex: 'name_ru',
      key: 'name',
      title: <p>{t('DiscountPage.TableHead.name')}</p>,
      width: 160,
      ellipsis: true,
      sorter: (a, b) =>
        alphabeticalSort(
          getNestedValue(a, 'product.product_list.name_ru'),
          getNestedValue(b, 'product.product_list.name_ru'),
        ),
      render: (_, record) => getNestedValue(record, 'product.product_list.name_ru'),
    },
    {
      dataIndex: 'category',
      key: 'cost_price',
      width: 150,
      title: <p>{t('DiscountPage.TableHead.category')}</p>,
      align: 'center',
      ellipsis: true,
      render: (_, record) => makeSpaces(+(getNestedValue(record, 'product.cost_price') || 0)),
    },
    {
      dataIndex: 'subCategory',
      key: 'subCategory',
      align: 'center',
      ellipsis: true,
      title: <p>{t('DiscountPage.TableHead.subCategory')}</p>,
      render: (_, record) =>
        makeSpaces(+getNestedValue(record, 'product.product_list.subcategory.name_ru')),
    },
    {
      dataIndex: 'bar_code',
      key: 'bar_code',
      ellipsis: true,
      title: <p>{t('Products.BarCode')}</p>,
      render: (_, record) => (
        <Space>
          <MyPopup data={record.colours} keyLabel="name_ru" keyNumber="quantity" keyId="bar_code" />
          <Paragraph>{getNestedValue(record, 'bar_code')}</Paragraph>
        </Space>
      ),
    },
    {
      dataIndex: 'brand',
      key: 'brand',
      title: <p>{t('Products.Brand')}</p>,
      ellipsis: true,
      sorter: (a, b) =>
        alphabeticalSort(
          getNestedValue(a, 'product.product_list.brand.name_ru'),
          getNestedValue(b, 'product.product_list.brand.name_ru'),
        ),
      render: (_, record) => getNestedValue(record, 'product.product_list.brand.name_ru'),
    },
    {
      dataIndex: 'category',
      key: 'category_render',
      title: <p>{t('Products.Category')}</p>,
      ellipsis: true,
      render: (_, record) => getNestedValue(record, 'product.product_list.category.name_ru'),
    },
    {
      dataIndex: 'subcategory',
      key: 'subcategory_render',
      title: <p>{t('Products.SubCategoryRu')}</p>,
      ellipsis: true,
      sorter: (a, b) =>
        alphabeticalSort(
          getNestedValue(a, 'product.product_list.subcategory.name_ru'),
          getNestedValue(b, 'product.product_list.subcategory.name_ru'),
        ),
      render: (_, record) => getNestedValue(record, 'product.product_list.subcategory.name_ru'),
    },
  ];

  const header = (
    <Flex gap={16} style={{ marginBottom: 24 }}>
      <MyInput
        isFormItem={false}
        size="large"
        placeholder={t('Common.SearchByName')}
        suffix={<ISearch />}
      />
    </Flex>
  );

  const items: CollapseProps['items'] = data?.data.map((item) => ({
    key: item.id,
    headerClass: 'flex-x-center',
    label: (
      <Flex justify="space-between" align="center">
        <Space size={[20, 0]} style={{ alignItems: 'flex-end', fontWeight: 700 }}>
          <p>{`${t('store')} ${item.id}`}</p>
          <p>|</p>
          <p style={{ fontSize: '14px' }}>{formatTimestamp('2024-10-15T12:02:14.400428+05:00')}</p>
        </Space>

        <Space size={[20, 0]} style={{ fontWeight: 700 }}>
          <p>{`${t('Return.Cash')} ${item.id}`}</p>
        </Space>
      </Flex>
    ),
    children: (
      <MyTable
        tableProps={{
          loading: false,
          size: 'small',
          scroll: { x: 'max-content' },
          rowKey: 'id',
        }}
        columns={columns}
        dataSource={data.data}
      />
    ),
  }));

  return (
    <MyContent>
      <div>
        <Flex style={{ marginBottom: 24 }} justify="space-between">
          <MyTableTitles title={t('InvoicesPage.title')} subTitle={t('InvoicesPage.subtitle')} />
        </Flex>

        {header}
        <Collapse size="small" items={items} />
      </div>
    </MyContent>
  );
};
