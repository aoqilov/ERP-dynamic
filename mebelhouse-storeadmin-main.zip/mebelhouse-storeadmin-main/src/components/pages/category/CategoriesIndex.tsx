import { IPen, IPlus, ISearch, ITrash } from '@/components/svgs/svgs';
import MyButton from '@/components/ui/buttons/my-button/MyButton';
import MyInput from '@/components/ui/my-input/MyInput';
import MySelect from '@/components/ui/my-select/MySelect';
import DraggableTable, { DraggedInfo } from '@/components/ui/tables/DraggableTable';
import MyTable from '@/components/ui/tables/MyTable/MyTable';
import MyTableTitles from '@/components/ui/tables/MyTableTitles/MyTableTitles';
import TableImage from '@/components/ui/tables/table-image/TableImage';
import { Locale } from '@/i18n';
import { SERVER_URL } from '@/lib/consts/url.consts';
// import { addKey } from '@/lib/utils/addKey';
import { langConverterActions } from '@/lib/utils/langHandlers';
import { alphabeticalSort } from '@/lib/utils/sorters/alphabeticalSort';
import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
// import { useGetAllCategoriesQuery } from '@/store/services/categories/categories.api';
import { TCategoriesItem, TCategoriesList } from '@/store/services/categories/categories.type';
// import { useGetAllSubCategoriesQuery } from '@/store/services/sub-categories/sub-categories.api';
import { TSubCategoriesList } from '@/store/services/sub-categories/sub-categories.type';
import { openModal } from '@/store/slices/modal.slice';
import type { TableColumnsType } from 'antd';
import { Flex, Space, Tabs } from 'antd';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import MyContent from '../layout/MyContent';
import CategoryModals from './category-modals';

type TabsType = 'category' | 'subcategory' | 'position';

const CategoriesIndex = () => {
  const [tab, setTab] = useState<TabsType>('category');
  const { modalIsOpen, modalType } = useAppSelector((state) => state.modal);
  const dispatch = useAppDispatch();
  // const { data: categoryData, isLoading: catLoading } = useGetAllCategoriesQuery();
  const [dataSource] = useState<TCategoriesList | TSubCategoriesList>([]);
  const [categoryDataSource] = useState<TCategoriesList>([]);
  const [subCategoryDataSource] = useState<TSubCategoriesList>([]);
  // const { data: subCatData, isLoading: subCatLoading } = useGetAllSubCategoriesQuery();
  const [categoryDragged, setCategoryDragged] = useState<DraggedInfo | null>(null);
  const [catSubCategoryDragged, setSubCategoryDragged] = useState<DraggedInfo | null>(null);
console.log(categoryDragged)
  console.log(catSubCategoryDragged)
  // useSelect(categoryData?.data || []);

  useEffect(() => {
    // setCategoryDataSource(addKey(categoryData?.data || []));
    // setSubCategoryDataSource(addKey(subCatData?.data || []));
    // if (tab === 'category' && categoryData) {
    //   setDataSource(addKey(categoryData?.data));
    // } else if (tab === 'subcategory' && subCatData) {
    //   setDataSource(addKey(subCatData?.data));
    // } else {
    //   setDataSource([]);
    // }
  }, []);

  const {
    t,
    i18n: { language },
  } = useTranslation();

  const columnData = t(
    tab === 'category'
      ? 'CategoriesPage.TableColumns'
      : tab === 'subcategory'
      ? 'CategoriesPage.TableColumns2'
      : '',
    {
      returnObjects: true,
    },
  ) as Array<{
    title: string;
  }>;

  let columns: TableColumnsType<TCategoriesItem> = [
    {
      dataIndex: 'name_ru',
      key: 'name_ru',
      width: 500, // Adjust width to fit both picture and name
      title: t('CategoriesPage.TableColumns.name_ru'), // Translation for name_ru
      render: (text, record) => {
        if (tab === 'category') {
          return (
            <Flex align="center" gap={10}>
              <TableImage
                imgProps={{
                  src: `${SERVER_URL}/${record.picture?.picture}`,
                  preview: Boolean(record?.picture),
                  alt: record.name_ru,
                }}
              />
              <span>{text}</span>
            </Flex>
          );
        }
        return <span>{text}</span>;
      },
      sorter: (a: TCategoriesItem, b: TCategoriesItem) => alphabeticalSort(a.name_ru, b.name_ru),
    },
    {
      dataIndex: 'name_uz',
      key: 'name_uz',
      width: 450,
      title: t('CategoriesPage.TableColumns.name_uz'), // Translation for name_uz
      sorter: (a: TCategoriesItem, b: TCategoriesItem) => alphabeticalSort(a.name_uz, b.name_uz),
    },
    {
      dataIndex: 'actions',
      key: 'actions',
      render: (_text, record) => (
        <Space size="middle">
          <MyButton
            onClick={() =>
              dispatch(
                openModal({
                  modalType: {
                    component: tab === 'category' ? 'categories' : 'subCategory',
                    style: 'form',
                    manipulation: 'edit',
                  },
                  id: String(record.id),
                  data: dataSource?.find((item) => item.id === record.id),
                }),
              )
            }
            style={{ background: 'var(--color-blue)', width: 32, height: 32 }}
            icon={<IPen />}
          />
          <MyButton
            onClick={() => {
              dispatch(
                openModal({
                  id: String(record.id),
                  modalType: {
                    component: tab === 'category' ? 'categories' : 'subCategory',
                    style: 'delete',
                  },
                }),
              );
            }}
            style={{ background: 'var(--color-red)', width: 32, height: 32 }}
            icon={<ITrash />}
          />
        </Space>
      ),
      width: 165,
      align: 'end',
    },
  ];

  columns = columns.map((item, index) => {
    const translation = columnData[index];

    if (index === columns.length - 1) {
      return {
        ...item,
        title: langConverterActions(language as Locale),
      };
    }

    return {
      ...item,
      title: translation?.title,
    };
  });

  const handleChange = (value: string) => {
    console.log(value);
  };

  const topHeader = (
    <Flex gap={20}>
      <MyButton
        onClick={() =>
          dispatch(
            openModal({
              modalType: {
                component: 'categories',
                style: 'form',
                manipulation: 'add',
              },
            }),
          )
        }
        styleType="orange"
        icon={<IPlus />}
      >
        {t('CategoriesPage.Add')}
      </MyButton>
      <MyButton
        onClick={() =>
          dispatch(
            openModal({
              modalType: {
                component: 'subCategory',
                style: 'form',
                manipulation: 'add',
              },
            }),
          )
        }
        styleType="orange"
        icon={<IPlus />}
      >
        {t('CategoriesPage.Add2')}
      </MyButton>
    </Flex>
  );

  const tabItems: { label: string; key: TabsType }[] = [
    {
      label: t('CategoriesPage.Tab1'),
      key: 'category',
    },
    {
      label: t('CategoriesPage.Tab2'),
      key: 'subcategory',
    },
    {
      label: t('CategoriesPage.Tab3'),
      key: 'position',
    },
  ];

  const onTabChange = (tab: string) => {
    setTab(tab as TabsType);
  };

  const header = (
    <>
      <Flex gap={16} style={{ marginBottom: 24 }}>
        <MyInput
          isFormItem={false}
          size="large"
          placeholder={t('Common.SearchByName')}
          suffix={<ISearch />}
        />
        <MySelect
          size="large"
          defaultValue=""
          style={{ width: 156 }}
          onChange={handleChange}
          options={[
            { value: '', label: t('CategoriesPage.AllCategories') },
            { value: 'jack', label: 'Кашгар' },
            { value: 'lucy', label: 'Иппадром' },
          ]}
        />
      </Flex>
      <Tabs
        style={{ fontWeight: 700 }}
        onChange={onTabChange}
        defaultActiveKey="category"
        items={tabItems}
      />
    </>
  );

  const categoryPositionColumns: TableColumnsType<TCategoriesItem> = [
    {
      title: 'Наименование Ру',
      // t('CategoriesPage.TableColumns.name_ru'),
      dataIndex: 'name_ru',
      key: 'name_ru',
    },
    {
      title: 'Наименование Уз',
      // t('CategoriesPage.TableColumns.name_uz'),
      dataIndex: 'name_uz',
      key: 'name_uz',
    },
  ];

  return (
    <MyContent>
      <Flex style={{ marginBottom: 24 }} justify={topHeader ? 'space-between' : 'flex-start'}>
        <MyTableTitles title={t('Common.Categories')} subTitle={t('CategoriesPage.Manage')} />
        {topHeader}
      </Flex>
      {header}
      {tab !== 'position' && (
        <MyTable
          // tableProps={{
          //   loading: catLoading || subCatLoading,
          // }}
          columns={columns}
          dataSource={tab === 'category' ? categoryDataSource : subCategoryDataSource}
        />
      )}
      {tab === 'position' && (
        <DraggableTable<TCategoriesItem>
          setDragged={setCategoryDragged}
          // loading={catLoading || subCatLoading}
          columns={categoryPositionColumns}
          dataSource={categoryDataSource}
          expandable={{
            expandedRowRender: () => (
              <DraggableTable
              style={{paddingLeft: 40}}
                setDragged={setSubCategoryDragged}
                pagination={false}
                columns={categoryPositionColumns}
                dataSource={subCategoryDataSource}
                size="small"
              />
            ),
          }}
        />
      )}

      {modalType?.style === 'form' && modalIsOpen && (
        <CategoryModals btnContent={t('Common.Save')} styleType="singleBtn" />
      )}
    </MyContent>
  );
};

export default CategoriesIndex;
