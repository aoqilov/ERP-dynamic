import MyInput from '@/components/ui/my-input/MyInput';
import MySelect from '@/components/ui/my-select/MySelect';
import { useAppSelector } from '@/store/reduxHooks';
import { Flex } from 'antd';
import { useTranslation } from 'react-i18next';

const SubCategoryForm = () => {
  const { t } = useTranslation();
  const {
    selectData: { data },
    modal: { data: modalData },
  } = useAppSelector((state) => state);

  // const handleChange = (value: string) => {
  //   console.log(value);
  // };

  return (
    <Flex gap={16} vertical>
      {' '}
      <MySelect
        formItemProps={{ name: 'category', label: t('CategoriesPage.Category') }}
        size="large"
        defaultValue={modalData?.category?.name_ru || data?.[0]?.value}
        // onChange={handleChange}
        options={data!}
      />
      <MyInput
        formItemProps={{ name: 'name_ru', label: t('CategoriesPage.SubCategoryRu') }}
        style={{ width: '100%' }}
        id="name"
        title={t('CategoriesPage.SubCategoryRu')}
        size="large"
        placeholder={t('CategoriesPage.SubCategoryRu')}
      />
      <MyInput
        formItemProps={{ name: 'name_uz', label: t('CategoriesPage.SubCategoryUz') }}
        style={{ width: '100%' }}
        id="name"
        title={t('CategoriesPage.SubCategoryUz')}
        size="large"
        placeholder={t('CategoriesPage.SubCategoryUz')}
      />
    </Flex>
  );
};

export default SubCategoryForm;
