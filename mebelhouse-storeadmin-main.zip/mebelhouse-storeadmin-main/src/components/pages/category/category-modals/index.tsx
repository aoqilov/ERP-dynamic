import ModalWrapper from '@/components/ui/modal-wrapper/ModalWrapper';
import { ModalStyleType } from '@/lib/types/common.type';
import { getErrorMessage } from '@/lib/utils/getErrorMessage';
import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
import {
  useCreateCategoriesMutation,
  useUpdateCategoriesMutation,
} from '@/store/services/categories/categories.api';
import { TCreateCategoriesBody } from '@/store/services/categories/categories.type';
import {
  useCreateSubCategoriesMutation,
  useUpdateSubCategoriesMutation,
} from '@/store/services/sub-categories/sub-categories.api';
import { setFile } from '@/store/slices/file.slice';
import { closeModal } from '@/store/slices/modal.slice';
import { ModalProps, message } from 'antd';
import { useTranslation } from 'react-i18next';
import CategoryForm from './CategoryForm';
import SubCategoryForm from './SubCategoryForm';
import { getInitialValue } from '@/lib/utils/getInitialValue';

type CategoryModalsProps = ModalProps & {
  styleType?: ModalStyleType;
  btnContent?: string;
};

const CategoryModals = ({ styleType, btnContent, ...modalProps }: CategoryModalsProps) => {
  const { t } = useTranslation();
  const dispatch = useAppDispatch();
  const {
    modal: { modalType, data, id: categoryId },
    auth: { token },
    file: { id },
    selectData: { data: selectData },
  } = useAppSelector((state) => state);

  const [addCategory, { isLoading: addCatLoading }] = useCreateCategoriesMutation();
  const [updateCategory, { isLoading: updateCatLoading }] = useUpdateCategoriesMutation();

  const [addSubCategory, { isLoading: subCatLoading }] = useCreateSubCategoriesMutation();
  const [updateSubCat, { isLoading: updateSubCatLoading }] = useUpdateSubCategoriesMutation();

  const onFinish = async (
    values: TCreateCategoriesBody & { picture: number; category: number },
  ) => {
    if (modalType?.component === 'categories' && !id) {
      message.error(t('Common.UploadingRequired'));
      return;
    }
    let res = null;

    const body = {
      ...values,
      // picture: id,
    };

    if (modalType?.component === 'categories' && id) {
      body.picture = id;
    }

    //POST
    if (modalType?.manipulation === 'add') {
      if (modalType.component === 'categories') {
        res = await addCategory({ body, token });
      } else {
        res = await addSubCategory({ body, token });
      }
      //PATCH
    } else {
      if (modalType?.component === 'categories') {
        res = await updateCategory({ body, token, id: categoryId! as string });
      } else if (modalType?.component === 'subCategory') {
        res = await updateSubCat({ body, token, id: categoryId! as string });
      }
    }

    if (res?.data?.status_code === 201 || res?.data?.status_code === 200) {
      message.success(t('Common.Success'));
      dispatch(setFile(null));
      dispatch(closeModal());
    } else {
      message.error(getErrorMessage(res?.error));
    }
  };

  const modalTitleHandler = () => {
    if (modalType?.manipulation === 'add') {
      if (modalType.component === 'categories') {
        return 'CategoriesPage.Add';
      } else {
        return 'CategoriesPage.Add2';
      }
    } else {
      if (modalType?.component === 'categories') {
        return 'CategoriesPage.EditCategory';
      } else {
        return 'CategoriesPage.EditSubCategory';
      }
    }
  };

  const initialValues = {
    name_ru: getInitialValue(modalType, data?.name_ru),
    name_uz: getInitialValue(modalType, data?.name_uz),
    position: getInitialValue(modalType, data?.position),
    category: getInitialValue(modalType, data?.category?.name_ru, selectData?.[0]?.value),
  };

  return (
    <ModalWrapper
      formProps={{ onFinish, initialValues }}
      btnProps={{
        htmlType: 'submit',
        loading: addCatLoading || updateCatLoading || subCatLoading || updateSubCatLoading,
      }}
      modalTitle={t(modalTitleHandler()!)}
      btnContent={btnContent}
      styleType={styleType}
      {...modalProps}
    >
      {modalType?.component === 'subCategory' ? <SubCategoryForm /> : <CategoryForm />}
    </ModalWrapper>
  );
};

export default CategoryModals;
