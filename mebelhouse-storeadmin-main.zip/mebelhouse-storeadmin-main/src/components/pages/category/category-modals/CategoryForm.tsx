import MyInput from '@/components/ui/my-input/MyInput';
import MyUpload from '@/components/ui/my-upload/MyUpload';
import { Flex } from 'antd';
import { useTranslation } from 'react-i18next';

const CategoryForm = () => {
  const { t } = useTranslation();

  return (
    <>
      <Flex gap={28} style={{ marginBottom: 16 }}>
        <MyUpload type="photo" uploadProps={{ listType: 'picture-card', accept: 'image/*' }} />
        <MyInput
          formItemProps={{
            name: 'name_ru',
            label: t('CategoriesPage.CategoryRu'),
            style: { width: '100%' },
          }}
          style={{ width: '100%' }}
          id="name"
          title={t('CategoriesPage.CategoryRu')}
          size="large"
          placeholder={t('CategoriesPage.CategoryRu')}
        />
      </Flex>
      <MyInput
        formItemProps={{ name: 'name_uz', label: t('CategoriesPage.CategoryUz') }}
        style={{ width: '100%' }}
        id="name"
        title={t('CategoriesPage.CategoryUz')}
        size="large"
        placeholder={t('CategoriesPage.CategoryUz')}
      />
    </>
  );
};

export default CategoryForm;
