import { Suspense } from 'react';
import ShowroomProdLogIndex from './ShowroomProdLogIndex';

const ShowroomProdLogPage = () => {
  return (
    <Suspense fallback={null}>
      <ShowroomProdLogIndex />;
    </Suspense>
  );
};

export default ShowroomProdLogPage;
