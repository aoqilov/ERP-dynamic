import MyTable from '@/components/ui/tables/MyTable/MyTable';
import { formatTimestamp } from '@/lib/utils/formatters/dateFormatter';
import { alphabeticalSort } from '@/lib/utils/sorters/alphabeticalSort';
import {
  TGetAllShowroomProdLogResponse,
  TShowroomProductItem,
} from '@/store/services/showroom-prod-log/showroom-prod-log.type';
import { Flex, TableProps } from 'antd';
import Paragraph from 'antd/es/typography/Paragraph';
import { CollapseProps } from 'antd/lib';
import { t } from 'i18next';

type Props = {
  data: TGetAllShowroomProdLogResponse;
  isLoading?: boolean;
};

const ShowroomProdLogColumns = ({ data }: Props) => {
  const columns: TableProps<TShowroomProductItem>['columns'] = [
    {
      dataIndex: 'name_ru',
      key: 'name_ru',
      title: <p style={{ textWrap: 'nowrap' }}>{t('Common.Product')}</p>,
      ellipsis: true,
      sorter: (a, b) => alphabeticalSort(a?.name_ru, b?.name_ru),
      render: (_, record) => record?.name_ru,
    },

    {
      dataIndex: 'category',
      key: 'category',
      ellipsis: true,
      title: <p style={{ textWrap: 'nowrap' }}>{t('CategoriesPage.Category')}</p>,
      render: (_, record) => record?.category_name_ru,
    },
    {
      dataIndex: 'sub_category',
      key: 'sub_category',
      ellipsis: true,
      title: <p style={{ textWrap: 'nowrap' }}>{t('CategoriesPage.SubCategory')}</p>,
      render: (_, record) => record.sub_category_name_ru,
    },
    {
      dataIndex: 'barcode',
      key: 'barcode',
      ellipsis: true,
      title: <p style={{ textWrap: 'nowrap' }}>{t('Products.BarCode')}</p>,
      render: (_, record) => (
        <Paragraph style={{ marginBottom: '0' }} copyable>
          {record?.bar_code}
        </Paragraph>
      ),
    },
    {
      dataIndex: 'quantity',
      key: 'quantity',
      width: 150,
      align: 'center',
      title: <p style={{ textWrap: 'nowrap' }}>{t('Products.Quantity')}</p>,
    },
    // {
    //   dataIndex: 'origin_price',
    //   key: 'origin_price',
    //   ellipsis: true,
    //   title: <p style={{ textWrap: 'nowrap' }}>{t('Products.CostPrice')}</p>,
    //   render: (value) => formatNumberWithSpaces(value),
    // },
    // {
    //   dataIndex: 'sale_price',
    //   key: 'sale_price',
    //   ellipsis: true,
    //   title: <p style={{ textWrap: 'nowrap' }}>{t('Products.SalePrice')}</p>,
    //   render: (value) => formatNumberWithSpaces(value),
    // },
  ];

  const collapseItems: CollapseProps['items'] = data?.data?.map((item) => ({
    key: item.id,
    headerClass: 'flex-x-center',
    label: (
      <Flex justify="space-between">
        <div style={{ display: 'flex', gap: 10 }}>
          <span style={{ fontWeight: 700 }}>№{item.order_check_number}</span>
          <p>{formatTimestamp(+item.created_at)}</p>
        </div>
        <span>
          {t('ShowroomProdLog.TotalQty')}:&nbsp;
          <span style={{ fontWeight: 700 }}>{+item.total_quantity}</span>
        </span>
      </Flex>
    ),
    children: (
      <MyTable
        tableProps={{
          loading: false,
          size: 'small',
          scroll: { x: 'max-content' },
          rowKey: 'id',
        }}
        columns={columns}
        dataSource={item.products}
      />
    ),
  }));

  return collapseItems;
};

export default ShowroomProdLogColumns;
