import { ISearch } from '@/components/svgs/svgs';
import MyRangePicker from '@/components/ui/my-date-picker/MyDatePicker';
import MyInput from '@/components/ui/my-input/MyInput';
import MyTableBox from '@/components/ui/tables';
import { useDebounce } from '@/lib/hooks/useDebounce';
import useQueryParams from '@/lib/hooks/useQueryParams';
import { useAppSelector } from '@/store/reduxHooks';
import { useGetAllShowroomProdLogQuery } from '@/store/services/showroom-prod-log/showroom-prod-log.api';
import { Flex } from 'antd';
import { t } from 'i18next';
import { ChangeEvent, FC, useEffect, useState } from 'react';
import MyContent from '../layout/MyContent';
import ShowroomProdLogColumns from './ShowroomProdLogColumns';

const ShowroomProdLogIndex: FC = () => {
  const { token } = useAppSelector((state) => state.auth);
  const { setParams, getParam } = useQueryParams();
  const [search, setSearch] = useState('');
  const [period, setPeriod] = useState<[number | null, number | null] | null>();

  // const [dataSource, setDataSource] = useState<TShowroomProdLogList>([]);

  const debouncedSearch = useDebounce(search, 500);

  const { data, isLoading } = useGetAllShowroomProdLogQuery({
    token,
    page: +(getParam('current_page') || 1),
    page_size: +(getParam('page_size') || 10),
    search: debouncedSearch,
    created_at_from: String(period?.[0] || ''),
    created_at_to: String(period?.[1] || ''),
  });

  useEffect(() => {
    setParams({
      total_elements: String(data?.total_elements || 10),
      from: String(data?.from || 1),
      to: String(data?.to || 10),
      current_page: String(data?.current_page || 1),
    });
  }, [data?.data]);

  const handleSearchChange = (e: ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
  };

  const columns = ShowroomProdLogColumns({ data: data!, isLoading });

  const header = (
    <>
      <Flex gap={16} style={{ marginBottom: 24 }}>
        <MyInput
          onChange={handleSearchChange}
          isFormItem={false}
          size="large"
          placeholder={t('Common.Search')}
          suffix={<ISearch />}
        />
        <MyRangePicker setDates={setPeriod} rangePickerProps={{ width: '60%' }} />
      </Flex>
    </>
  );

  return (
    <MyContent>
      <MyTableBox
        isCollapse={true}
        collapseItems={columns}
        tableProps={{ loading: isLoading }}
        dataSource={data?.data!}
        paginationProps={{ total: 10, current: 5 }}
        columns={columns}
        tableTitles={{
          title: t('ShowroomProdLog.Title'),
          subTitle: t('ShowroomProdLog.Subtitle'),
        }}
        header={header}
      />
    </MyContent>
  );
};

export default ShowroomProdLogIndex;
