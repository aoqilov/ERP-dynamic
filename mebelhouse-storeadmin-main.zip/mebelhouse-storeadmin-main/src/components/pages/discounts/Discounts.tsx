import MyContent from "../layout/MyContent";

const Discounts = () => {
  return <MyContent><div>Process</div></MyContent>;
};

export default Discounts;
