import { HeaderProfile } from '@/components/ui/profile';
import { Flex, Layout } from 'antd';
import { FC, PropsWithChildren } from 'react';
import MyHeader from './MyHeader';
import { Sidebar } from './Sidebar';

export const DefaultLayout: FC<PropsWithChildren> = ({ children }) => (
  <Layout style={{ minHeight: '100dvh', flexDirection: 'row' }}>
    <Sidebar />

    <Layout>
      <MyHeader>
        <Flex style={{ height: '100%' }} align="center" justify="flex-end">
          <HeaderProfile />
        </Flex>
      </MyHeader>

      {children}
    </Layout>
  </Layout>
);
