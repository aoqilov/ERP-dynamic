import { theme } from 'antd';
import { Content } from 'antd/es/layout/layout';
import { FC, ReactNode } from 'react';

type Props = {
  children: ReactNode;
};

const MyContent: FC<Props> = ({ children }) => {
  const {
    token: { colorBgContainer,  },
  } = theme.useToken();

  return (
    <Content
      style={{
        margin: '32px 24px',
        padding: 24,
        minHeight: 280,
        background: colorBgContainer,
        borderRadius: 16,
      }}
    >
      {children}
    </Content>
  );
};
export default MyContent;
