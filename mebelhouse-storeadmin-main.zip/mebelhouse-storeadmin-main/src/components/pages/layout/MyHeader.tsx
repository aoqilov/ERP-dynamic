import { theme } from 'antd';
import { Header } from 'antd/es/layout/layout';
import { FC, ReactNode } from 'react';

type Props = {
  children: ReactNode;
};

const MyHeader: FC<Props> = ({ children }) => {
  const {
    token: { colorBgContainer },
  } = theme.useToken();

  return (
    <Header style={{ padding: 0, paddingRight: '20px', background: colorBgContainer }}>
      {children}
    </Header>
  );
};

export default MyHeader;
