import { IDouble } from '@/components/svgs/svgs';
import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
import { toggleSidebar } from '@/store/slices/sidebar.slice';
import clsx from 'clsx';
import { FC } from 'react';
import './sidebar-close-btn.css';

const SidebarCloseBtn: FC = () => {
  const dispatch = useAppDispatch();
  const sidebar = useAppSelector((state) => state.sidebar);
  const handleClick = () => {
    dispatch(toggleSidebar());
  };

  return (
    <button
      className={clsx('sidebar-close-btn', { 'sidebar-close-btn--open': !sidebar.isOpen })}
      type="button"
      onClick={handleClick}
    >
      {
        <IDouble
          className={clsx('sidebar-close-btn-icon', {
            'sidebar-close-btn-icon--rotate': !sidebar.isOpen,
          })}
        />
      }
    </button>
  );
};

export default SidebarCloseBtn;
