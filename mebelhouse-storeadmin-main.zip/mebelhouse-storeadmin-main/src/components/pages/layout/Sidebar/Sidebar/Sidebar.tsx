import Logo from '@/components/ui/logo/Logo';
import { useAppSelector } from '@/store/reduxHooks';
import { Button, ConfigProvider, Flex, Menu } from 'antd';
import Sider from 'antd/es/layout/Sider';
import { ItemType, MenuItemType } from 'antd/es/menu/interface';
import clsx from 'clsx';
import { FC } from 'react';
import { useTranslation } from 'react-i18next';
import { Link, useLocation } from 'react-router-dom';
import SidebarCloseBtn from '../SidebarCloseBtn/SidebarCloseBtn';
import { sidebarMenuItemsList } from '../sidebar-data';
import { ICategory } from '@/components/svgs/svgs';
import './sidebar.css';
import { ROUTES } from '@/constants';

export const Sidebar: FC = () => {
  const { isOpen } = useAppSelector((state) => state.sidebar);
  const pathname = useLocation().pathname;

  const { t } = useTranslation('');

  const sidebarData = t('SidebarData', { returnObjects: true }) as Array<{
    label: string;
    link: string;
  }>;

  const sidebarMenuItemsUpdated = sidebarMenuItemsList().map((item, index) => {
    const translation = sidebarData[index];

    return {
      ...item,
      label: translation.link ? (
        <Link to={translation.link}>{translation.label}</Link>
      ) : (
        translation.label
      ),
    };
  });

  return (
    <Sider
      width={250}
      style={{
        padding: !isOpen ? '0 20px 20px 20px' : '0 5px 5px 5px',
        background: 'white',
        borderRight: '1px solid #E9EAEC',
        height: '100vh',
        position: 'sticky',
        left: 0,
        bottom: 0,
        top: 0,
        zIndex: 20,
        overflow: 'auto',
      }}
      trigger={null}
      collapsible
      collapsed={isOpen}
    >
      <Flex style={{ margin: '24px 0' }} align="center" justify="space-between">
        {!isOpen && <Logo width={124} height={44} />}
        <SidebarCloseBtn />
      </Flex>

      <Link
        style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '100%' }}
        to={ROUTES.home}
      >
        <Button
          style={{ width: '100%' }}
          className={clsx('sidebar__dash-btn', {
            'sidebar__dash-btn--close': !isOpen,
          })}
          type="primary"
          icon={<ICategory />}
          iconPosition="end"
        >
          {!isOpen && t('Common.Dashboard')}
        </Button>
      </Link>

      <ConfigProvider
        theme={{
          components: {
            Menu: {
              itemSelectedBg: '#3838382c',
              itemSelectedColor: 'var(--color-text)',
              itemHeight: 52,
              itemHoverColor: 'var(--color-primary)',
              colorIconHover: 'var(--color-primary)',
              colorIcon: 'var(--color-gray)',
            },
          },
        }}
      >
        <Menu
          style={{ borderRight: 'none', fontWeight: 700 }}
          mode="inline"
          selectedKeys={[pathname]}
          items={sidebarMenuItemsUpdated as ItemType<MenuItemType>[]}
        />
      </ConfigProvider>
    </Sider>
  );
};
