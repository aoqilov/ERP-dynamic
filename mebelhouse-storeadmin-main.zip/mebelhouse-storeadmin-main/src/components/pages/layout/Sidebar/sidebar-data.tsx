import {
  ICartPlus,
  IInventory,
  IReturn,
  ISales,
  ITransactions,
  IUsers,
  IWarehouse,
} from '@/components/svgs/svgs';
import { ROUTES } from '@/constants';
import { ItemType, MenuItemType } from 'antd/es/menu/interface';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';

export const sidebarMenuItemsList = () => {
  const { t } = useTranslation();

  return [
    {
      key: ROUTES.employees,
      icon: <IUsers />,
    },
    {
      key: ROUTES.warehouse,
      icon: <IWarehouse />,
    },
    {
      key: '/transactions',
      icon: <ITransactions />,
      children: [
        {
          key: '/transactions/pending',
          type: 'item',
          label: <Link to={'/transactions/pending'}>{t('TransferPage.Status.pending')}</Link>,
        },
        {
          key: '/transactions/accepted',
          type: 'item',
          label: <Link to={'/transactions/accepted'}>{t('TransferPage.Status.accepted')}</Link>,
        },
        {
          key: '/transactions/rejected',
          type: 'item',
          label: <Link to={'/transactions/rejected'}>{t('TransferPage.Status.rejected')}</Link>,
        },
      ],

      // label: <Link href="/orders">Orders</Link>,
    },
    // {
    //   key: '/invoices',
    //   icon: <IInvocies />,
    // },

    {
      key: '/order',
      icon: <ISales />,
    },
    {
      key: '/inventory',
      icon: <IInventory />,
    },
    {
      key: '/showroom-prod-log',
      icon: <ICartPlus />,
    },
    {
      key: '/clients',
      icon: <IUsers />,
    },
    {
      key: '/return-order',
      icon: <IReturn />,
    },
  ] as ItemType<MenuItemType>[];
};
