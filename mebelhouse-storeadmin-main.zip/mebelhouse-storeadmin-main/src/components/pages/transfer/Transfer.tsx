import { ISearch } from '@/components/svgs/svgs';
import MyRangePicker from '@/components/ui/my-date-picker/MyDatePicker';
import { MyInput } from '@/components/ui/my-input';
import MyPagination from '@/components/ui/tables/MyPagination/MyPagination';
import MyTable from '@/components/ui/tables/MyTable/MyTable';
import MyTableTitles from '@/components/ui/tables/MyTableTitles/MyTableTitles';
import { useDebounce } from '@/lib/hooks/useDebounce';
import useQueryParams from '@/lib/hooks/useQueryParams';
import { calcTransferQuantity } from '@/lib/utils/calcTransferQuantity';
import { formatTimestamp } from '@/lib/utils/formatters/dateFormatter';
import { formatNumberWithSpaces } from '@/lib/utils/formatters/formatNumberWithSpaces';
import { useAppSelector } from '@/store/reduxHooks';
import { useGetAllTransferQuery } from '@/store/services/transfer/transfer.api';
import { TTransferInnerItem, TTransferStatus } from '@/store/services/transfer/transfer.type';
import { Collapse, CollapseProps, Empty, Flex, Space, Spin, TableProps } from 'antd';
import Paragraph from 'antd/es/typography/Paragraph';
import { ChangeEvent, FC, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'react-router-dom';
import MyContent from '../layout/MyContent';
import TransferActions from './TransferActions';
import TransferStatusModal from './TransferStatusModal';

const TransferIndex: FC = () => {
  const { t } = useTranslation();
  const location = useLocation();
  const pathname = location.pathname;
  const transferStatus = pathname.substring(pathname.lastIndexOf('/') + 1) as TTransferStatus;
  const token = useAppSelector((state) => state?.auth?.token);
  const { getParam, setParams } = useQueryParams();
  // const [storeId, setStoreId] = useState('');
  const [period, setPeriod] = useState<[number | null, number | null] | null>();
  const [search, setSearch] = useState('');
  const debounceSearchName = useDebounce(search, 300);

  // const { data: storeData } = useGetAllShowroomsSelectQuery({ token });

  const { modalIsOpen, modalType } = useAppSelector((state) => ({
    modalIsOpen: state?.modal?.modalIsOpen,
    modalType: state?.modal?.modalType,
  }));

  const getAllTransferResult = useGetAllTransferQuery({
    token,
    status: transferStatus as any,
    page_size: +(getParam('page_size') || 10),
    page: +(getParam('current_page') || 1),
    pagination: true,
    // showroom_id: storeId,
    search: debounceSearchName,
    created_at_from: String(period?.[0] || ''),
    created_at_to: String(period?.[1] || ''),
    // search: debounceSearchName,
  });

  // const storeList = convertDataForSelect({
  //   data: storeData?.data,
  //   label: 'name',
  //   extraOption: { label: t('StoresPage.AllStores'), value: '' },
  // });

  useEffect(() => {
    setParams({
      total_elements: String(getAllTransferResult.data?.total_elements || 10),
      from: String(getAllTransferResult.data?.from || 1),
      to: String(getAllTransferResult.data?.to || 10),
      current_page: String(getAllTransferResult.data?.current_page || 1),
    });
  }, [getAllTransferResult?.data?.data]);

  useEffect(() => {
    getAllTransferResult?.refetch();
  }, [location?.pathname]);

  const transferIsEmpty =
    !getAllTransferResult?.isLoading &&
    !getAllTransferResult?.isFetching &&
    getAllTransferResult?.isSuccess &&
    !getAllTransferResult?.data?.data?.length;

  const columnReasonItem: TableProps<TTransferInnerItem>['columns'] = [
    {
      dataIndex: 'reason',
      key: 'reason',
      ellipsis: true,
      title: <p style={{ textWrap: 'nowrap' }}>{t('Products.Reason')}</p>,
      render: (reason) => reason || '—',
    },
  ];

  const columns: TableProps<TTransferInnerItem>['columns'] = [
    {
      dataIndex: 'product_name_ru',
      key: 'product_name_ru',
      title: <p style={{ textWrap: 'nowrap' }}>{t('Products.NameRu')}</p>,
      ellipsis: true,

      // verticalAlign: 'middle',
      // sorter: (a, b) =>
      //   alphabeticalSort(a?.product?.product_list?.name_ru, b?.product?.product_list?.name_ru),
      render: (_, record) => record?.product_name_ru,
    },
    {
      dataIndex: 'category',
      key: 'category',
      title: <p style={{ textWrap: 'nowrap' }}>{t('Products.SubCategoryRu')}</p>,
      ellipsis: true,
      render: (_, record) => record?.sub_category_name_ru,
    },
    {
      dataIndex: 'color',
      key: 'color',
      title: <p style={{ textWrap: 'nowrap' }}>{t('Settings.Color')}</p>,
      ellipsis: true,
      render: (_, record) => record?.product_colour_name_ru,
    },
    {
      dataIndex: 'cost_price',
      key: 'cost_price',
      width: 150,

      title: <p style={{ textWrap: 'nowrap' }}>{t('Products.CostPrice')}</p>,
      ellipsis: true,
      render: (_, record) => formatNumberWithSpaces(+(record?.origin_price || 0)),
    },

    {
      dataIndex: 'sale_price',
      key: 'sale_price',
      ellipsis: true,

      title: <p style={{ textWrap: 'nowrap' }}>{t('Products.SalePrice')}</p>,
      render: (_, record) => formatNumberWithSpaces(+(record?.sale_price || 0)),
    },
    {
      dataIndex: 'quantity',
      key: 'quantity',
      align: 'center',
      title: <p style={{ textWrap: 'nowrap' }}>{t('Products.Quantity')}</p>,
      render: (_, record) => calcTransferQuantity(record, transferStatus) + ' шт',
      // <MyPopup
      //   data={record?.product?.colors}
      //   keyLabel="color_name"
      //   keyNumber="quantity"
      //   keyId="color_id"
      // />
    },
    {
      dataIndex: 'marga',
      key: 'marga',
      width: 150,

      title: <p style={{ textWrap: 'nowrap' }}>{t('Products.Marga')}</p>,
      align: 'center',
      ellipsis: true,

      render: (marga) => `${marga}%`,
    },
    {
      dataIndex: 'barcode',
      key: 'barcode',
      ellipsis: true,
      title: <p style={{ textWrap: 'nowrap' }}>{t('Products.BarCode')}</p>,
      render: (_, record) => (
        <Paragraph style={{ marginBottom: '0' }} copyable>
          {record?.product_barcode}
        </Paragraph>
      ),
    },
    ...(transferStatus === 'rejected' || transferStatus === 'cancelled' ? columnReasonItem : []),
  ];

  const handleSearchChange = (e: ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
  };

  // const handleStoreChange = (value: string) => {
  //   setStoreId(value);
  // };

  const header = (
    <>
      <Flex gap={16} style={{ marginBottom: 24 }}>
        <MyInput
          onChange={handleSearchChange}
          isFormItem={false}
          size="large"
          placeholder={t('Common.SearchByName')}
          suffix={<ISearch />}
        />
        <MyRangePicker setDates={setPeriod} rangePickerProps={{ width: '60%' }} />
        {/* <MySelect
          size="large"
          defaultValue=""
          style={{ width: 156 }}
          onChange={handleStoreChange}
          options={storeList}
        /> */}
      </Flex>
    </>
  );

  const items: CollapseProps['items'] = getAllTransferResult?.data?.data?.map(
    ({ id, created_at, items, showroom, status }) => {
      return {
        key: id,
        headerClass: 'flex-x-center',
        label: (
          <Space size={[20, 0]} style={{ alignItems: 'flex-end', display: 'flex' }}>
            <p>{showroom?.name}</p>
            <p style={{ fontSize: '14px' }}>{formatTimestamp(+created_at)}</p>
            {/* <Tag color={{ out: 'blue', in: 'green' }[direction]}>
              {{ out: 'Вывоз', in: 'Ввоз' }[direction]}
              {direction}
            </Tag> */}
          </Space>
        ),
        children: (
          <MyTable
            tableProps={{
              loading: false,
              size: 'small',
              scroll: { x: 'max-content' },
              rowKey: 'product_id',
            }}
            columns={columns}
            dataSource={items}
          />
        ),
        extra:
          status === 'pending' ? (
            <TransferActions transferId={id} transferItems={items} />
          ) : undefined,
      };
    },
  );

  return (
    <MyContent>
      <div style={{ marginBottom: 20 }}>
        <Flex style={{ marginBottom: 24 }} justify={'space-between'}>
          <MyTableTitles
            title={t(`TransferPage.Status.${transferStatus}`)}
            subTitle={t('TransferPage.SubTitle')}
          />
        </Flex>
        {header}
        {getAllTransferResult?.isLoading ? (
          <Spin className="flex-center" style={{ height: '30vh' }} />
        ) : transferIsEmpty ? (
          <Empty style={{ marginTop: '80px' }} />
        ) : (
          <>
            <Collapse size="small" items={items} />
            {(items?.length || 0) > 10 && (
              <div style={{ marginTop: 24 }}>
                <MyPagination paginationProps={{ total: 10, current: 5 }} />
              </div>
            )}
          </>
        )}
      </div>
      {modalIsOpen && modalType?.component === 'productsTransfer' && <TransferStatusModal />}
      {/* <MyPagination /> */}
    </MyContent>
  );
};

export default TransferIndex;
