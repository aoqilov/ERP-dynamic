import ModalWrapper from '@/components/ui/modal-wrapper/ModalWrapper';
import NumberInput from '@/components/ui/NumberInput';
import useQueryParams from '@/lib/hooks/useQueryParams';
import { calcTransferQuantity } from '@/lib/utils/calcTransferQuantity';
import { getErrorMessage } from '@/lib/utils/getErrorMessage';
import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
import {
  useAcceptTransferMutation,
  useRejectTransferMutation,
} from '@/store/services/transfer/transfer.api';
import {
  TAcceptTransferBody,
  TRejectTransferBody,
  TTransferInnerItem,
} from '@/store/services/transfer/transfer.type';
import { closeModal } from '@/store/slices/modal.slice';
import { Input, message, Table, Tag } from 'antd';
import { TableProps } from 'antd/lib';
import { FC, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

type Props = {};

const TransferStatusModal: FC<Props> = () => {
  const [transferBody, setTransferBody] = useState<
    TAcceptTransferBody['items'] | TRejectTransferBody['items']
  >([]);
  const [errorsId, setErrorsId] = useState<string[]>([]);
  const { t } = useTranslation();
  const dispatch = useAppDispatch();
  const { token, transferItems, transferId, modalIsOpen } = useAppSelector((state) => ({
    token: state?.auth?.token,
    transferItems: state?.modal?.data as TTransferInnerItem[],
    transferId: state?.modal?.id as string,
    modalIsOpen: state?.modal?.modalIsOpen,
  }));
  const { getParam } = useQueryParams();

  const actionType = getParam('action-type') as 'accept' | 'reject';

  const [rejectTransferTrigger, rejectTransferResult] = useRejectTransferMutation();
  const [acceptTransferTrigger, acceptTransferResult] = useAcceptTransferMutation();

  const handleSetTransferProduct = ({
    quantity,
    id,
    reason,
  }: {
    quantity?: string;
    id: string;
    reason?: string;
  }) => {
    const transferProductIndex = transferBody?.findIndex((item) => item?.product?.id === id);
    const newReason = reason === undefined ? transferBody[transferProductIndex]?.reason : reason;
    const newQuantity = Number(quantity || transferBody[transferProductIndex]?.quantity || 0);
    let values = structuredClone(transferBody);

    if (transferProductIndex !== -1) {
      values[transferProductIndex] = {
        product: { id },
        quantity: newQuantity,
        reason: newReason,
      };
    } else {
      values.push({ product: { id }, quantity: newQuantity, reason: newReason });
    }
    setTransferBody(values);
  };

  const closedModal = () => {
    dispatch(closeModal());
  };

  const handleSubmit = async () => {
    const transferItems = transferBody.filter(({ quantity }) => quantity > 0);
    if (transferItems?.length === 0) return message.error('Заполните поля');

    if (actionType === 'accept') {
      acceptTransferTrigger({
        token,
        body: {
          transfer: { id: transferId as string },
          items: transferItems,
        },
      });
    } else if (actionType === 'reject') {
      const haveEmpty = transferItems?.filter(({ product, quantity, reason }) => {
        if (quantity > 0 && Boolean(reason)) return false;
        setErrorsId((prev) => [...prev, product?.id]);
        return true;
      });
      if (haveEmpty.length) return;

      rejectTransferTrigger({
        token,
        body: {
          transfer: { id: transferId as string },
          items: transferItems,
        },
      });
    }
  };

  console.log(transferBody);

  useEffect(() => {
    if (rejectTransferResult?.isError) {
      setErrorsId([]);
      message.error(getErrorMessage(rejectTransferResult?.error));
    } else if (rejectTransferResult?.isSuccess) {
      setTransferBody([]);
      message.success('Удачно');
      setErrorsId([]);
      closedModal();
    }
    if (acceptTransferResult?.isError) {
      setErrorsId([]);
      message.error(getErrorMessage(acceptTransferResult?.error));
    } else if (acceptTransferResult?.isSuccess) {
      setTransferBody([]);
      message.success('Удачно');
      setErrorsId([]);
      closedModal();
    }
  }, [
    rejectTransferResult?.isError,
    rejectTransferResult?.isSuccess,
    rejectTransferResult?.error,
    acceptTransferResult?.isError,
    acceptTransferResult?.isSuccess,
    acceptTransferResult?.error,
  ]);

  const modalTitle = {
    accept: t('Принятие продукции'),
    reject: t('Отменение'),
  }[actionType];

  // const setTransferFullQuantity = (checked: boolean) => {
  //   if (!checked) {
  //     const transferFullQuantity = transferItems.map(({ id, quantity }) => ({
  //       id,
  //       quantity: Number(quantity || 0),
  //     }));
  //     setTransferProducts(transferFullQuantity);
  //     setIsFulledQuantity(true);
  //   } else {
  //     setTransferProducts([]);
  //     setIsFulledQuantity(false);
  //   }
  // };

  const reasonColumn: TableProps<TTransferInnerItem>['columns'] = [
    {
      title: 'Причина отмены',
      dataIndex: 'reason',
      key: 'reason',
      onCell: () => ({
        style: { paddingBlock: 0 },
      }),
      render: (_, record) => {
        return (
          <Input
            status={errorsId.includes(record?.product_id) ? 'error' : ''}
            onChange={(e) => {
              handleSetTransferProduct({
                id: record?.product_id,
                reason: e?.target?.value,
              });
              if (errorsId?.includes(record?.product_id)) {
                setErrorsId((prev) => prev.filter((id) => id !== record?.product_id));
              }
            }}
            placeholder="Причина"
            type="text"
            style={{ width: 200 }}
            size="large"
          />
        );
      },
    },
  ];

  const columns: TableProps<TTransferInnerItem>['columns'] = [
    {
      title: 'Товары',
      dataIndex: 'product_name',
      key: 'product_name',
      render: (_, { product_name_ru }) => (
        <div style={{ minWidth: 160 }}> {product_name_ru || 'Товар'}</div>
      ),
    },
    {
      dataIndex: 'color',
      key: 'color',
      title: <p style={{ textWrap: 'nowrap' }}>{t('Settings.Color')}</p>,
      ellipsis: true,
      render: (_, record) => record?.product_colour_name_ru,
    },
    {
      title: 'Кол-во',
      dataIndex: 'quantity',
      key: 'quantity',
      align: 'center',
      render: (_, record) => {
        const quantity = calcTransferQuantity(record);
        return <Tag color={quantity === 0 ? 'error' : ''}>{quantity} шт</Tag>;
      },
    },
    Table.SELECTION_COLUMN,
    {
      title: 'Выбор',
      dataIndex: 'action',
      key: 'action',
      align: 'center',
      width: 'min-content',
      render: (_, record) => {
        const product = transferBody.find((item) => item?.product?.id === record?.product_id);
        return (
          <NumberInput
            max={calcTransferQuantity(record)}
            setValue={(val) => handleSetTransferProduct({ quantity: val, id: record?.product_id })}
            value={product ? product?.quantity.toString() : '0'}
          />
        );
      },
    },
    ...(actionType === 'reject' ? reasonColumn : []),
  ];

  const handleRowSelection = (selectedRowKeys: React.Key[], selectedRows: TTransferInnerItem[]) => {
    if (!selectedRowKeys) return setTransferBody([]);
    const selectedTransferBody: typeof transferBody = selectedRows?.map((transferItem) => {
      return {
        ...transferBody?.find(({ product }) => {
          product?.id === transferItem?.product_id;
        }),
        product: { id: transferItem?.product_id },
        quantity: calcTransferQuantity(transferItem),
      };
    });
    setTransferBody(selectedTransferBody);
  };

  return (
    modalIsOpen && (
      <ModalWrapper
        width="fit-content"
        btnProps={{
          htmlType: 'submit',
          onClick: handleSubmit,
          loading: rejectTransferResult?.isLoading || acceptTransferResult?.isLoading,
        }}
        modalTitle={modalTitle}
        btnContent={actionType === 'accept' ? 'Принять' : 'Отказать'}
        styleType="singleBtn"
      >
        <Table
          rowSelection={{
            type: 'checkbox',
            // selectedRowKeys,
            onChange: handleRowSelection,
            onSelect: (record, selected) => {
              handleSetTransferProduct({
                id: record?.product_id,
                quantity: selected ? calcTransferQuantity(record)?.toString() : '0',
              });
            },
          }}
          pagination={false}
          scroll={{ x: 'max-content' }}
          dataSource={transferItems}
          columns={columns}
          rowKey={'product_id'}
        />
      </ModalWrapper>
    )
  );
};

export default TransferStatusModal;
