import ButtonSquare from '@/components/ui/buttons/ButtonSquare';
import useQueryParams from '@/lib/hooks/useQueryParams';
import { calcTransferQuantity } from '@/lib/utils/calcTransferQuantity';
import { useAppDispatch } from '@/store/reduxHooks';
import { TTransferInnerItem } from '@/store/services/transfer/transfer.type';
import { openModal } from '@/store/slices/modal.slice';
import { Flex } from 'antd';
import { FC } from 'react';

type Props = {
  transferId: string;
  transferItems: TTransferInnerItem[];
};

const TransferActions: FC<Props> = ({ transferId, transferItems }) => {
  const dispatch = useAppDispatch();
  const { setParams } = useQueryParams();

  const cleanedTransferItems = transferItems?.filter((record) => calcTransferQuantity(record) > 0);

  const openedModal = (type: 'accept' | 'reject') => {
    setParams({ 'action-type': type });

    dispatch(
      openModal({
        data: cleanedTransferItems,
        id: transferId,
        modalType: {
          component: 'productsTransfer',
          style: 'form',
          manipulation: 'edit',
        },
      }),
    );
  };

  return (
    <Flex gap={20} onClick={(e) => e.stopPropagation()}>
      <ButtonSquare
        theme="green"
        onClick={() => {
          openedModal('accept');
        }}
        disabled={!cleanedTransferItems?.length}
      >
        Принять
      </ButtonSquare>
      <ButtonSquare
        theme="red"
        onClick={() => {
          openedModal('reject');
        }}
        disabled={!cleanedTransferItems?.length}
      >
        Отменить
      </ButtonSquare>
    </Flex>
  );
};

export default TransferActions;
