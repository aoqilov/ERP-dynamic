import MyPopup from '@/components/ui/my-pop-up/MyPopup';
import MyTable from '@/components/ui/tables/MyTable/MyTable';
import { formatCurrency } from '@/lib/utils/formatters/currencyFormatter';
import { formatTimestamp } from '@/lib/utils/formatters/dateFormatter';
import { formatNumberWithSpaces } from '@/lib/utils/formatters/formatNumberWithSpaces';
import { alphabeticalSort } from '@/lib/utils/sorters/alphabeticalSort';
import {
  TGetAllSalesResponse,
  TProductSalesItem,
  TSalesItem,
} from '@/store/services/sales/sales.type';
import { Collapse, Flex, Space, TableProps } from 'antd';
import Paragraph from 'antd/es/typography/Paragraph';
import { CollapseProps } from 'antd/lib';
import { t } from 'i18next';
import { TabsTypeSales } from './SalesIndex';
import { filterUniqueLocations } from '@/lib/utils/filterUniqueLocations';

type Props = {
  data: TGetAllSalesResponse;
  isLoading: boolean;
  tab: TabsTypeSales;
};

const SalesColumns = ({ data, isLoading, tab }: Props) => {
  const columns: TableProps<TProductSalesItem>['columns'] = [
    {
      dataIndex: 'product_name_ru',
      key: 'product_name_ru',
      title: <p style={{ textWrap: 'nowrap' }}>{t('Common.Product')}</p>,
      ellipsis: true,
      sorter: (a, b) => alphabeticalSort(a?.product_name_ru, b?.product_name_ru),
      render: (_, record) => record?.product_name_ru,
    },
    {
      dataIndex: 'quantity',
      key: 'quantity',
      width: 150,
      align: 'center',
      title: <p style={{ textWrap: 'nowrap' }}>{t('Products.Quantity')}</p>,
      render: (_, record) => {
        return (
          <Space size={[10, 10]}>
            <MyPopup data={record?.quantities} keyLabel="color_ru" keyNumber="quantity" />
            {record?.quantities && record?.quantities.length > 0
              ? record?.quantities.reduce((acc, item) => acc + +item.quantity, 0)
              : t('Common.NotInStock')}
          </Space>
        );
      },
    },
    {
      dataIndex: 'category',
      key: 'category',
      ellipsis: true,
      title: <p style={{ textWrap: 'nowrap' }}>{t('CategoriesPage.Category')}</p>,
      render: (_, record) => record?.category_name_ru,
    },
    {
      dataIndex: 'sub_category',
      key: 'sub_category',
      ellipsis: true,
      title: <p style={{ textWrap: 'nowrap' }}>{t('CategoriesPage.SubCategory')}</p>,
      render: (_, record) => record.subcategory_name_ru,
    },
    {
      dataIndex: 'barcode',
      key: 'barcode',
      ellipsis: true,
      title: <p style={{ textWrap: 'nowrap' }}>{t('Products.BarCode')}</p>,
      render: (_, record) => (
        <Paragraph style={{ marginBottom: '0' }} copyable>
          {record?.bar_code}
        </Paragraph>
      ),
    },
    {
      dataIndex: 'origin_price',
      key: 'origin_price',
      ellipsis: true,
      title: <p style={{ textWrap: 'nowrap' }}>{t('Products.CostPrice')}</p>,
      render: (value) => formatNumberWithSpaces(value),
    },
    {
      dataIndex: 'sale_price',
      key: 'sale_price',
      ellipsis: true,
      title: <p style={{ textWrap: 'nowrap' }}>{t('Products.SalePrice')}</p>,
      render: (value) => formatNumberWithSpaces(value),
    },
  ];

  const itemsNest = (item: TSalesItem): CollapseProps['items'] => {
    return item?.locations?.map((nestedItem, index) => {
      return {
        key: String(index),
        label: nestedItem.location_name,
        children: (
          <MyTable
            tableProps={{
              loading: isLoading,
              size: 'middle',
              scroll: { x: 'max-content' },
              rowKey: 'id',
            }}
            columns={columns}
            dataSource={nestedItem.products}
          />
        ),
      };
    });
  };

  const collapseItems: CollapseProps['items'] = filterUniqueLocations(data?.data)?.map((item) => ({
    key: item.id,
    headerClass: 'flex-x-center',
    label: (
      <Flex justify="space-between">
        <div style={{ display: 'flex', gap: 10 }}>
          <span style={{ fontWeight: 700 }}>№{item.order_number}</span>
          {tab === 'set' && <span style={{ fontWeight: 700 }}>СЭТ {item.set?.name}</span>}
          <p>{formatTimestamp(+item.sold_time)}</p>
        </div>
        <span style={{ fontWeight: 700 }}>{formatCurrency(+item.total_price)}</span>
      </Flex>
    ),
    children: <Collapse items={itemsNest(item)} />,
  }));

  return collapseItems;
};

export default SalesColumns;
