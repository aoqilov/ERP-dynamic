import SalesIndex from './SalesIndex';
export const SalesPage = SalesIndex;
