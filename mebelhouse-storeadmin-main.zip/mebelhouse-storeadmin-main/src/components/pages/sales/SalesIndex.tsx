import { IDownload, ISearch } from '@/components/svgs/svgs';
import MyRangePicker from '@/components/ui/my-date-picker/MyDatePicker';
import MyInput from '@/components/ui/my-input/MyInput';
import MyTableBox from '@/components/ui/tables';
import { useDebounce } from '@/lib/hooks/useDebounce';
import useQueryParams from '@/lib/hooks/useQueryParams';
import { useAppSelector } from '@/store/reduxHooks';
import {
  useGetAllProductsSalesQuery,
  useLazyGetAllSalesDownloadQuery,
} from '@/store/services/sales/sales.api';
import { Flex, Tabs } from 'antd';
import { t } from 'i18next';
import { ChangeEvent, FC, useEffect, useState } from 'react';
import MyContent from '../layout/MyContent';
import SalesColumns from './SalesColumns';
import { handleDownloadFile } from '@/lib/utils/downloadHandler';
import MyButton from '@/components/ui/buttons/my-button/MyButton';

export type TabsTypeSales = 'products' | 'set';

const SalesIndex: FC = () => {
  const { token } = useAppSelector((state) => state.auth);
  const { setParams, getParam } = useQueryParams();
  const [search, setSearch] = useState('');
  const [period, setPeriod] = useState<[number | null, number | null] | null>();
  const [tab, setTab] = useState<TabsTypeSales>('products');
  // const [dataSource, setDataSource] = useState<TSalesList>([]);

  const debouncedSearch = useDebounce(search, 500);

  const { data, isLoading } = useGetAllProductsSalesQuery({
    sets: tab === 'set',
    token,
    pagination: true,
    page: +(getParam('current_page') || 1),
    page_size: +(getParam('page_size') || 10),
    search: debouncedSearch,
    created_at_from: String(period?.[0] || ''),
    created_at_to: String(period?.[1] || ''),
  });

  const [triggerDownload, { isFetching }] = useLazyGetAllSalesDownloadQuery();

  const handleDownload = async () => {
    const { data, error } = await triggerDownload({
      token,
      sets: tab === 'set',
      created_at_from: String(period?.[0] || ''),
      created_at_to: String(period?.[1] || ''),
      search: debouncedSearch,
    });

    handleDownloadFile({ data: data!, error, fileName: t('Sales.Sales') });
  };

  useEffect(() => {
    setParams({
      total_elements: String(data?.total_elements || 10),
      from: String(data?.from || 1),
      to: String(data?.to || 10),
      current_page: String(data?.current_page || 1),
    });
  }, [data?.data]);

  const handleSearchChange = (e: ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
  };

  const columns = SalesColumns({ data: data!, isLoading, tab });

  const tabItems: { label: string; key: TabsTypeSales }[] = [
    {
      label: t('Products.Products'),
      key: 'products',
    },
    {
      label: t('Products.Sets'),
      key: 'set',
    },
  ];

  const onTabChange = (tab: string) => {
    setTab(tab as TabsTypeSales);
    setParams({ current_page: String(1) });
  };

  const topHeader = (
    <MyButton loading={isFetching} onClick={handleDownload} styleType="white" icon={<IDownload />}>
      {t('Common.Download')}
    </MyButton>
  );

  const header = (
    <>
      <Flex gap={16} style={{ marginBottom: 24 }}>
        <MyInput
          onChange={handleSearchChange}
          isFormItem={false}
          size="large"
          placeholder={t('Common.SearchByName')}
          suffix={<ISearch />}
        />
        <MyRangePicker setDates={setPeriod} rangePickerProps={{ width: '60%' }} />
      </Flex>
      <Tabs
        style={{ fontWeight: 700 }}
        onChange={onTabChange}
        defaultActiveKey="1"
        items={tabItems}
      />
    </>
  );

  return (
    <MyContent>
      <MyTableBox
        isCollapse={true}
        collapseItems={columns}
        tableProps={{ loading: isLoading }}
        dataSource={data?.data!}
        paginationProps={{ total: 10, current: 5 }}
        columns={columns}
        tableTitles={{
          title: t('Sales.Sales'),
          subTitle: t('Sales.SalesList'),
        }}
        topHeader={topHeader}
        header={header}
      />
    </MyContent>
  );
};

export default SalesIndex;
