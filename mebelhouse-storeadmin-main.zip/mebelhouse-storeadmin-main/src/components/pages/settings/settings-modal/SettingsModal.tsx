import ModalWrapper from '@/components/ui/modal-wrapper/ModalWrapper';
import { ModalStyleType } from '@/lib/types/common.type';
import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
import { ModalProps, message } from 'antd';
import { useTranslation } from 'react-i18next';
import SettingsForm from './SettingsForm';
import { useCreateColorMutation, useUpdateColorMutation } from '@/store/services/color/color.api';
import { TCreateColorBody } from '@/store/services/color/color.type';
import { getErrorMessage } from '@/lib/utils/getErrorMessage';
import { closeModal } from '@/store/slices/modal.slice';
import { useCreateBrandMutation, useUpdateBrandMutation } from '@/store/services/brand/brand.api';
import {
  useCreateRegionMutation,
  useUpdateRegionMutation,
} from '@/store/services/region/region.api';
import { getInitialValue } from '@/lib/utils/getInitialValue';

type SettingsModalProps = ModalProps & {
  styleType?: ModalStyleType;
  btnContent?: string;
};

const SettingsModal = ({ styleType, btnContent, ...modalProps }: SettingsModalProps) => {
  const { t } = useTranslation();
  const dispatch = useAppDispatch();
  const {
    modal: { modalType, id, data },
    auth: { token },
  } = useAppSelector((state) => state);
  const [addColor, { isLoading: colorLoading }] = useCreateColorMutation();
  const [addBrand, { isLoading: brandLoading }] = useCreateBrandMutation();
  const [addRegion, { isLoading: regionLoading }] = useCreateRegionMutation();
  const [updateColor, { isLoading: colorLoadingUpadate }] = useUpdateColorMutation();
  const [updateBrand, { isLoading: brandLoadingUpadate }] = useUpdateBrandMutation();
  const [updateRegion, { isLoading: regionLoadingUpadate }] = useUpdateRegionMutation();

  const initialValues: TCreateColorBody = {
    name_ru: getInitialValue(modalType, data?.name_ru),
    name_uz: getInitialValue(modalType, data?.name_uz),
  };

  const onFinish = async (values: TCreateColorBody) => {
    let res = null;
    const body = {
      ...values,
    };

    if (modalType?.component === 'brand') {
      body.name_uz = body.name_ru;
    }
    //POST
    if (modalType?.manipulation === 'add') {
      if (modalType.component === 'color') {
        res = await addColor({ body, token });
      } else if (modalType.component === 'brand') {
        res = await addBrand({ body, token });
      } else if (modalType.component === 'region') {
        res = await addRegion({ body, token });
      }
    }
    //UPDATE
    else {
      if (modalType?.component === 'color' && id) {
        res = await updateColor({ body, token, id: String(id) });
      } else if (modalType?.component === 'brand' && id) {
        res = await updateBrand({ body, token, id: String(id) });
      } else if (modalType?.component === 'region' && id) {
        res = await updateRegion({ body, token, id: String(id) });
      }
    }

    if (res?.data?.status_code === 201 || res?.data?.status_code === 200) {
      message.success(t('Common.Success'));
      dispatch(closeModal());
    } else {
      message.error(getErrorMessage(res?.error));
    }
  };

  const modalTitleHandler = () => {
    if (modalType?.component === 'color') {
      return 'Settings.Color';
    } else if (modalType?.component === 'brand') {
      return 'Settings.Brand';
    } else {
      return 'Settings.Region';
    }
  };

  return (
    <ModalWrapper
      formProps={{ onFinish, initialValues }}
      btnProps={{
        htmlType: 'submit',
        loading:
          colorLoading ||
          colorLoadingUpadate ||
          brandLoading ||
          brandLoadingUpadate ||
          regionLoadingUpadate ||
          regionLoading,
      }}
      modalTitle={t(modalTitleHandler()!)}
      btnContent={btnContent}
      styleType={styleType}
      {...modalProps}
    >
      <SettingsForm />
    </ModalWrapper>
  );
};

export default SettingsModal;
