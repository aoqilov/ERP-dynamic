import MyInput from '@/components/ui/my-input/MyInput';
import { useAppSelector } from '@/store/reduxHooks';
import { Flex } from 'antd';
import { useTranslation } from 'react-i18next';

const SettingsForm = () => {
  const { t } = useTranslation();
  const { modalType } = useAppSelector((state) => state.modal);

  const handleTranslation = () => {
    if (modalType?.component === 'color') {
      return 'Color';
    } else if (modalType?.component === 'brand') {
      return 'Brand';
    } else {
      return 'Region';
    }
  };

  return (
    <Flex vertical gap={16}>
      <MyInput
        style={{ width: '100%' }}
        formItemProps={{ name: 'name_ru', label: t(`Settings.${handleTranslation()}Ru`) }}
        id="nameRu"
        title={t(`Settings.${handleTranslation()}${modalType?.component !== 'brand' ? 'Ru' : ''}`)}
        size="large"
        placeholder={t(
          `Settings.${handleTranslation()}${modalType?.component !== 'brand' ? 'Ru' : ''}`,
        )}
      />
      {modalType?.component !== 'brand' && (
        <MyInput
          style={{ width: '100%' }}
          formItemProps={{ name: 'name_uz', label: t(`Settings.${handleTranslation()}Uz`) }}
          id="nameUz"
          title={t(`Settings.${handleTranslation()}Uz`)}
          size="large"
          placeholder={t(`Settings.${handleTranslation()}Uz`)}
        />
      )}
    </Flex>
  );
};

export default SettingsForm;
