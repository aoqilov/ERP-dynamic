import { IPen, IPlus, ISearch, ITrash } from '@/components/svgs/svgs';
import MyButton from '@/components/ui/buttons/my-button/MyButton';
import MyInput from '@/components/ui/my-input/MyInput';
import MyTableBox from '@/components/ui/tables';
import { Locale } from '@/i18n';
import { langConverterActions } from '@/lib/utils/langHandlers';
import { alphabeticalSort } from '@/lib/utils/sorters/alphabeticalSort';
import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
import { ComponentsNameType, openModal } from '@/store/slices/modal.slice';
import { Space } from 'antd';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'react-router-dom';
import MyContent from '../layout/MyContent';
import SettingsModal from './settings-modal/SettingsModal';
import type { TableColumnsType } from 'antd';
import { useGetAllColorQuery } from '@/store/services/color/color.api';
import { TColorItem, TColorList } from '@/store/services/color/color.type';
import { useGetAllBrandQuery } from '@/store/services/brand/brand.api';
import { useGetAllRegionQuery } from '@/store/services/region/region.api';

type DataType = {
  key: React.Key;
  name?: string;
  name_ru?: string;
  name_uz?: string;
};

type SettingType = 'color' | 'brand' | 'region';

const SettignsIndex = () => {
  const { modalIsOpen, modalType } = useAppSelector((state) => state.modal);
  const [dataSource, setDataSource] = useState<TColorList>([]);
  const location = useLocation();

  const { data: colorData, isLoading: colorLoading } = useGetAllColorQuery();
  const { data: brandData, isLoading: brandLoading } = useGetAllBrandQuery();
  const { data: regionData, isLoading: regionLoading } = useGetAllRegionQuery();

  const currentPath = (): SettingType => {
    if (location.pathname === '/settings/color') {
      return 'color';
    } else if (location.pathname === '/settings/brand') {
      return 'brand';
    } else if (location.pathname === '/settings/region') {
      return 'region';
    }
    return 'color';
  };

  useEffect(() => {
    if (currentPath() === 'color' && colorData?.data) {
      setDataSource(colorData?.data);
    } else if (currentPath() === 'brand' && brandData?.data) {
      setDataSource(brandData?.data);
    } else if (currentPath() === 'region' && regionData?.data) {
      setDataSource(regionData?.data);
    }
  }, [location.pathname, brandData, colorData, regionData]);

  const {
    t,
    i18n: { language },
  } = useTranslation();
  const dispatch = useAppDispatch();

  const handleTranslation = (path: string, type: 'component' | 'title' | 'subTitle' | 'add') => {
    let obj = null;

    if (type === 'component') {
      obj = {
        color: 'color',
        brand: 'brand',
        region: 'region',
      };
    } else if (type === 'title') {
      obj = {
        color: 'Settings.Color',
        brand: 'Settings.Brand',
        region: 'Settings.Region',
      };
    } else if (type === 'subTitle') {
      obj = {
        color: 'Settings.ColorsList',
        brand: 'Settings.BrandsList',
        region: 'Settings.RegionsList',
      };
    } else if (type === 'add') {
      obj = {
        color: 'Settings.AddColor',
        brand: 'Settings.AddBrand',
        region: 'Settings.AddRegion',
      };
    }

    return obj?.[path];
  };

  const columnData = t(
    currentPath() === 'color'
      ? 'Settings.TableColumnsColor'
      : currentPath() === 'brand'
      ? 'Settings.TableColumnsBrand'
      : 'Settings.TableColumnsRegion',
    {
      returnObjects: true,
    },
  ) as Array<{
    title: string;
  }>;

  let columns: TableColumnsType<TColorItem> = [
    {
      dataIndex: 'name_ru',
      key: 'name_ru',
      width: 450,
      sorter: (a: DataType, b: DataType) => alphabeticalSort(a.name_ru!, b.name_ru!),
    },
    {
      dataIndex: 'name_uz',
      key: 'name_uz',
      width: 450,
      sorter: (a: DataType, b: DataType) => alphabeticalSort(a.name_uz!, b.name_uz!),
    },
    {
      dataIndex: 'actions',
      key: 'actions',
      render: (_text, record) => (
        <Space size="middle">
          <MyButton
            onClick={() =>
              dispatch(
                openModal({
                  modalType: {
                    component: handleTranslation(currentPath()!, 'component') as ComponentsNameType,
                    style: 'form',
                    manipulation: 'edit',
                  },
                  data: dataSource.find((item) => item.id === record.id),
                  id: String(record.id),
                }),
              )
            }
            style={{ background: 'var(--color-blue)', width: 32, height: 32 }}
            icon={<IPen />}
          />
          <MyButton
            onClick={() => {
              dispatch(
                openModal({
                  id: String(record.id),
                  modalType: {
                    component: currentPath(),
                    style: 'delete',
                  },
                }),
              );
            }}
            style={{ background: 'var(--color-red)', width: 32, height: 32 }}
            icon={<ITrash />}
          />
        </Space>
      ),
      width: 165,
      align: 'end',
    },
  ];

  columns = columns.map((item, index) => {
    const translation = columnData[index];

    if (index === columns.length - 1) {
      return {
        ...item,
        title: langConverterActions(language as Locale),
      };
    }

    return {
      ...item,
      title: translation?.title,
    };
  });

  if (currentPath() === 'brand') {
    columns.splice(1, 1);
  }

  // const dataSource = [
  //   {
  //     id: 4587,
  //     key: '1',
  //     name: 'name',
  //   },
  //   {
  //     id: 4587,
  //     key: '2',
  //     name: 'name',
  //   },
  //   {
  //     id: 4587,
  //     key: '3',
  //     name: 'name',
  //   },
  // ];

  const topHeader = (
    <MyButton
      onClick={() =>
        dispatch(
          openModal({
            modalType: {
              component: handleTranslation(currentPath()!, 'component') as ComponentsNameType,
              style: 'form',
              manipulation: 'add',
            },
          }),
        )
      }
      styleType="orange"
      icon={<IPlus />}
    >
      {t(handleTranslation(currentPath()!, 'add')!)}
    </MyButton>
  );

  const header = (
    <div style={{ marginBottom: 24 }}>
      <MyInput size="large" placeholder={t('Common.SearchByName')} suffix={<ISearch />} />
    </div>
  );

  return (
    <MyContent>
      <MyTableBox
        tableProps={{ loading: colorLoading || brandLoading || regionLoading }}
        columns={columns}
        dataSource={dataSource}
        tableTitles={{
          title: t(handleTranslation(currentPath()!, 'title')!),
          subTitle: t(handleTranslation(currentPath()!, 'subTitle')!),
        }}
        topHeader={topHeader}
        header={header}
      />
      {modalType?.style === 'form' && modalIsOpen && (
        <SettingsModal btnContent={t('Common.Save')} styleType="singleBtn" />
      )}
    </MyContent>
  );
};

export default SettignsIndex;
