import { IDashboardOne } from '@/components/svgs/svgs';
import { FC } from 'react';
import { DashboardItem } from '../DashboardItem';
import './home.css';

export const Home: FC = () => {
  const data = [
    {
      icon: <IDashboardOne />,
      total: 125000000,
      desc: 'Общая исходная цена',
    },
  ];

  return (
    <ul className="home-list">
      {data.map((item) => (
        <DashboardItem item={item} />
      ))}
    </ul>
  );
};
