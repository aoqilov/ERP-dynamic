import { IDashboardOne } from '@/components/svgs/svgs';
import { formatCurrency } from '@/lib/utils/formatters/currencyFormatter';
import './dashboard-item.css';
import { ReactElement } from 'react';

type DashboardItemType = {
  icon: ReactElement;
  total: number;
  desc: string;
};

type DashboardItemProps = {
  item: DashboardItemType;
};

export const DashboardItem = ({ item }: DashboardItemProps) => {
  return (
    <li key={item.total} className="dashboard-item">
      <IDashboardOne className="dashbord-item__icon" />
      <p className="dashboard-item__total">{formatCurrency(item.total, { currency: 'UZS' })}</p>
      <p className="dashboard-item__desc">Выручка</p>
    </li>
  );
};
