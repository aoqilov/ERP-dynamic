import { ROUTES } from '@/constants';
import { useAppSelector } from '@/store/reduxHooks';
import { Button, Result } from 'antd';
import { Content } from 'antd/es/layout/layout';
import { useEffect } from 'react';
import { FC } from 'react';
import { useTranslation } from 'react-i18next';
import { Link, useNavigate } from 'react-router-dom';

const NotFound: FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const auth = useAppSelector((state) => state.auth);

  useEffect(() => {
    if (!auth?.token) {
      navigate(ROUTES.login);
    }
  }, []);

  return (
    <Content className="flex-center h-inherit">
      <Result
        status="404"
        title="404"
        subTitle={t('Common.NotFound')}
        extra={
          <Link to={ROUTES.home}>
            <Button type="primary">{t('Common.BackHome')}</Button>
          </Link>
        }
      />
    </Content>
  );
};

export default NotFound;
