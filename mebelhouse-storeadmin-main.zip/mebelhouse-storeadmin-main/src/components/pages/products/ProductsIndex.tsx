import MyTableBox from '@/components/ui/tables';
import { Locale } from '@/i18n';
import useQueryParams from '@/lib/hooks/useQueryParams';
import { addKey } from '@/lib/utils/addKey';
import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
// import { TProductListsList } from '@/store/services/product-lists/product-lists.type';
import { useGetAllProductsQuery } from '@/store/services/products/products.api';
// import { TProductsList } from '@/store/services/products/products.type';
import { setSelectedItems } from '@/store/slices/selected-items.slice';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import MyContent from '../layout/MyContent';
import { ProductColumns } from './product-columns/ProductColumns';
import ProductsHeader from './products-headers/ProductsHeader';
// import ProductsTopHeader from './products-headers/ProductsTopHeader';
import { TProductListsItem } from '@/store/services/product-lists/product-lists.type';
import { TableRowSelection } from 'antd/es/table/interface';
import BarCodePrint from './barcode-print/BarCodePrint';
import ProductSetColumns from './product-columns/ProductSetColumns';
import ProductModals from './products-modal';

export type TabsType = 'productLists' | 'set' | 'excel' | 'manual' | 'products';

const ProductsIndex = () => {
  const [tab, setTab] = useState<TabsType>('products');
  const {
    modal: { modalIsOpen, modalType },
    selectedItems: { selectedItems },
  } = useAppSelector((state) => state);
  const [dataSource, setDataSource] = useState<any>([]);
  const { token } = useAppSelector((state) => state.auth);
  const { getParam, setParams } = useQueryParams();
  const {
    barCodePrint: { printIsOpen },
  } = useAppSelector((state) => state.products);

  const { data: productsData, isLoading: productsLoading } = useGetAllProductsQuery({
    token,
    page_size: +(getParam('page_size') || 10),
    page: +(getParam('current_page') || 1),
    search: getParam('search') || '',
    category_id: getParam('category') || '',
    sub_category_id: getParam('subcategory') || '',
    // colors: true,
  });

  const { collapseItems, productsSetData, setCheckboxAll } = ProductSetColumns({ tab });

  const getNeededApi = (key: string) => {
    if (tab === 'products' && productsData) {
      return productsData[key as keyof typeof productsData];
    } else if (tab === 'set' && productsSetData) {
      return productsSetData[key as keyof typeof productsSetData];
    }
  };

  useEffect(() => {
    setParams({
      total_elements: String(getNeededApi('total_elements') || 10),
      from: String(getNeededApi('from') || 1),
      to: String(getNeededApi('to') || 10),
      current_page: String(getNeededApi('current_page') || 1),
    });
  }, [tab, productsData?.data, productsSetData?.data]);

  useEffect(() => {
    if (tab === 'products' && productsData) {
      setDataSource(addKey(productsData?.data));
    } else if (tab === 'set' && productsSetData) {
      setDataSource(addKey(productsSetData?.data));
    } else {
      setDataSource([]);
    }
  }, [tab, productsData?.data, productsSetData?.data]);

  const {
    t,
    i18n: { language },
  } = useTranslation();
  const dispatch = useAppDispatch();

  const columnData = t('Products.TableColumns', {
    returnObjects: true,
  }) as Array<{ title: string }>;

  const productColumns = ProductColumns(language as Locale, columnData);
  // const productListColumns = ProductListColumns(
  //   dispatch,
  //   language as Locale,
  //   columnData,
  //   productListsData?.data,
  // );T

  const onTabChange = (tab: string) => {
    setTab(tab as TabsType);
  };

  useEffect(() => {
    dispatch(setSelectedItems({ selectedItems: null }));
  }, [tab]);

  const onSelectChange = (newSelectedRowKeys: React.Key[]) => {
    // setSelectedRowKeys(newSelectedRowKeys);
    dispatch(setSelectedItems({ selectedItems: newSelectedRowKeys }));
  };

  const rowSelection: TableRowSelection<TProductListsItem> = {
    selectedRowKeys: selectedItems || [],
    onChange: onSelectChange,
  };

  return (
    <MyContent>
      <MyTableBox
        collapseItems={collapseItems}
        paginationProps={{ total: 10, current: 5 }}
        isCollapse={tab === 'set'}
        tableProps={{
          scroll: { x: 'max-content' },
          loading: productsLoading,
          rowSelection: rowSelection as any,
        }}
        columns={productColumns}
        dataSource={dataSource as any}
        tableTitles={{
          title: t('Products.Warehouse'),
          subTitle: t('Products.ListOfProducts'),
        }}
        // topHeader={<ProductsTopHeader tab={tab} />}
        header={
          <ProductsHeader
            components={{ setCheckboxAll }}
            tab={tab}
            onTabChange={onTabChange}
            selectedRowKeys={selectedItems || []}
          />
        }
      />
      {(modalType?.style === 'form' || modalType?.style === 'view') && modalIsOpen && (
        <ProductModals styleType="singleBtn" />
      )}
      {printIsOpen && (
        <BarCodePrint
          tab={tab}
          productsData={productsData?.data!}
          productSetData={productsSetData?.data!}
        />
      )}
    </MyContent>
  );
};

export default ProductsIndex;
