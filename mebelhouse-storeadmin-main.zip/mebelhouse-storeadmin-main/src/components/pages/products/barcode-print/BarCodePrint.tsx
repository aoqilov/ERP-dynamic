import { formatNumberWithSpaces } from '@/lib/utils/formatters/formatNumberWithSpaces';
import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
import { TProductListsItem } from '@/store/services/product-lists/product-lists.type';
import { setBarCodePrint } from '@/store/slices/products.slice';
import { FC, useEffect, useRef } from 'react';
import { ReactBarcode } from 'react-jsbarcode';
import { useReactToPrint } from 'react-to-print';
import './bar-code-print.css';
import { TProductsSetItem } from '@/store/services/products-set/products-set.type';
import { TabsType } from '../ProductsIndex';

type Props = {
  productSetData: TProductsSetItem[];
  productsData: TProductListsItem[];
  tab?: TabsType;
};

const BarCodePrint: FC<Props> = ({ productsData, productSetData, tab }) => {
  // const [isPrinting, setIsPrinting] = useState(false);
  // const {
  //   barCodePrint: { printIsOpen, printValue },
  // } = useAppSelector((state) => state.products);
  const { selectedItems } = useAppSelector((state) => state.selectedItems);
  const dispatch = useAppDispatch();

  const contentRef = useRef<HTMLDivElement>(null);

  const reactToPrintFn = useReactToPrint({
    contentRef,
    onAfterPrint: () => {
      // Reset the Promise resolve so we can print again
      // promiseResolveRef.current = null;
      // setIsPrinting(false);
      dispatch(setBarCodePrint({ printIsOpen: false }));
    },
  });

  const filteredData = (tab === 'products' ? productsData : productSetData)?.filter((item) =>
    selectedItems?.includes(item.id),
  );

  // const promiseResolveRef: any = useRef(null);

  // Set up the react-to-print hook
  // const handlePrint = useReactToPrint({
  //   content: () => contentRef.current, // The DOM element we want to print
  //   onBeforeGetContent: () => {
  //     // Optionally handle actions before printing (e.g., set state, resolve promises)
  //     setIsPrinting(true);
  //     return Promise.resolve(); // Return a resolved promise to ensure it's ready for printing
  //   },
  //   onAfterPrint: () => {
  //     // Optionally handle actions after printing (e.g., reset state)
  //     setIsPrinting(false);
  //   },
  // });

  // useEffect(() => {
  //   if (isPrinting && promiseResolveRef.current) {
  //     // Resolves the Promise, letting `react-to-print` know that the DOM updates are completed
  //     promiseResolveRef.current();
  //   }
  // }, [isPrinting]);

  useEffect(() => {
    reactToPrintFn();
  }, []);

  const barCodeItem = (item: TProductListsItem | TProductsSetItem) => (
    <>
      <h2 style={{ width: 200 }} className="barcode-title">
        {/* @ts-ignore */}
        {tab === 'products' ? item.name_ru : `СЭТ ${item.name}`}
      </h2>
      <ReactBarcode
        value={item.bar_code!}
        options={{ format: 'CODE128', height: 33, width: 1.5, fontSize: 14 }}
      />
      <p>{formatNumberWithSpaces(item.sale_price)}&nbsp;UZS</p>
    </>
  );

  return (
    <div style={{ display: 'none' }}>
      <div ref={contentRef} className="barcode-content">
        {filteredData?.map((item) => barCodeItem(item))}
      </div>
    </div>
  );
};

export default BarCodePrint;
