// columns.ts
import { IPen, ITrash } from '@/components/svgs/svgs';
import MyButton from '@/components/ui/buttons/my-button/MyButton';
import TableImage from '@/components/ui/tables/table-image/TableImage';
import { Locale } from '@/i18n';
import { CDN_URL } from '@/lib/consts/url.consts';
import { langConverterActions } from '@/lib/utils/langHandlers';
import { alphabeticalSort } from '@/lib/utils/sorters/alphabeticalSort';
import { useAppDispatch } from '@/store/reduxHooks';
import {
  TProductListsItem,
  TProductListsList,
} from '@/store/services/product-lists/product-lists.type';
import { openModal } from '@/store/slices/modal.slice';
import { Flex, Space, TableColumnsType } from 'antd';

export const ProductListColumns = (
  dispatch: ReturnType<typeof useAppDispatch>,
  language: Locale,
  columnData: Array<{ title: string }>,
  data: TProductListsList = [],
): TableColumnsType<TProductListsItem> => {
  // const { t } = useTranslation();

  let columns: TableColumnsType<TProductListsItem> = [
    {
      dataIndex: 'name_ru',
      key: 'name_ru',
      width: 300,
      sorter: (a: TProductListsItem, b: TProductListsItem) =>
        alphabeticalSort(a?.name_ru || '', b?.name_ru || ''),
      render: (_text, record) => {
        const name_ru = record?.name_ru || 'No name available';
        const hasImages = record?.images?.length > 0;

        return (
          <Flex align="center" gap={10}>
            <TableImage
              images={record.images}
              imgProps={{
                src: hasImages ? `${CDN_URL}/images/${record.images?.[0].path}` : '',
                preview: Boolean(hasImages),
                alt: name_ru,
              }}
            />
            <span>{name_ru}</span>
          </Flex>
        );
      },
    },
    {
      dataIndex: 'brand',
      key: 'brand',
      width: 150,
      sorter: (a: TProductListsItem, b: TProductListsItem) =>
        alphabeticalSort(a?.brand?.name || '', b?.brand?.name || ''),
      render: (_, record) => record?.brand?.name || 'No brand available',
    },
    {
      dataIndex: 'category',
      key: 'category',
      width: 150,
      sorter: (a: TProductListsItem, b: TProductListsItem) =>
        alphabeticalSort(a?.category?.name_ru || '', b?.category?.name_ru || ''),
      render: (_, record) => record?.sub_category.category?.name_ru,
    },
    {
      dataIndex: 'sub_category',
      key: 'sub_category',
      width: 150,
      sorter: (a: TProductListsItem, b: TProductListsItem) =>
        alphabeticalSort(a?.sub_category?.name_ru || '', b?.sub_category?.name_ru || ''),
      render: (_, record) => record?.sub_category?.[`name_${'ru'}`] || 'No subcategory available',
    },
    {
      dataIndex: 'country',
      key: 'country',
      width: 150,
      render: (_, record) => record?.country?.name_ru || 'No country available',
    },
    {
      dataIndex: 'bar_code',
      key: 'bar_code',
      width: 250,
    },
    {
      dataIndex: 'product_code',
      key: 'product_code',
      width: 250,
    },
    {
      dataIndex: 'actions',
      key: 'actions',
      fixed: 'right',
      render: (_text, record) => (
        <Space size="middle">
          <MyButton
            onClick={() =>
              dispatch(
                openModal({
                  modalType: {
                    component: 'productLists',
                    style: 'form',
                    manipulation: 'edit',
                  },
                  data: data?.find((item) => item.id === record.id),
                  id: record.id,
                }),
              )
            }
            style={{ background: 'var(--color-blue)', width: 32, height: 32 }}
            icon={<IPen />}
          />
          <MyButton
            onClick={() => {
              dispatch(
                openModal({
                  id: record.id,
                  modalType: {
                    component: 'productLists',
                    style: 'delete',
                  },
                }),
              );
            }}
            style={{ background: 'var(--color-red)', width: 32, height: 32 }}
            icon={<ITrash />}
          />
        </Space>
      ),
      align: 'end',
    },
  ];

  columns = columns.map((item, index) => {
    const translation = columnData[index];
    return {
      ...item,
      title: translation?.title ?? langConverterActions(language),
    };
  });

  return columns;
};
