import MyPopup from '@/components/ui/my-pop-up/MyPopup';
import MyTable from '@/components/ui/tables/MyTable/MyTable';
import { Locale } from '@/i18n';
import { formatNumberWithSpaces } from '@/lib/utils/formatters/formatNumberWithSpaces';
import { langConverterActions } from '@/lib/utils/langHandlers';
import { alphabeticalSort } from '@/lib/utils/sorters/alphabeticalSort';
import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
import { useGetAllProductsSetQuery } from '@/store/services/products-set/products-set.api';
import { TProductsSetInnerItem } from '@/store/services/products-set/products-set.type';
import { setSelectedItems } from '@/store/slices/selected-items.slice';
import { Checkbox, Col, CollapseProps, Row, Space, TableColumnsType, Typography } from 'antd';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { TabsType } from '../ProductsIndex';
import useQueryParams from '@/lib/hooks/useQueryParams';

const ProductSetColumns = ({ tab }: { tab: TabsType }) => {
  const { token } = useAppSelector((state) => state.auth);
  const { getParam } = useQueryParams();
  const { data: productsSetData, isLoading: productsSetLoading } = useGetAllProductsSetQuery({
    token,
    page_size: +(getParam('page_size') || 10),
    page: +(getParam('current_page') || 1),
    search: getParam('search') || '',
  });

  const dispatch = useAppDispatch();

  const {
    t,
    i18n: { language },
  } = useTranslation();

  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isAllChecked, setIsAllChecked] = useState(false);

  const handleCheckboxChange = (id: string, checked: boolean) => {
    setSelectedIds((prev) =>
      checked ? [...prev, id] : prev.filter((selectedId) => selectedId !== id),
    );
  };

  const handleCheckAllChange = (checked: boolean) => {
    if (productsSetData?.data) {
      setSelectedIds(checked ? productsSetData.data.map((item) => item.id) : []);
    }
  };

  useEffect(() => {
    if (productsSetData?.data) {
      const allChecked =
        selectedIds.length === productsSetData.data.length &&
        productsSetData.data.every((item) => selectedIds.includes(item.id));
      setIsAllChecked(allChecked);
    }
    dispatch(setSelectedItems({ selectedItems: selectedIds }));
  }, [selectedIds, productsSetData]);

  useEffect(() => {
    setSelectedIds([]);
    setIsAllChecked(false);
  }, [tab]);

  let columns: TableColumnsType<TProductsSetInnerItem> = [
    {
      dataIndex: 'name_ru',
      key: 'name_ru',
      width: 300,
      sorter: (a, b) => alphabeticalSort(a?.product_name_ru, b?.product_name_ru),
      render: (_text, record) => {
        return record?.product_name_ru;
      },
    },
    // {
    //   dataIndex: 'category',
    //   key: 'category',
    //   width: 150,
    //   sorter: (a, b) =>
    //     alphabeticalSort(a?.subcategory?.category?.name_ru, b?.subcategory?.category?.name_ru),
    //   render: (_text, record) => record?.subcategory?.category?.name_ru,
    // },
    // {
    //   dataIndex: 'subcategory',
    //   key: 'subcategory',
    //   width: 150,
    //   sorter: (a, b) => alphabeticalSort(a?.subcategory?.name_ru, b?.subcategory?.name_ru),
    //   render: (_, record) => record?.subcategory?.name_ru,
    // },
    // {
    //   dataIndex: 'barcode',
    //   key: 'barcode',
    //   width: 250,
    //   render: (_, record) => record.,
    // },
    {
      dataIndex: 'quantity',
      key: 'quantity',
      width: 150,
      render: (_, record) => {
        return (
          <Space size={[10, 10]}>
            <MyPopup
              data={record?.quantities}
              keyLabel="color_name_ru"
              keyNumber="quantity"
              keyId="product_id"
            />
            {record?.quantities && record?.quantities?.length > 0
              ? record?.quantities.reduce((acc, item) => acc + +item?.quantity, 0)
              : t('Common.NotInStock')}
          </Space>
        );
      },
    },

    {
      dataIndex: 'cost_price',
      key: 'cost_price',
      width: 150,
      render: (_, record) => formatNumberWithSpaces(+record?.origin_price),
    },
    {
      dataIndex: 'sale_price',
      key: 'sale_price',
      width: 150,
      render: (_, record) => formatNumberWithSpaces(+record?.sale_price),
    },
  ];

  const columnData = t('ProductSet.TableColumns', {
    returnObjects: true,
  }) as Array<{ title: string }>;

  columns = columns?.map((item, index) => {
    const translation = columnData[index];
    return {
      ...item,
      title: translation?.title ?? langConverterActions(language as Locale),
    };
  });

  const collapseItems: CollapseProps['items'] = productsSetData?.data?.map(
    ({ id, items, name, sale_price, bar_code }) => ({
      key: id,
      headerClass: 'flex-x-center',
      label: (
        <Row>
          <Col span={1}>
            <Checkbox
              checked={selectedIds.includes(id)}
              onChange={(e) => handleCheckboxChange(id, e.target.checked)}
              onClick={(e) => e.stopPropagation()}
            />
          </Col>
          <Col span={6}>
            <p>СЭТ {name}</p>
          </Col>
          <Col span={13}>
            <span>
              {t('Products.BarCode')}:&nbsp;
              <Typography.Text copyable>{bar_code}</Typography.Text>
            </span>
          </Col>
          <Col style={{ textAlign: 'right' }} span={4}>
            <span style={{ fontWeight: 700 }}>{formatNumberWithSpaces(sale_price)} UZS</span>
          </Col>
        </Row>
      ),
      children: (
        <MyTable
          tableProps={{
            loading: productsSetLoading,
            size: 'middle',
            scroll: { x: 'max-content' },
            rowKey: 'id',
          }}
          columns={columns}
          dataSource={items?.filter((item) => item?.id)}
        />
      ),
    }),
  );

  return {
    setCheckboxAll: (
      <div>
        <Space style={{ marginBottom: 16 }}>
          <Checkbox
            checked={isAllChecked}
            indeterminate={
              selectedIds.length > 0 && selectedIds.length < (productsSetData?.data?.length || 0)
            }
            onChange={(e) => handleCheckAllChange(e.target.checked)}
          >
            {t('Common.SelectAll')}
          </Checkbox>
        </Space>
      </div>
    ),
    collapseItems,
    productsSetData,
  };
};

export default ProductSetColumns;
