import MyPopup from '@/components/ui/my-pop-up/MyPopup';
import TableImage from '@/components/ui/tables/table-image/TableImage';
import { Locale } from '@/i18n';
import { CDN_URL } from '@/lib/consts/url.consts';
import { makeSpaces } from '@/lib/utils/formatters/makeSpaces';
import { langConverterActions } from '@/lib/utils/langHandlers';
import { alphabeticalSort } from '@/lib/utils/sorters/alphabeticalSort';

import { TProductsItem } from '@/store/services/products/products.type';
import { Flex, Space, TableColumnsType } from 'antd';
import { useTranslation } from 'react-i18next';

export const ProductColumns = (
  language: Locale,
  columnData: Array<{ title: string }>,
): TableColumnsType<TProductsItem> => {
  const { t } = useTranslation();

  let columns: TableColumnsType<TProductsItem> = [
    {
      dataIndex: 'name_ru',
      key: 'name_ru',
      width: 300,
      sorter: (a: TProductsItem, b: TProductsItem) => alphabeticalSort(a?.name_ru, b?.name_ru),
      render: (_text, record) => {
        const hasPictures = record?.images && record?.images?.length > 0;
        return (
          <Flex align="center" gap={10}>
            <TableImage
              imgProps={{
                src: `${CDN_URL}/images/${record?.images?.[0]?.path}`,
                preview: Boolean(hasPictures),
                alt: record?.name_ru,
              }}
            />
            <span>{record?.name_ru}</span>
          </Flex>
        );
      },
    },
    {
      dataIndex: 'brand',
      key: 'brand',
      width: 150,
      sorter: (a: TProductsItem, b: TProductsItem) =>
        alphabeticalSort(a?.brand.name, b?.brand.name),
      render: (_, record) => record?.brand?.name,
    },
    {
      dataIndex: 'category',
      key: 'category',
      width: 150,
      sorter: (a: TProductsItem, b: TProductsItem) =>
        alphabeticalSort(a?.sub_category?.category?.name_ru, b?.sub_category?.category?.name_ru),
      render: (_text, record) => record?.sub_category?.category?.name_ru,
    },
    {
      dataIndex: 'subcategory',
      key: 'subcategory',
      width: 150,
      sorter: (a: TProductsItem, b: TProductsItem) =>
        alphabeticalSort(a?.sub_category.name_ru, b?.sub_category?.name_ru),
      render: (_, record) => record?.sub_category?.[`name_${'ru'}`],
    },
    {
      dataIndex: 'country',
      key: 'country',
      width: 150,
      render: (_, record) => record?.country?.name_ru,
    },
    {
      dataIndex: 'bar_code',
      key: 'bar_code',
      width: 250,
      render: (_, record) => record?.bar_code,
    },
    {
      dataIndex: 'quantity',
      key: 'quantity',
      width: 150,
      render: (_, record) => (
        <Space size={[10, 10]}>
          <MyPopup
            data={record?.quantities as any}
            keyLabel="color_name_ru"
            keyNumber="quantity"
            keyId="id"
          />
          {record?.quantities && record.quantities.length > 0
            ? record.quantities.reduce((acc, quantity) => acc + Number(quantity.quantity), 0)
            : t('Common.NotInStock')}
        </Space>
      ),
    },
    {
      dataIndex: 'origin_price',
      key: 'origin_price',
      width: 150,
      render: (_, record) => makeSpaces(+record?.origin_price),
    },
    {
      dataIndex: 'sale_price',
      key: 'sale_price',
      width: 150,
      render: (_, record) => makeSpaces(+record?.sale_price),
    },
  ];

  columns = columns.map((item, index) => {
    const translation = columnData[index];
    return {
      ...item,
      title: translation?.title ?? langConverterActions(language),
    };
  });

  return columns;
};
