import { ITrash } from '@/components/svgs/svgs';
import CountButton from '@/components/ui/buttons/count-button/CountButton';
import MyButton from '@/components/ui/buttons/my-button/MyButton';
import MySelect from '@/components/ui/my-select/MySelect';
import MyTableBox from '@/components/ui/tables';
import TableImage from '@/components/ui/tables/table-image/TableImage';
import { SERVER_URL } from '@/lib/consts/url.consts';
import { convertDataForSelect } from '@/lib/utils/convertDataForSelect';
import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
import { useGetAllProductsQuery } from '@/store/services/products/products.api';
import { TProductIncomeItemList } from '@/store/services/products/products.type';
import { setSelectedProductsList } from '@/store/slices/products.slice';
import { Col, Flex, Row, TableColumnsType } from 'antd';
import { DefaultOptionType } from 'antd/es/select';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

type TProductTransferType = {
  key: string;
  productId: string; // New field for tracking product ID
  name_ru: string;
  color: string; // Each row represents a color
  picture: string;
  balance: number; // Display balance specific to the color
  quantity: number; // Quantity for CountButton specific to the color
};

const ProductsTransferListForm = () => {
  const { token } = useAppSelector((state) => state.auth);
  const { data, isLoading } = useGetAllProductsQuery({ token, colors: true });
  const { t } = useTranslation();
  const [options, setOptions] = useState<DefaultOptionType[]>([]);
  const [value, setValue] = useState<string>();
  const [filteredData, setFilteredData] = useState<DefaultOptionType[]>([]);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [dataSource, setDatasource] = useState<any[]>([]);
  const dispatch = useAppDispatch();

  useEffect(() => {
    if (data) {
      const convertedOptions = convertDataForSelect({
        label: 'name_ru',
        data: data?.data,
      });
      setOptions(convertedOptions);
      setFilteredData(convertedOptions);
    }
  }, [data]);

  // Updated map function to handle color-specific rows
  const mapDataSourceToProductIncome = (
    dataSource: TProductTransferType[],
  ): TProductIncomeItemList => {
    return dataSource.map((item) => ({
      product_list: parseInt(item.productId), // Using productId
      cost_price: '0', // Placeholder, adjust as needed
      sale_price: '0', // Placeholder, adjust as needed
      quantity: item.quantity, // Color-specific quantity
    }));
  };

  const handleChange = (newValue: string | null) => {
    if (!newValue) {
      setValue('');
      setDropdownOpen(false);
      return;
    }

    setValue('');
    setDropdownOpen(false);

    const selectedProduct = data?.data.find((product) => Number(product.id) === +newValue);
    if (selectedProduct) {
      const productRows = selectedProduct.colours.map((color) => ({
        key: `${selectedProduct.id}-${color.id}`,
        productId: selectedProduct.id.toString(),
        name_ru: selectedProduct.name_ru,
        color: color.name_ru,
        picture: selectedProduct.images[0]?.path || '',
        balance: color.code,
        quantity: 0,
      }));

      const updatedDataSource = [...dataSource, ...productRows];
      setDatasource(updatedDataSource);

      // Update options to exclude already selected items
      const newOptions = options.filter((option) => option.value !== newValue);
      setOptions(newOptions);
      setFilteredData(newOptions); // Update the filtered data for consistent display
    }
  };

  const handleSearch = (newValue: string) => {
    if (newValue) {
      const filtered = options.filter(
        (option) =>
          typeof option.label === 'string' &&
          option.label.toLowerCase().includes(newValue.toLowerCase()) &&
          !dataSource.some((item) => item.productId === option.value), // Exclude already selected items
      );
      setFilteredData(filtered);
      setDropdownOpen(true);
    } else {
      setFilteredData(options);
      setDropdownOpen(false);
    }
  };

  const handleQuantityChange = (key: string, quantity: number) => {
    const updatedDataSource = dataSource.map((item) =>
      item.key === key ? { ...item, quantity } : item,
    );
    setDatasource(updatedDataSource);

    const productIncomeList = mapDataSourceToProductIncome(updatedDataSource);
    dispatch(setSelectedProductsList(productIncomeList));
  };

  const handleRemove = (key: string) => {
    const updatedDataSource = dataSource.filter((item) => item.key !== key);
    setDatasource(updatedDataSource);

    const productStillExists = updatedDataSource.some(
      (item) => item.productId === dataSource.find((item) => item.key === key)?.productId,
    );

    const removedItem = dataSource.find((item) => item.key === key);

    if (removedItem && !productStillExists) {
      if (!options.some((option) => option.value === removedItem.productId)) {
        const newOptions = [
          ...options,
          { value: removedItem.productId, label: removedItem.name_ru },
        ];
        setOptions(newOptions);
        setFilteredData(newOptions);
      }
    }

    const productIncomeList = mapDataSourceToProductIncome(updatedDataSource);
    dispatch(setSelectedProductsList(productIncomeList));
  };

  const columns: TableColumnsType<TProductTransferType> = [
    {
      title: t('Products.Products'),
      dataIndex: 'name_ru',
      key: 'name_ru',
      width: 200,
      render: (text, record) => {
        // Calculate the row span for product name and image
        const sameProductRows = dataSource.filter((item) => item.productId === record.productId);
        const rowSpan =
          sameProductRows.findIndex((item) => item.key === record.key) === 0
            ? sameProductRows.length
            : 0;

        return {
          children: (
            <Flex
              align="center"
              vertical
              gap={10}
              style={{
                height: '100%',
                justifyContent: 'center',
                textAlign: 'center',
              }}
            >
              <TableImage
                imgProps={{
                  src: `${SERVER_URL}/${record.picture}`,
                  preview: Boolean(record.picture),
                  alt: record.name_ru,
                }}
              />
              <span>{text}</span>
            </Flex>
          ),
          props: {
            rowSpan, // Span rows for the same product
            style: { textAlign: 'center', verticalAlign: 'middle' }, // Center vertically and horizontally
          },
        };
      },
    },
    {
      title: t('Products.Color'),
      dataIndex: 'color',
      key: 'color',
      width: 120,
      render: (_, record) => <p>{record.color}</p>, // Отображение только названия цвета
    },
    {
      title: t('Products.Balance'),
      dataIndex: 'balance',
      key: 'balance',
      width: 100,
      render: (balance) => (
        <div
          style={{
            textAlign: 'center',
            height: '100%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {balance} {/* Render balance as text */}
        </div>
      ),
    },
    {
      title: t('Products.Quantity'),
      dataIndex: 'quantity',
      key: 'quantity',
      width: 120,
      render: (quantity, record) => (
        <div style={{ height: '100%', display: 'flex', alignItems: 'center' }}>
          <CountButton
            initialCount={quantity}
            onCountChange={(count) => handleQuantityChange(record.key, count)}
            limit={record.balance} // Assuming 'balance' is the limit for 'quantity'
          />
        </div>
      ),
    },
    {
      title: t('Common.Actions'),
      key: 'actions',
      width: '1%',
      align: 'center',
      render: (_, record) => (
        <MyButton
          onClick={() => handleRemove(record.key)}
          style={{ background: 'var(--color-red)', width: 32, height: 32 }}
          icon={<ITrash />}
        />
      ),
    },
  ];

  return (
    <Row gutter={[16, 16]}>
      <Col span={24}>
        <MySelect
          showSearch
          value={value}
          defaultActiveFirstOption={false}
          suffixIcon={null}
          filterOption={false}
          onChange={handleChange}
          onSearch={handleSearch}
          notFoundContent={isLoading ? t('Common.Loading') : null}
          formItemProps={{ label: t('Common.SearchByName') }}
          options={filteredData}
          allowClear
          id="ProductsSelect"
          placeholder={t('Products.SelectProducts')}
          open={dropdownOpen}
        />
      </Col>
      <Col span={24}>
        <MyTableBox tableProps={{ bordered: true }} columns={columns} dataSource={dataSource} />
      </Col>
    </Row>
  );
};

export default ProductsTransferListForm;
