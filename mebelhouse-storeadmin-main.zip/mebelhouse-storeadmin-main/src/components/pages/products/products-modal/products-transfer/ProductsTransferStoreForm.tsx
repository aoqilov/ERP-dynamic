import MySelect from '@/components/ui/my-select/MySelect';
import { convertDataForSelect } from '@/lib/utils/convertDataForSelect';
import { useAppSelector } from '@/store/reduxHooks';
import { useGetAllShowroomsQuery } from '@/store/services/showrooms/showrooms.api';
import { useTranslation } from 'react-i18next';

const ProductsTransferStoreForm = () => {
  const { t } = useTranslation();
  const {
    auth: { token },
  } = useAppSelector((state) => state);

  const getAllShowroomsResult = useGetAllShowroomsQuery({ token }, { skip: !token });

  return (
    <>
      <MySelect
        formItemProps={{ name: 'showroom', label: t('StoresPage.Store') }}
        size="large"
        defaultValue={getAllShowroomsResult?.data?.data[0]?.name}
        options={convertDataForSelect({
          label: 'name_ru',
          data: getAllShowroomsResult?.data?.data,
        })}
      />
    </>
  );
};

export default ProductsTransferStoreForm;
