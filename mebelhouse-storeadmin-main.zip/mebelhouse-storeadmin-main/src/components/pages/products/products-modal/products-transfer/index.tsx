import { useAppSelector } from '@/store/reduxHooks';
import ProductsTransferListForm from './ProductsTransferListForm';
import ProductsTransferStoreForm from './ProductsTransferStoreForm';

const ProductsTransfer = () => {
  const { transferStep } = useAppSelector((state) => state.products);

  console.log(transferStep);

  if (transferStep === 'list') {
    return <ProductsTransferListForm />;
  } else {
    return <ProductsTransferStoreForm />;
  }
};

export default ProductsTransfer;
