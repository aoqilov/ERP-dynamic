import ModalWrapper from '@/components/ui/modal-wrapper/ModalWrapper';
import { ModalStyleType } from '@/lib/types/common.type';
import { convertToIds } from '@/lib/utils/convertToIds';
import { getErrorMessage } from '@/lib/utils/getErrorMessage';
import { getInitialValue } from '@/lib/utils/getInitialValue';
import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
import {
  useCreateProductListsMutation,
  useUpdateProductListsMutation,
} from '@/store/services/product-lists/product-lists.api';
import { TCreateProductListsBody } from '@/store/services/product-lists/product-lists.type';
import { useCreateIncomeProductsMutation } from '@/store/services/products/products.api';
import { setFile } from '@/store/slices/file.slice';
import { ComponentsNameType, closeModal } from '@/store/slices/modal.slice';
import { setSelectedProductsList, setTransferStep } from '@/store/slices/products.slice';
import { ModalProps, message } from 'antd';
import { ReactElement, useState } from 'react';
import { useTranslation } from 'react-i18next';
import Excel from './Excel';
import ExcelUploadForm from './ExcelUploadForm';
import ProductsForm from './ProductsForm';
import ProductsWriteOffForm from './ProductsWriteOffForm';
import ProductsIncomeForm from './products-income/ProductsIncomeForm';
import ProductsTransfer from './products-transfer';

type ProductModalsProps = ModalProps & {
  styleType?: ModalStyleType;
};

const ProductModals = ({ styleType, ...modalProps }: ProductModalsProps) => {
  const { t } = useTranslation();
  const {
    modal: { modalType, id, data },
    file: { id: fileId },
    auth: { token },
    products: { selectedProductsList, transferStep },
  } = useAppSelector((state) => state);

  const [category, setCategory] = useState<null | number>(null);
  const dispatch = useAppDispatch();
  const [addProductList, { isLoading: productListAddLoading }] = useCreateProductListsMutation();

  const [addIncomeProducts, { isLoading: addIncomeProductsLoading }] =
    useCreateIncomeProductsMutation();

  const [updateProduct, { isLoading: productListsUpdatedLoading }] =
    useUpdateProductListsMutation();
  // const [transferProducts, { isLoading: transferProductLoading }] = useCreateTransferMutation();

  const initialValues = {
    name_ru: getInitialValue(modalType, data?.name_ru),
    name_uz: getInitialValue(modalType, data?.name_uz),
    description_uz: getInitialValue(modalType, data?.description_uz),
    description_ru: getInitialValue(modalType, data?.description_ru),
    barcode: getInitialValue(modalType, data?.barcode),
    colors: getInitialValue(modalType, convertToIds(data?.colors, 'id')),
    country: getInitialValue(modalType, data?.country?.id),
    brand: getInitialValue(modalType, data?.brand?.id),
    category: getInitialValue(modalType, data?.category?.id),
    subcategory: getInitialValue(modalType, data?.subcategory?.id),
  };

  const isTransferListStep = modalType?.component === 'productsTransfer' && transferStep === 'list';

  const onFinish = async (values: TCreateProductListsBody) => {
    if (isTransferListStep) {
      dispatch(setTransferStep('store'));
      return;
    }

    if (modalType?.component === 'productLists' && !fileId) {
      message.error(t('Common.UploadingRequired'));
      return;
    }

    let res = null;

    // const { ...restValues, color } = {
    //   ...values,
    // };

    const body = {
      ...values,
      pictures: [fileId!],
      category,
      // origin_price: 10000000,
      // origin_price: 1_000_000,
      // sale_price: 2_000_000,
    };

    //POST
    if (modalType?.manipulation === 'add') {
      if (modalType.component === 'productLists') {
        //@ts-ignore
        res = await addProductList({ body, token });
      } else if (modalType.component === 'productsIncome') {
        res = await addIncomeProducts({ body: { products: selectedProductsList } as any, token });
      } else if (modalType.component === 'productsTransfer' && transferStep === 'store') {
        // res = await transferProducts({ body: { products: selectedProductsIncome,  } });
      }
    }
    //PATCH
    else {
      if (modalType?.component === 'productLists') {
        //@ts-ignore
        res = await updateProduct({ body, token, id: id! });
      }
    }

    //Handling error
    if (res?.data?.status_code === 201 || res?.data?.status_code === 200) {
      message.success(t('Common.Success'));
      dispatch(setFile(null));
      dispatch(closeModal());
      onCloseTransferModal();
    } else {
      message.error(getErrorMessage(res));
    }
  };

  const titlesAdd: Partial<{ [key in ComponentsNameType]: string }> = {
    productLists: 'Products.AddProduct',
    excelUpload: 'Products.DownloadFromExcel',
    productsTransfer: 'Products.Sending',
    productsIncome: 'Products.Income',
  };

  const titlesEdit: Partial<{ [key in ComponentsNameType]: string }> = {
    productLists: 'Products.UpdateProduct',
    productsWriteOff: 'Products.WriteOff',
  };

  const modalTitleHandler = () => {
    if (modalType?.manipulation === 'add') {
      return titlesAdd[modalType.component!];
    } else if (modalType?.manipulation === 'edit') {
      return titlesEdit[modalType?.component!];
    } else if (modalType?.manipulation === 'add') {
      return titlesAdd[modalType?.component!];
    } else if (modalType?.manipulation === 'add') {
      return titlesAdd[modalType?.component!];
    } else {
      return 'Common.Info';
    }
  };

  const components: {
    width: Record<string, string>;
    modals: Partial<Record<ComponentsNameType, ReactElement>>;
  } = {
    modals: {
      productLists: <ProductsForm setCategory={setCategory} />,
      excel: <Excel />,
      excelUpload: <ExcelUploadForm />,
      productsWriteOff: <ProductsWriteOffForm />,
      productsTransfer: <ProductsTransfer />,
      productsIncome: <ProductsIncomeForm />,
    },
    width: {
      productLists: '65vw',
      excel: '65vw',
      excelUpload: '506px',
      productWriteOff: '506px',
      productsTransfer: '609px',
      productsIncome: '90vw',
    },
  };

  const handleClick = () => {
    if (modalType?.component === 'excel') {
      dispatch(closeModal());
    }
  };

  const getHtmlType = () => {
    if (modalType?.component === 'excel') {
      return 'button';
    } else {
      return 'submit';
    }
  };

  const getBtnContent = () => {
    if (modalType?.component === 'excel') {
      return t('Common.Close');
    } else if (isTransferListStep) {
      return t('Common.Next');
    } else {
      return t('Common.Save');
    }
  };

  const onCloseTransferModal = () => {
    if (modalType?.component === 'productsTransfer') {
      dispatch(setTransferStep('list'));
    }
    dispatch(setSelectedProductsList([]));
    dispatch(closeModal());
  };

  const isDisabled = () => {
    if (modalType?.component === 'productsIncome' || modalType?.component === 'productsTransfer') {
      return selectedProductsList.length === 0;
    } else {
      return false;
    }
  };

  return (
    <ModalWrapper
      onCancel={onCloseTransferModal}
      formProps={{
        onFinish: modalType?.component !== 'excel' ? onFinish : () => {},
        initialValues,
        onClick: handleClick,
      }}
      btnProps={{
        htmlType: getHtmlType(),
        loading: productListAddLoading || productListsUpdatedLoading || addIncomeProductsLoading,
        disabled: isDisabled(),
      }}
      modalTitle={t(modalTitleHandler()!)}
      btnContent={getBtnContent()}
      styleType={styleType}
      width={modalType?.component ? components.width?.[modalType?.component] : '65vw'}
      {...modalProps}
    >
      {modalType?.component ? components.modals?.[modalType?.component] : null}
    </ModalWrapper>
  );
};

export default ProductModals;
