import { useTranslation } from 'react-i18next';
import img from '../../../../assets/img/excel.jpg';

const Excel = () => {
  const { t } = useTranslation();

  const textStyles = {
    fontWeight: 500,
    fontSize: '14px',
    lineHeight: 1.4,
    color: '#000000',
    marginBottom: 16,
  };

  return (
    <div>
      <p style={textStyles}>{t('Products.ExcelText')}</p>
      <img
        style={{ width: '100%', objectFit: 'contain' }}
        width={904}
        height={173}
        src={img}
        alt="excel image"
      />
    </div>
  );
};

export default Excel;
