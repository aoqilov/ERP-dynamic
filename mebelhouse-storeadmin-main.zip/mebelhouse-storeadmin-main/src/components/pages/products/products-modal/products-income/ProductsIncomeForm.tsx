import { ITrash } from '@/components/svgs/svgs';
import CountButton from '@/components/ui/buttons/count-button/CountButton';
import MyButton from '@/components/ui/buttons/my-button/MyButton';
import MySelect from '@/components/ui/my-select/MySelect';
import MyTableBox from '@/components/ui/tables';
import TableImage from '@/components/ui/tables/table-image/TableImage';
import { SERVER_URL } from '@/lib/consts/url.consts';
import { convertDataForSelect } from '@/lib/utils/convertDataForSelect';
import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
import { useGetAllProductListsQuery } from '@/store/services/product-lists/product-lists.api';
import { TProductIncomeItemList } from '@/store/services/products/products.type';
import { setSelectedProductsList } from '@/store/slices/products.slice';
import { Col, Flex, Row, TableColumnsType, Input } from 'antd';
import { DefaultOptionType } from 'antd/es/select';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

// Utility function to format numbers with spaces for readability
export const formatNumberWithSpaces = (value: string | number): string => {
  if (typeof value === 'number') {
    value = value.toString();
  }
  return value.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
};

type TProductTransferType = {
  key: string;
  productId: string;
  name_ru: string;
  color: { id: number; name_ru: string };
  picture: string;
  marga: string; // Marga (percentage)
  cost_price: string; // Cost price for the input field
  sale_price: string; // Sale price for the input field
  quantity: number;
  colors: { id: number; quantity: number }[];
};

const ProductsIncomeForm = () => {
  const { token } = useAppSelector((state) => state.auth);
  const { data, isLoading } = useGetAllProductListsQuery({ token });
  const { t } = useTranslation();
  const [options, setOptions] = useState<DefaultOptionType[]>([]);
  const [value, setValue] = useState<string>();
  const [filteredData, setFilteredData] = useState<DefaultOptionType[]>([]);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [dataSource, setDatasource] = useState<TProductTransferType[]>([]);
  const dispatch = useAppDispatch();

  useEffect(() => {
    if (data) {
      const convertedOptions = convertDataForSelect({ label: 'name_ru', data: data?.data });
      setOptions(convertedOptions);
      setFilteredData(convertedOptions);
    }
  }, [data]);

  useEffect(() => {
    const existingProductIds = new Set(dataSource.map((item) => item.productId));
    const newFilteredData = options.filter(
      (option) => !existingProductIds.has(String(option.value)),
    );
    setFilteredData(newFilteredData);
  }, [dataSource, options]);

  const mapDataSourceToProductIncome = (
    dataSource: TProductTransferType[],
  ): TProductIncomeItemList => {
    const groupedByProduct = dataSource.reduce((acc, item) => {
      const existingProduct = acc.find((p) => p.product_list === parseInt(item.productId));

      const colorItem = {
        id: item.color.id,
        quantity: item.quantity,
      };

      if (item.quantity === 0) {
        return acc;
      }

      if (existingProduct) {
        existingProduct?.colors?.push(colorItem);
      } else {
        acc.push({
          product_list: parseInt(item.productId),
          cost_price: item.cost_price,
          sale_price: item.sale_price,
          colors: [colorItem], // Добавляем цвет с количеством
        });
      }

      return acc;
    }, [] as TProductIncomeItemList);

    return groupedByProduct;
  };

  const handleChange = (newValue: string | null) => {
    if (!newValue) {
      setValue(''); // Ensures the input is cleared if newValue is null
      setDropdownOpen(false);
      return;
    }

    setValue(''); // Reset the value after processing the selection
    setDropdownOpen(false);

    const selectedProduct = data?.data.find((product) => Number(product.id) === +newValue);
    if (selectedProduct) {
      const productRows = selectedProduct.colours.map((color) => ({
        key: `${selectedProduct.id}-${color.id}`,
        productId: selectedProduct.id.toString(),
        name_ru: selectedProduct.name_ru,
        color,
        picture: selectedProduct.images[0]?.path || '',
        marga: '0',
        cost_price: '0',
        sale_price: '0',
        quantity: 0,
        colors: [],
      }));

      const updatedDataSource = [...dataSource, ...productRows];
      setDatasource(updatedDataSource);

      const newOptions = options.filter((option) => option.value !== newValue);
      setOptions(newOptions);
      setFilteredData(newOptions);
    }
  };

  const handleSearch = (searchText: string) => {
    const filtered = options.filter(
      (option) =>
        typeof option.label === 'string' &&
        option.label.toLowerCase().includes(searchText.toLowerCase()) &&
        !dataSource.some((item) => item.productId === option.value), // Exclude already selected items
    );
    setFilteredData(filtered);
    setDropdownOpen(true);
  };

  const handleQuantityChange = (key: string, quantity: number) => {
    const updatedDataSource = dataSource.map((item) =>
      item.key === key ? { ...item, quantity: quantity } : item,
    );
    setDatasource(updatedDataSource);

    // Убедитесь, что обновленное состояние отправляется в dispatch
    const productIncomeList = mapDataSourceToProductIncome(updatedDataSource);
    dispatch(setSelectedProductsList([...productIncomeList])); // Передаем копию массива
  };
  const handleMargaChange = (key: string, marga: string) => {
    const updatedDataSource = dataSource.map((item) => {
      if (item.key === key) {
        const cost_price = parseFloat(item.cost_price);
        const sale_price = (cost_price + (cost_price * parseFloat(marga)) / 100).toFixed(2);
        return { ...item, marga, sale_price };
      }
      return item;
    });
    setDatasource(updatedDataSource);

    const productIncomeList = mapDataSourceToProductIncome(updatedDataSource);
    dispatch(setSelectedProductsList(productIncomeList));
  };

  const handleCostPriceChange = (key: string, cost_price: string) => {
    const updatedDataSource = dataSource.map((item) => {
      if (item.key === key) {
        const marga = parseFloat(item.marga);
        const sale_price = (
          parseFloat(cost_price) +
          (parseFloat(cost_price) * marga) / 100
        ).toFixed(2);
        return { ...item, cost_price, sale_price };
      }
      return item;
    });
    setDatasource(updatedDataSource);

    const productIncomeList = mapDataSourceToProductIncome(updatedDataSource);
    dispatch(setSelectedProductsList(productIncomeList));
  };

  const handleSalePriceChange = (key: string, sale_price: string) => {
    const updatedDataSource = dataSource.map((item) => {
      if (item.key === key) {
        const cost_price = parseFloat(item.cost_price);
        const marga = (((parseFloat(sale_price) - cost_price) / cost_price) * 100).toFixed(2);
        return { ...item, sale_price, marga };
      }
      return item;
    });
    setDatasource(updatedDataSource);

    const productIncomeList = mapDataSourceToProductIncome(updatedDataSource);
    dispatch(setSelectedProductsList(productIncomeList));
  };

  const handleRemove = (key: string) => {
    const updatedDataSource = dataSource.filter((item) => item.key !== key);
    setDatasource(updatedDataSource);

    // Check if all entries for this product have been removed
    const productStillExists = updatedDataSource.some(
      (item) => item.productId === dataSource.find((item) => item.key === key)?.productId,
    );

    // Find the removed item details to potentially add back to options
    const removedItem = dataSource.find((item) => item.key === key);

    if (removedItem && !productStillExists) {
      // Only add back if this product no longer has any entries in the dataSource
      if (!options.some((option) => option.value === removedItem.productId)) {
        const newOptions = [
          ...options,
          { value: removedItem.productId, label: removedItem.name_ru },
        ];
        setOptions(newOptions);
        setFilteredData(newOptions);
      }
    }

    const productIncomeList = mapDataSourceToProductIncome(updatedDataSource);
    dispatch(setSelectedProductsList(productIncomeList));
  };

  const columns: TableColumnsType<TProductTransferType> = [
    {
      title: t('Products.Products'),
      dataIndex: 'name_ru',
      key: 'name_ru',
      width: 200,
      render: (text, record) => {
        const sameProductRows = dataSource.filter((item) => item.productId === record.productId);
        const rowSpan =
          sameProductRows.findIndex((item) => item.key === record.key) === 0
            ? sameProductRows.length
            : 0;

        return {
          children: (
            <Flex
              align="center"
              vertical
              gap={10}
              style={{ height: '100%', justifyContent: 'start', textAlign: 'left' }}
            >
              <TableImage
                imgProps={{
                  src: `${SERVER_URL}/${record.picture}`,
                  preview: Boolean(record.picture),
                  alt: record.name_ru,
                }}
              />
              <span style={{ textAlign: 'center' }}>{text}</span>
            </Flex>
          ),
          props: {
            rowSpan,
            style: { textAlign: 'center', verticalAlign: 'middle' },
          },
        };
      },
    },

    {
      title: t('Products.Marga'),
      dataIndex: 'marga',
      key: 'marga',
      width: 60,
      render: (marga, record) => {
        const sameProductRows = dataSource.filter((item) => item.productId === record.productId);
        const rowSpan =
          sameProductRows.findIndex((item) => item.key === record.key) === 0
            ? sameProductRows.length
            : 0;

        return {
          children: (
            <Input
              type="text"
              value={formatNumberWithSpaces(marga)}
              onChange={(e) => handleMargaChange(record.key, e.target.value.replace(/\s/g, ''))}
              style={{ textAlign: 'center' }}
            />
          ),
          props: {
            rowSpan,
            style: { textAlign: 'center', verticalAlign: 'middle' },
          },
        };
      },
    },
    {
      title: t('Products.CostPrice'),
      dataIndex: 'cost_price',
      key: 'cost_price',
      width: 120,
      render: (cost_price, record) => {
        const sameProductRows = dataSource.filter((item) => item.productId === record.productId);
        const rowSpan =
          sameProductRows.findIndex((item) => item.key === record.key) === 0
            ? sameProductRows.length
            : 0;

        return {
          children: (
            <Input
              type="text"
              value={formatNumberWithSpaces(cost_price)}
              onChange={(e) => handleCostPriceChange(record.key, e.target.value.replace(/\s/g, ''))}
              style={{ textAlign: 'center' }}
            />
          ),
          props: {
            rowSpan,
            style: { textAlign: 'center', verticalAlign: 'middle' },
          },
        };
      },
    },
    {
      title: t('Products.SalePrice'),
      dataIndex: 'sale_price',
      key: 'sale_price',
      width: 120,
      render: (sale_price, record) => {
        const sameProductRows = dataSource.filter((item) => item.productId === record.productId);
        const rowSpan =
          sameProductRows.findIndex((item) => item.key === record.key) === 0
            ? sameProductRows.length
            : 0;

        return {
          children: (
            <Input
              type="text"
              value={formatNumberWithSpaces(sale_price)}
              onChange={(e) => handleSalePriceChange(record.key, e.target.value.replace(/\s/g, ''))}
              style={{ textAlign: 'center' }}
            />
          ),
          props: {
            rowSpan,
            style: { textAlign: 'center', verticalAlign: 'middle' },
          },
        };
      },
    },
    {
      title: t('Products.Color'),
      dataIndex: 'color',
      key: 'color',
      width: 120,
      render: (color: { name_ru: string }) => <p>{color.name_ru}</p>,
    },
    {
      title: t('Products.Quantity'),
      dataIndex: 'quantity',
      key: 'quantity',
      // width: 60,
      width: '10%',
      render: (quantity, record) => (
        <div style={{ height: '100%', display: 'flex', alignItems: 'center' }}>
          <CountButton
            initialCount={quantity}
            onCountChange={(count) => handleQuantityChange(record.key, count)}
          />
        </div>
      ),
    },
    {
      title: t('Common.Actions'),
      key: 'actions',
      width: '1%',
      align: 'center',
      render: (_, record) => (
        <MyButton
          onClick={() => handleRemove(record.key)}
          style={{ background: 'var(--color-red)', width: 32, height: 32 }}
          icon={<ITrash />}
        />
      ),
    },
  ];

  return (
    <Row gutter={[16, 16]}>
      <Col span={24}>
        <MySelect
          showSearch
          value={value}
          defaultActiveFirstOption={false}
          suffixIcon={null}
          filterOption={false}
          onChange={handleChange}
          onSearch={handleSearch}
          notFoundContent={isLoading ? t('Common.Loading') : null}
          formItemProps={{ label: t('Common.SearchByName') }}
          options={filteredData}
          allowClear
          id="ProductsSelect"
          placeholder={t('Products.SelectProducts')}
          open={dropdownOpen}
        />
      </Col>
      <Col span={24}>
        <MyTableBox tableProps={{ bordered: true }} columns={columns} dataSource={dataSource} />
      </Col>
    </Row>
  );
};

export default ProductsIncomeForm;
