import MyInput from '@/components/ui/my-input/MyInput';
import MySelect from '@/components/ui/my-select/MySelect';
import MyUpload from '@/components/ui/my-upload/MyUpload';
import { convertDataForSelect } from '@/lib/utils/convertDataForSelect';
import { useAppSelector } from '@/store/reduxHooks';
import { Col, Row } from 'antd';
import { useTranslation } from 'react-i18next';

const ProductsWriteOffForm = () => {
  const { t } = useTranslation();
  const { data } = useAppSelector((state) => state.modal);
  const colorOptions = convertDataForSelect({ label: 'name_ru', data: data?.colors });

  return (
    <>
      <Row gutter={[16, 16]}>
        <Col span={6}>
          <MyUpload
            type="photo"
            uploadProps={{ listType: 'picture-card', accept: 'image/*', disabled: true }}
          />
        </Col>
        <Col span={18}>
          <MyInput
            disabled={true}
            formItemProps={{
              name: 'name_ru',
              label: t('Products.NameRu'),
            }}
            id="NameRu"
            title={t('Products.NameRu')}
            placeholder={t('Products.NameRu')}
          />
        </Col>
        <Col span={24}>
          <MySelect
            options={colorOptions}
            allowClear
            formItemProps={{
              name: 'colors',
              label: t('Products.Color'),
              rules: [{ required: true, message: t('Common.Required') }],
            }}
            id="Color"
            title={t('Products.Color')}
            placeholder={t('Products.PickColor')}
          />
        </Col>
        <Col span={24}>
          <MyInput
            type="number"
            formItemProps={{
              name: 'quantity',
              label: t('Products.Qty'),
              rules: [{ required: true, message: t('Common.Required') }],
            }}
            id="Qty"
            title={t('Products.Qty')}
            placeholder={t('Products.Qty')}
          />
        </Col>
        <Col span={24}>
          <MyInput
            formItemProps={{
              name: 'comment',
              label: t('Products.Reason'),
            }}
            id="Reason"
            title={t('Products.Reason')}
            placeholder={t('Products.Reason')}
          />
        </Col>
      </Row>
    </>
  );
};

export default ProductsWriteOffForm;
