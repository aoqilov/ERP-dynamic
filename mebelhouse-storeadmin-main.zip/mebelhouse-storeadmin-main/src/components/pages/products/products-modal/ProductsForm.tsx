import MyInput from '@/components/ui/my-input/MyInput';
import MySelect from '@/components/ui/my-select/MySelect';
import MyUpload from '@/components/ui/my-upload/MyUpload';
import { convertDataForSelect } from '@/lib/utils/convertDataForSelect';
import { useAppSelector } from '@/store/reduxHooks';
import { useGetAllBrandQuery } from '@/store/services/brand/brand.api';
import { useGetAllCategoriesQuery } from '@/store/services/categories/categories.api';
import { useGetAllColorQuery } from '@/store/services/color/color.api';
import { useGetAllRegionQuery } from '@/store/services/region/region.api';
import { Col, Row } from 'antd';
import { DefaultOptionType } from 'antd/es/select';
import { FC } from 'react';
import { useTranslation } from 'react-i18next';

type Props = {
  setCategory: (v: number) => void;
};

const ProductsForm: FC<Props> = ({ setCategory }) => {
  const { t } = useTranslation();
  const { token } = useAppSelector((item) => item.auth)

  const { data: colorData } = useGetAllColorQuery();
  const { data: regionData } = useGetAllRegionQuery();
  const { data: brandData } = useGetAllBrandQuery();
  const { data: categoryData } = useGetAllCategoriesQuery({ token });

  // const colorOptions: SelectProps['options'] = [
  //   {
  //     label: 'Ясень',
  //     value: 1,
  //   },
  // ];

  // const regionOptions: SelectProps['options'] = [
  //   {
  //     label: 'Китай',
  //     value: 1,
  //   },
  // ];

  // const categorySelectOptions: SelectProps['options'] = [
  //   {
  //     label: <span>Садовая мебель</span>,
  //     value: 1,
  //     options: [
  //       { label: <span>Кресло</span>, value: 2 },
  //       { label: <span>Стол стеклянный</span>, value: 3 },
  //     ],
  //   },
  // ];

  const colorDataSelect = convertDataForSelect({ label: 'name_ru', data: colorData?.data });
  const regionDataSelect = convertDataForSelect({ label: 'name_ru', data: regionData?.data });
  const brandDataSelect = convertDataForSelect({ label: 'name_ru', data: brandData?.data });
  const categoryDataSelect = convertDataForSelect({
    label: 'name_ru',
    data: categoryData?.data,
    nested: {
      nestedItem: 'subcategories',
      nestedLabel: 'name_ru',
    },
  });

  const onFilterColor = (input: string, option: DefaultOptionType) => {
    const label = option?.label;
    if (typeof label === 'string') {
      return label.toLowerCase().includes(input.toLowerCase());
    }
    return false;
  };

  const handleCategoryChange = (_: unknown, option: DefaultOptionType) => {
    setCategory(option.category);
  };

  return (
    <>
      <Row gutter={[16, 16]}>
        <Col span={4}>
          <MyUpload type="photo" uploadProps={{ listType: 'picture-card', accept: 'image/*' }} />
        </Col>
        <Col span={10}>
          <MyInput
            formItemProps={{
              name: 'name_ru',
              label: t('Products.NameRu'),
            }}
            id="NameRu"
            title={t('Products.NameRu')}
            placeholder={t('Products.NameRu')}
          />
        </Col>
        <Col span={10}>
          <MyInput
            formItemProps={{
              name: 'name_uz',
              label: t('Products.NameUz'),
            }}
            id="NameUz"
            title={t('Products.NameUz')}
            placeholder={t('Products.NameUz')}
          />
        </Col>
        <Col span={12}>
          <MyInput
            formItemProps={{
              name: 'description_ru',
              label: t('Products.DescRu'),
            }}
            id="DescRu"
            title={t('Products.DescRu')}
            placeholder={t('Products.DescRu')}
          />
        </Col>
        <Col span={12}>
          <MyInput
            formItemProps={{
              name: 'description_uz',
              label: t('Products.DescUz'),
            }}
            id="DescUz"
            title={t('Products.DescUz')}
            placeholder={t('Products.DescUz')}
          />
        </Col>
        <Col span={12}>
          <MySelect
            options={colorDataSelect}
            mode="multiple"
            allowClear
            formItemProps={{
              name: 'colors',
              label: t('Products.Color'),
              rules: [{ required: true, message: t('Common.Required') }],
            }}
            id="Color"
            title={t('Products.Color')}
            placeholder={t('Products.PickColor')}
            filterOption={(input, option) => onFilterColor(input, option!)}
          />
        </Col>
        <Col span={12}>
          <MySelect
            options={regionDataSelect}
            allowClear
            formItemProps={{
              name: 'country',
              label: t('Products.Region'),
              rules: [{ required: true, message: t('Common.Required') }],
            }}
            id="Region"
            title={t('Products.Region')}
            placeholder={t('Products.SelectRegion')}
          />
        </Col>
        <Col span={12}>
          <MySelect
            options={brandDataSelect}
            formItemProps={{
              name: 'brand',
              label: t('Products.Brand'),
              rules: [{ required: true, message: t('Common.Required') }],
            }}
            id="Brand"
            title={t('Products.Brand')}
            placeholder={t('Products.SelectBrand')}
          />
        </Col>
        <Col span={12}>
          <MySelect
            onChange={handleCategoryChange}
            options={categoryDataSelect}
            formItemProps={{
              name: 'subcategory',
              label: t('Products.Category'),
              rules: [{ required: true, message: t('Common.Required') }],
            }}
            id="Category"
            title={t('Products.Category')}
            placeholder={t('Products.SelectCategory')}
          />
        </Col>
        <Col span={10}>
          <MyInput
            formItemProps={{
              name: 'barcode',
              label: t('Products.BarCode'),
              rules: [{ required: true, message: t('Common.Required') }],
            }}
            id="BarCode"
            title={t('Products.BarCode')}
            placeholder={t('Products.BarCode')}
          />
        </Col>
        {/* <Col span={2} style={{ display: 'flex', alignItems: 'flex-end', flexDirection: 'column' }}>
          <span style={{ opacity: '0%', paddingBottom: 8 }}>ex</span>
          <MyButton style={{ width: 52, height: 52 }} icon={<IREfresh />} />
          <span style={{ opacity: '0%' }}>ex</span>
        </Col> */}
      </Row>
    </>
  );
};

export default ProductsForm;
