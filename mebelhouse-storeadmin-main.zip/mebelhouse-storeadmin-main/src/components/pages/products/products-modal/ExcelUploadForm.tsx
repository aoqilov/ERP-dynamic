import MyUpload from '@/components/ui/my-upload/MyUpload';

const ExcelUploadForm = () => {
  return (
    <>
      <MyUpload
        type="file"
        uploadProps={{
          type: 'drag',
          accept:
            '.xls,.xlsx,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        }}
      />
    </>
  );
};

export default ExcelUploadForm;
