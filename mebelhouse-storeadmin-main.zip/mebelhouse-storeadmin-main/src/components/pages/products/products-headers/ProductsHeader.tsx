import { ISearch } from '@/components/svgs/svgs';
import MyButton from '@/components/ui/buttons/my-button/MyButton';
import MyInput from '@/components/ui/my-input/MyInput';
import MySelect from '@/components/ui/my-select/MySelect';
import { useDebounce } from '@/lib/hooks/useDebounce';
import useQueryParams from '@/lib/hooks/useQueryParams';
import { convertDataForSelect } from '@/lib/utils/convertDataForSelect';
import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
import { useGetAllCategoriesQuery } from '@/store/services/categories/categories.api';
import { useGetAllSubCategoriesQuery } from '@/store/services/sub-categories/sub-categories.api';
import { setBarCodePrint } from '@/store/slices/products.slice';
import { Flex, Tabs } from 'antd';
import { ChangeEvent, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { TabsType } from '../ProductsIndex';

type ProductsHeaderProps = {
  selectedRowKeys: React.Key[];
  onTabChange: ((activeKey: string) => void) | undefined;
  tab: TabsType;
  components?: Record<string, React.ReactNode>;
};

const ProductsHeader = ({ selectedRowKeys, tab, onTabChange, components }: ProductsHeaderProps) => {
  const { t } = useTranslation();
  const isSelected = selectedRowKeys.length > 0;

  const {
    auth: { token },
  } = useAppSelector((state) => state);
  const dispatch = useAppDispatch();
  const { data: categoryData } = useGetAllCategoriesQuery({ token });
  const { data: subcategoryData } = useGetAllSubCategoriesQuery({ token });
  const { setParams, getParam } = useQueryParams();
  const [searchValue, setSearchValue] = useState(getParam('search') || '');
  const debouncedSearchValue = useDebounce(searchValue, 500);

  const handleCategoryChange = (value: string) => {
    // const findSubcategory = subcategoryData?.data?.find(({ category }) => category?.id === value);

    setParams({ category: value, subcategory: '' });
  };

  const handleSubcategoryChange = (value: string) => {
    const findSubcategory = subcategoryData?.data?.find(({ id }) => id === value);

    setParams({ subcategory: value, category: findSubcategory?.category?.id || '' });
  };

  const handleSearchChange = (event: ChangeEvent<HTMLInputElement>) => {
    setSearchValue(event.target.value);
  };

  useEffect(() => {
    const currentParam = getParam('search');
    if (debouncedSearchValue !== currentParam) {
      setParams({ search: debouncedSearchValue });
    }
  }, [debouncedSearchValue, setParams, getParam]);

  const tabItems: { label: string; key: TabsType }[] = [
    {
      label: t('Products.AllProds'),
      key: 'products',
    },
    {
      label: t('Products.Sets'),
      key: 'set',
    },
  ];

  const categoryDataSelect = convertDataForSelect({
    label: 'name_ru',
    data: categoryData?.data,
    extraOption: {
      label: t('Common.AllCategories'),
      value: '',
    },
  });

  const subcategoryDataSelect = convertDataForSelect({
    label: 'name_ru',
    data: subcategoryData?.data?.filter(({ category }) =>
      getParam('category') ? category?.id === getParam('category') : true,
    ),
    extraOption: {
      label: t('Common.AllSubCategories'),
      value: '',
    },
  });

  return (
    <>
      <Flex gap={16} style={{ marginBottom: 24 }}>
        <MyInput
          isFormItem={false}
          size="large"
          value={searchValue}
          onChange={handleSearchChange}
          placeholder={t('Common.SearchByName')}
          suffix={<ISearch />}
        />
        {tab === 'products' && (
          <>
            <MySelect
              size="large"
              style={{ width: 200 }}
              onChange={handleCategoryChange}
              value={getParam('category') || ''}
              options={categoryDataSelect}
            />
            <MySelect
              size="large"
              style={{ width: 200 }}
              onChange={handleSubcategoryChange}
              value={getParam('subcategory') || ''}
              options={subcategoryDataSelect}
            />
          </>
        )}
      </Flex>
      {(tab === 'products' || tab === 'set') && isSelected && (
        <MyButton
          onClick={() => dispatch(setBarCodePrint({ printIsOpen: true }))}
          style={{ background: 'var(--color-green)' }}
          styleType="primary"
        >
          {t('Products.PrintSelected')}
        </MyButton>
      )}
      <Tabs
        style={{ fontWeight: 700 }}
        onChange={onTabChange}
        defaultActiveKey="1"
        items={tabItems}
      />
      {tab === 'set' && components?.setCheckboxAll}
    </>
  );
};

export default ProductsHeader;
