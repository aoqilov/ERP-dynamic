import { IDownload } from '@/components/svgs/svgs';
import MyButton from '@/components/ui/buttons/my-button/MyButton';
import { useAppDispatch } from '@/store/reduxHooks';
import { openModal } from '@/store/slices/modal.slice';
import { Flex } from 'antd';
import { useTranslation } from 'react-i18next';
import { TabsType } from '../ProductsIndex';
import { FC } from 'react';

type Props = {
  tab: TabsType;
};

const ProductsTopHeader: FC<Props> = () => {
  const { t } = useTranslation();
  const dispatch = useAppDispatch();

  return (
    <Flex gap={20}>
      <MyButton
        onClick={() =>
          dispatch(
            openModal({
              modalType: {
                component: 'productLists',
                style: 'form',
                manipulation: 'add',
              },
            }),
          )
        }
        styleType="white"
        icon={<IDownload />}
      >
        {t('Products.Download')}
      </MyButton>
    </Flex>
  );
};

export default ProductsTopHeader;
