import InventoryIndex from '@/components/pages/inventory/InventoryIndex';
import { Suspense } from 'react';

const InventoryPage = () => {
  return (
    <Suspense fallback={null}>
      <InventoryIndex />;
    </Suspense>
  );
};

export default InventoryPage;
