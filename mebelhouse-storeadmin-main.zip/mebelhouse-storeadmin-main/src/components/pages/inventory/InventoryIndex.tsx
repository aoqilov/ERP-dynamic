import { ISearch } from '@/components/svgs/svgs';
import MyRangePicker from '@/components/ui/my-date-picker/MyDatePicker';
import MyInput from '@/components/ui/my-input/MyInput';
import MyTableBox from '@/components/ui/tables';
import { useDebounce } from '@/lib/hooks/useDebounce';
import useQueryParams from '@/lib/hooks/useQueryParams';
import { useAppSelector } from '@/store/reduxHooks';
import { useGetAllInventoryQuery } from '@/store/services/inventory/inventory.api';
import { Flex } from 'antd';
import { t } from 'i18next';
import { ChangeEvent, FC, useEffect, useState } from 'react';
import MyContent from '../layout/MyContent';
import InventoryColumns from './InventoryColumns';

const InventoryIndex: FC = () => {
  const { token } = useAppSelector((state) => state.auth);
  const { setParams, getParam } = useQueryParams();
  const [search, setSearch] = useState('');
  const [period, setPeriod] = useState<[number | null, number | null] | null>();
  const debouncedSearch = useDebounce(search, 300);

  const { data, isLoading } = useGetAllInventoryQuery({
    token,
    page: +(getParam('current_page') || 1),
    page_size: +(getParam('page_size') || 10),
    search: debouncedSearch,
    created_at_from: String(period?.[0] || ''),
    created_at_to: String(period?.[1] || ''),
  });

  useEffect(() => {
    setParams({
      total_elements: String(data?.total_elements || 10),
      from: String(data?.from || 1),
      to: String(data?.to || 10),
      current_page: String(data?.current_page || 1),
    });
  }, [data?.data]);

  const handleSearchChange = (e: ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
  };

  const columns = InventoryColumns();

  const header = (
    <>
      <Flex gap={16} style={{ marginBottom: 24 }}>
        <MyInput
          onChange={handleSearchChange}
          isFormItem={false}
          size="large"
          placeholder={t('Common.SearchByName')}
          suffix={<ISearch />}
        />
        <MyRangePicker setDates={setPeriod} rangePickerProps={{ width: '60%' }} />
      </Flex>
    </>
  );

  return (
    <MyContent>
      <MyTableBox
        tableProps={{ loading: isLoading, scroll: { x: 'max-content' } }}
        dataSource={data?.data!}
        paginationProps={{ total: 10, current: 5 }}
        columns={columns}
        tableTitles={{
          title: t('Inventory.Inventory'),
          subTitle: t('Inventory.ActionsList'),
        }}
        header={header}
      />
    </MyContent>
  );
};

export default InventoryIndex;
