import { formatTimestamp } from '@/lib/utils/formatters/dateFormatter';
import { alphabeticalSort } from '@/lib/utils/sorters/alphabeticalSort';
import { TInventoryItem } from '@/store/services/inventory/inventory.type';
import { TableProps } from 'antd';
import Paragraph from 'antd/es/typography/Paragraph';
import { t } from 'i18next';

const InventoryColumns = () => {
  const columns: TableProps<TInventoryItem>['columns'] = [
    {
      dataIndex: 'executer',
      key: 'executer',
      title: <p style={{ textWrap: 'nowrap' }}>{t('Common.FullName')}</p>,
      width: 200,
      sorter: (a, b) => alphabeticalSort(a?.executer?.last_name, b?.executer?.last_name),
      render: (_, record) => {
        return (
          <p>
            {record?.executer.first_name}&nbsp;{record?.executer.first_name}
          </p>
        );
      },
    },
    {
      dataIndex: 'name_ru',
      key: 'name_ru',
      title: <p style={{ textWrap: 'nowrap' }}>{t('Common.Product')}</p>,
      sorter: (a, b) => alphabeticalSort(a?.product_list?.name_ru, b?.product_list?.name_ru),
      render: (_, record) => record?.product_list.name_ru,
    },
    {
      dataIndex: 'colour_name_ru',
      key: 'colour_name_ru',
      title: <p style={{ textWrap: 'nowrap' }}>{t('Common.Color')}</p>,
      render: (_, record) => record?.product_list?.colour_name_ru,
    },

    {
      dataIndex: 'category',
      key: 'category',
      title: <p style={{ textWrap: 'nowrap' }}>{t('CategoriesPage.Category')}</p>,
      render: (_, record) => record?.product_list?.sub_category?.category?.name_ru,
    },
    {
      dataIndex: 'sub_category',
      key: 'sub_category',
      title: <p style={{ textWrap: 'nowrap' }}>{t('CategoriesPage.SubCategory')}</p>,
      render: (_, record) => record?.product_list?.sub_category?.name_ru,
    },
    {
      dataIndex: 'barcode',
      key: 'barcode',
      width: 180,
      title: <p style={{ textWrap: 'nowrap' }}>{t('Products.BarCode')}</p>,
      render: (_, record) => (
        <Paragraph style={{ marginBottom: '0' }} copyable>
          {record?.product_list?.bar_code}
        </Paragraph>
      ),
    },
    {
      dataIndex: 'created_at',
      key: 'created_at',
      title: <p style={{ textWrap: 'nowrap' }}>{t('Common.Date')}</p>,
      render: (_, record) => formatTimestamp(+record.created_at),
    },
    {
      dataIndex: 'old_quantity',
      key: 'old_quantity',
      title: <p style={{ textWrap: 'nowrap' }}>{t('Common.OldQty')}</p>,
    },
    {
      dataIndex: 'new_quantity',
      key: 'new_quantity',
      title: <p style={{ textWrap: 'nowrap' }}>{t('Common.NewQty')}</p>,
    },
    {
      dataIndex: 'comment',
      key: 'comment',
      title: <p style={{ textWrap: 'nowrap' }}>{t('Common.Comment')}</p>,
      // width: 300,
    },
  ];

  return columns;
};

export default InventoryColumns;
