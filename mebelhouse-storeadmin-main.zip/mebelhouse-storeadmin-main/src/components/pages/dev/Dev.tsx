import MyContent from '../layout/MyContent';

const Dev = () => {
  return (
    <MyContent>
      <div style={{ fontSize: 32, fontWeight: 700 }}>На этапе разработки...</div>
    </MyContent>
  );
};

export default Dev;
