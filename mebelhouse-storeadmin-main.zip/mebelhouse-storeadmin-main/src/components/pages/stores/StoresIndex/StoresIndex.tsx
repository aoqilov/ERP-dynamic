import { ICross, IPen, IPlus, ISearch } from '@/components/svgs/svgs';
import MyButton from '@/components/ui/buttons/my-button/MyButton';
import MyInput from '@/components/ui/my-input/MyInput';
import MyTableBox from '@/components/ui/tables';
import { Locale } from '@/i18n';
import { useDebounce } from '@/lib/hooks/useDebounce';
import { LangEnum } from '@/lib/types/lang.type';
import { langConverterActions } from '@/lib/utils/langHandlers';
import { alphabeticalSort } from '@/lib/utils/sorters/alphabeticalSort';
import { useAppDispatch, useAppSelector } from '@/store/reduxHooks';
import { useGetAllShowroomsQuery } from '@/store/services/showrooms/showrooms.api';
import { TShowroomsItem } from '@/store/services/showrooms/showrooms.type';
import { openModal } from '@/store/slices/modal.slice';
import type { TableColumnsType } from 'antd';
import { Flex, Space, Spin } from 'antd';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import MyContent from '../../layout/MyContent';
import './stores-index.css';

const StoresIndex = () => {
  const [searchName, setSearchName] = useState('');
  const {
    t,
    i18n: { language },
  } = useTranslation();
  const { token } = useAppSelector((state) => state.auth);

  const debounceSearchName = useDebounce(searchName, 300);

  const getAllShowroomsResult = useGetAllShowroomsQuery(
    { token, name: debounceSearchName },
    { skip: !token },
  );

  // const getOneShowroomsResult = useGetOneShowroomsQuery({ token, id: 1 }, { skip: !token });
  // const [createShowroomsTrigger, createShowroomsResult] = useCreateShowroomsMutation();
  // const [updateShowroomsTrigger, updateShowroomsResult] = useUpdateShowroomsMutation();
  // const [deleteShowroomsTrigger, deleteShowroomsResult] = useDeleteShowroomsMutation();

  const dispatch = useAppDispatch();
  const columnData = t('StoresPage.TableColumns', {
    returnObjects: true,
  }) as Array<{
    title: string;
  }>;

  let columns: TableColumnsType<TShowroomsItem> = [
    {
      dataIndex: `name_${language}`,
      key: `name_${language}`,
      width: 450,
      sorter: (a, b) =>
        // @ts-ignore
        alphabeticalSort(a[`name_${language as LangEnum}`], b[`name_${language as LangEnum}`]),
    },
    {
      title: 'CashReg',
      dataIndex: 'cashReg',
      key: 'age',
      width: 450,
      render: () => 1,
    },
    {
      width: 165,
      align: 'center',
      dataIndex: 'actions',
      key: 'actions',
      render: (_text, record) => (
        <Space size="middle">
          <MyButton
            href={`/stores/form?id=${record?.id}`}
            style={{ background: 'var(--color-blue)', width: 32, height: 32 }}
            icon={<IPen />}
          />
          <MyButton
            onClick={() => {
              dispatch(
                openModal({
                  // id: +record.key,
                  id: String(record?.id),
                  modalType: {
                    component: 'store',
                    style: 'delete',
                  },
                }),
              );
            }}
            style={{ background: 'var(--color-orange)', width: 32, height: 32 }}
            icon={<ICross />}
          />
        </Space>
      ),
    },
  ];

  columns = columns.map((item, index) => {
    const translation = columnData[index];

    if (index === columns.length - 1) {
      return {
        ...item,
        title: langConverterActions(language as Locale),
      };
    }

    return {
      ...item,
      title: translation?.title,
    };
  });

  // const handleChange = (value: string) => {
  //   console.log(value);
  // };

  const topHeader = (
    <MyButton styleType="orange" href={'/stores/form'} icon={<IPlus />}>
      {t('StoresPage.AddStore')}
    </MyButton>
  );

  const header = (
    <Flex gap={16} style={{ marginBottom: 24 }}>
      <MyInput
        inputType="text"
        isFormItem={false}
        value={searchName}
        onChange={(e) => setSearchName(e?.target?.value)}
        size="large"
        placeholder={t('Common.SearchByName')}
        suffix={
          getAllShowroomsResult?.isFetching && Boolean(searchName) ? (
            <Spin size="small" />
          ) : (
            <ISearch />
          )
        }
      />
      {/* <MySelect
        size="large"
        defaultValue=""
        style={{ width: 250 }}
        onChange={handleChange}
        options={[
          { value: '', label: t('StoresPage.AllStores') },
          { value: 'jack', label: 'Кашгар' },
          { value: 'lucy', label: 'Иппадром' },
        ]}
      /> */}
    </Flex>
  );

  return (
    <MyContent>
      <MyTableBox
        columns={columns}
        dataSource={getAllShowroomsResult?.data?.data || []}
        tableTitles={{ title: t('Common.Stores'), subTitle: t('StoresPage.ManageStores') }}
        topHeader={topHeader}
        header={header}
      />
    </MyContent>
  );
};

export default StoresIndex;
