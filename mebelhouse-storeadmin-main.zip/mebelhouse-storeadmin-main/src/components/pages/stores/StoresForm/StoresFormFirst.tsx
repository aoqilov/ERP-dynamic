import MyInput from '@/components/ui/my-input/MyInput';
import { getErrorMessage } from '@/lib/utils/getErrorMessage';
import { useAppSelector } from '@/store/reduxHooks';
import {
  useCreateShowroomsMutation,
  useGetOneShowroomsQuery,
  useUpdateShowroomsMutation,
} from '@/store/services/showrooms/showrooms.api';
import {
  TCreateShowroomsBody,
  TUpdateShowroomsBody,
} from '@/store/services/showrooms/showrooms.type';
import { Button, Col, Flex, Form, message, Row, Spin, Typography } from 'antd';
import { FormInstance } from 'antd/lib';
import { createRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate, useSearchParams } from 'react-router-dom';
import CashRegs from './CashRegs/CashRegs';
import './stores-form.css';
const { Text } = Typography;

const StoresFormFirst = () => {
  const { t } = useTranslation();
  const { token } = useAppSelector((state) => state.auth);
  const navigate = useNavigate();

  const [searchParams] = useSearchParams();
  const id = searchParams.get('id');

  const getOneShowroomsResult = useGetOneShowroomsQuery(
    { token, id: String(id) },
    { skip: !token || !id },
  );

  const [createShowroomsTrigger, createShowroomsResult] = useCreateShowroomsMutation();
  const [updateShowroomsTrigger, updateShowroomsResult] = useUpdateShowroomsMutation();

  const initialValues = {
    remember: true,
    name: getOneShowroomsResult?.data?.data?.name,
    address: (getOneShowroomsResult?.data?.data as any)?.address || '',
    phone: (getOneShowroomsResult?.data?.data as any)?.phone || '',
  };

  const formRef = createRef<FormInstance>();

  const onFinish = (values: { name: string; address: string; phone: string }) => {
    if (id) {
      const body: TUpdateShowroomsBody = {
        address: values?.address,
        name: values?.name,
        phone: values?.phone,
      };

      updateShowroomsTrigger({ body, id: String(id), token });
    } else {
      const body: TCreateShowroomsBody = {
        address: values?.address,
        name: values?.name,
        phone: values?.phone,
      };

      createShowroomsTrigger({ body, token });
    }
  };

  useEffect(() => {
    const isSuccess = createShowroomsResult?.isSuccess || updateShowroomsResult?.isSuccess;
    const isError = createShowroomsResult?.isError || updateShowroomsResult?.isError;
    if (isSuccess) {
      navigate('/stores');
      message.success(id ? 'Успешно обновлен' : 'Успешно создано');
    }

    if (isError) {
      message.error(getErrorMessage(createShowroomsResult?.error || updateShowroomsResult?.error));
    }
  }, [
    createShowroomsResult?.isSuccess,
    updateShowroomsResult?.isSuccess,
    createShowroomsResult?.isError,
    updateShowroomsResult?.isError,
  ]);

  const onFinishFailed = (errorInfo: any) => {
    // message.error('Login failed! Please check your input.');
    console.log('Failed:', errorInfo);
  };

  if (id && getOneShowroomsResult?.isLoading) {
    return (
      <Flex align="center" justify="center" style={{ height: '100%' }}>
        <Spin />
      </Flex>
    );
  }

  return (
    <div className="store-form-wrapper">
      <Flex className="store-form-wrapper__header" align="center" justify="space-between" gap={10}>
        <Text className="store-form-wrapper__title">{t('StoresPage.FillAllInputs')}</Text>
        <Button
          loading={createShowroomsResult?.isLoading || updateShowroomsResult?.isLoading}
          htmlType="submit"
          className="store-form-wrapper__btn"
          type="primary"
          style={{ width: 'auto' }}
          form="showroom"
        >
          {t('Common.Save')}
        </Button>
      </Flex>

      <Form
        id="showroom"
        layout="vertical"
        ref={formRef}
        initialValues={initialValues}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
      >
        <Row style={{ marginBottom: 16 }}>
          <Col span={24}>
            <MyInput
              formItemProps={{ name: 'name', label: t('StoresPage.Name') }}
              id="name"
              title={t('StoresPage.Name')}
              size="large"
              placeholder={t('StoresPage.Name')}
            />
          </Col>
        </Row>
        <Row className="store-form-wrapper__second-row" gutter={16} style={{ paddingBottom: 32 }}>
          <Col span={12}>
            <MyInput
              formItemProps={{ name: 'address', label: t('StoresPage.Address') }}
              id="address"
              title={t('StoresPage.Address')}
              size="large"
              placeholder={t('StoresPage.Address')}
            />
          </Col>
          <Col span={12}>
            <MyInput
              formItemProps={{ name: 'phone', label: t('StoresPage.Phone') }}
              id="phone"
              title={t('StoresPage.Phone')}
              size="large"
              placeholder={t('StoresPage.Phone')}
            />
          </Col>
        </Row>
        <CashRegs />
      </Form>
    </div>
  );
};

export default StoresFormFirst;
