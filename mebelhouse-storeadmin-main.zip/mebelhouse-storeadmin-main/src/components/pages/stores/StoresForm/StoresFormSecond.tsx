import MyInput from '@/components/ui/my-input/MyInput';
import { Locale } from '@/i18n';
import { validateMinMessage } from '@/lib/utils/validations';
import { Button, Col, Flex, Form, Row, Typography } from 'antd';
import { FormInstance } from 'antd/lib';
import { createRef } from 'react';
import { useTranslation } from 'react-i18next';
import './stores-form.css';
const { Text } = Typography;

const StoresFormSecond = () => {
  const {
    t,
    i18n: { language },
  } = useTranslation();

  const formRef = createRef<FormInstance>();

  const onFinish = (values: any) => {
    // message.success('Login successful!');
    console.log('Received values: ', values);
    // navigate('/');
  };

  const onFinishFailed = (errorInfo: any) => {
    // message.error('Login failed! Please check your input.');
    console.log('Failed:', errorInfo);
  };

  return (
    <div className="store-form-wrapper">
      <Form
        layout="vertical"
        ref={formRef}
        name="login"
        initialValues={{ remember: true }}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
      >
        <Flex
          className="store-form-wrapper__header"
          align="center"
          justify="space-between"
          gap={10}
        >
          <Text className="store-form-wrapper__title">{t('StoresPage.Passwords')}</Text>
          <Button htmlType="submit" className="store-form-wrapper__btn" type="primary">
            {t('Common.Save')}
          </Button>
        </Flex>
        <Row gutter={16}>
          <Col span={12}>
            <MyInput
              formItemProps={{ name: 'login', label: t('StoresPage.Login') }}
              id="login"
              title={t('StoresPage.Login')}
              size="large"
              placeholder={t('StoresPage.Login')}
            />
          </Col>
          <Col span={12}>
            <MyInput
              formItemProps={{
                name: 'password',
                rules: [
                  { required: true, message: t('Common.Required') },
                  { min: 6, message: validateMinMessage(6, language as Locale) },
                ],
                label: t('StoresPage.Password'),
              }}
              type="password"
              id="password"
              title={t('StoresPage.Password')}
              size="large"
              placeholder={t('StoresPage.Password')}
            />
          </Col>
        </Row>
      </Form>
    </div>
  );
};

export default StoresFormSecond;
