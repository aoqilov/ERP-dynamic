import { IPlus } from '@/components/svgs/svgs';
import MyButton from '@/components/ui/buttons/my-button/MyButton';
import MyInput from '@/components/ui/my-input/MyInput';
import { Col, Flex, Row } from 'antd';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { AiOutlineDelete } from 'react-icons/ai';

const CashRegs = () => {
  const { t } = useTranslation();

  // State to keep track of the cash registers
  const [cashRegs, setCashRegs] = useState([{ key: Date.now() }]);

  const addCashReg = () => {
    setCashRegs([...cashRegs, { key: Date.now() }]); // Add a new cash register row
  };

  const deleteCashReg = (index: number) => {
    const newCashRegs = cashRegs.filter((_, i) => i !== index);
    setCashRegs(newCashRegs); // Remove the specific cash register row
  };

  return (
    <>
      {cashRegs.map((cashReg, index) => (
        <Row className="store-form-wrapper__third-row" gutter={16} key={cashReg.key}>
          <Col span={12}>
            <MyInput
              required={false}
              formItemProps={{ name: `cashReg-${index}`, label: t('StoresPage.CashReg') }}
              style={{ marginBottom: 0 }}
              id={`cashReg-${index}`}
              title={t('StoresPage.CashReg')}
              size="large"
              placeholder={t('StoresPage.CashReg')}
            />
          </Col>
          <Col span={12}>
            <Flex justify="space-between" align="center">
              <MyInput
                required={false}
                formItemProps={{
                  name: `deviceCode-${index}`,
                  label: t('StoresPage.DeviceCode'),
                  style: { width: '100%', marginBottom: 16 },
                }}
                id={`deviceCode-${index}`}
                title={t('StoresPage.DeviceCode')}
                size="large"
                placeholder={t('StoresPage.DeviceCode')}
              />

              {index > 0 && (
                <MyButton
                  danger
                  className="stores-form-wrapper__delete-cash-reg"
                  onClick={() => deleteCashReg(index)}
                  icon={<AiOutlineDelete />}
                  style={{ marginLeft: '10px' }} // Add some spacing
                />
              )}
            </Flex>
          </Col>
        </Row>
      ))}
      <Flex justify="flex-end">
        <MyButton
          className="stores-form-wrapper__add-cash-reg"
          styleType="white"
          icon={<IPlus />}
          onClick={addCashReg}
        >
          {t('StoresPage.AddCashReg')}
        </MyButton>
      </Flex>
    </>
  );
};

export default CashRegs;
