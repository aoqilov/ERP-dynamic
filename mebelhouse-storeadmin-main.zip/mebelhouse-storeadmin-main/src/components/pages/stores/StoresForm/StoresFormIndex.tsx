import { ConfigProvider, Flex, Space, Typography } from 'antd';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';

import StoresFormFirst from '@/components/pages/stores/StoresForm/StoresFormFirst';
import { IArrowLeft } from '@/components/svgs/svgs';
import MyContent from '../../layout/MyContent';

// type TabsType = 'first' | 'second';

const StoresFormIndex = () => {
  const { t } = useTranslation();
  const { Text } = Typography;
  // const [tab, setTab] = useState('1');

  // const tabItems = [
  //   {
  //     label: t('StoresPage.Tab1'),
  //     key: '1',
  //   },
  //   {
  //     label: t('StoresPage.Tab2'),
  //     key: '2',
  //   },
  // ];

  // const onTabChange = (tab: string) => {
  //   setTab(tab);
  // };

  return (
    <Flex vertical>
      <ConfigProvider>
        <Space style={{ margin: '24px 0px 0px 24px' }} align="center">
          <Link to={'/stores'}>
            <IArrowLeft color="#A0AEC0" width={24} height={24} style={{ width: 24, height: 24 }} />
          </Link>
          <Text
            style={{
              fontWeight: 700,
              fontSize: 24,
              lineHeight: '31.2px',
            }}
          >
            {t('StoresPage.AddingStores')}
          </Text>
        </Space>
        <MyContent>
          {/* <Tabs
            style={{ fontWeight: 700, marginBottom: 24 }}
            onChange={onTabChange}
            // defaultActiveKey="1"
            items={tabItems}
          /> */}
          <StoresFormFirst />
          {/* {tab === '2' && <StoresFormSecond />} */}
        </MyContent>
      </ConfigProvider>
    </Flex>
  );
};

export default StoresFormIndex;
