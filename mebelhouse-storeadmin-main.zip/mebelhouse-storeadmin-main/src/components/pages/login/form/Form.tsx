import { MyInput } from '@/components/ui/my-input';
import { ROUTES } from '@/constants';
import { useAppDispatch } from '@/store/reduxHooks';
import { useSignInMutation } from '@/store/services/auth/auth.api';
import { TSignInBody } from '@/store/services/auth/auth.type';
import { setAuth } from '@/store/slices/auth.slice';
import { Button, Flex, Form, message } from 'antd';
import { FormInstance } from 'antd/lib';
import { createRef, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';

export const LoginForm = () => {
  const { t } = useTranslation();
  const formRef = createRef<FormInstance>();
  const dispatch = useAppDispatch();
  const [signIn, { isLoading }] = useSignInMutation();
  const navigate = useNavigate();
  const [loginSuccess, setLoginSuccess] = useState(false);
  const [inputErrors, setInputErrors] = useState({
    username: false,
    password: false,
  });
  const [isButtonDisabled, setIsButtonDisabled] = useState(true);

  const onFinish = async (values: TSignInBody) => {
    const res = await signIn({ body: values });
    if (res?.data?.status_code === 200) {
      dispatch(setAuth(res?.data?.data));
      message.success(t('Common.Success'));
      setLoginSuccess(true);
      // navigate(ROUTES.home);
    } else {
      message.error(t('Common.CantSignIn'));
    }
  };

  const onFinishFailed = (errorInfo: any) => {
    const errors = errorInfo.errorFields.reduce(
      (acc: any, curr: any) => {
        acc[curr.name[0]] = true;
        return acc;
      },
      { username: false, password: false },
    );
    setInputErrors(errors);
  };

  const onValuesChange = (_changedValues: any, allValues: any) => {
    const allFieldsFilled = allValues.username && allValues.password;
    setIsButtonDisabled(!allFieldsFilled);
  };

  useEffect(() => {
    if (loginSuccess) {
      navigate(ROUTES.home);
    }
  }, [loginSuccess, navigate]);

  return (
    <Form
      ref={formRef}
      name="login"
      style={{ width: 400 }}
      initialValues={{ remember: true }}
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
      onValuesChange={onValuesChange}
      layout="vertical"
    >
      <Flex vertical gap="16px">
        <Form.Item
          label={t('Common.Login')}
          name="username"
          rules={[
            { required: true, message: t('Auth.RequiredUsername') },
            { min: 3, message: t('Auth.UsernameMinLength') },
          ]}
        >
          <MyInput
            size="large"
            placeholder={t('Auth.Username')}
            style={{
              borderColor: inputErrors.username ? 'red' : undefined,
            }}
          />
        </Form.Item>

        <Form.Item
          label={t('Common.Pass')}
          name="password"
          rules={[
            { required: true, message: t('Auth.RequiredPassword') },
            { min: 6, message: t('Auth.PasswordMinLength') },
          ]}
        >
          <MyInput
            inputType="password"
            size="large"
            placeholder={t('Auth.Password')}
            style={{
              borderColor: inputErrors.password ? 'red' : undefined,
            }}
          />
        </Form.Item>

        <Button
          disabled={isButtonDisabled}
          size="large"
          type="primary"
          loading={isLoading}
          htmlType="submit"
          block
          style={{
            backgroundColor: isButtonDisabled ? '#d3d3d3' : 'var(--color-primary)',
            height: '54px',
            borderRadius: '10px',
          }}
        >
          {t('Auth.Login')}
        </Button>
      </Flex>
    </Form>
  );
};
