import Logo from '@/components/ui/logo/Logo';
import { Col, Row, Typography } from 'antd';
import { useTranslation } from 'react-i18next';
import { footerAuthColorStyle, rightSideStyle } from './Login.styles';
import { LoginForm } from './form/Form';

const Login = () => {
  const { t } = useTranslation();

  return (
    <Row style={{ height: '100vh' }}>
      <Col
        span={12}
        style={{
          backgroundColor: 'white',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <div
          style={{
            width: '100%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            height: '100%',
          }}
        >
          <Logo width={400} height={141} />
        </div>

        <div style={rightSideStyle}>
          <Typography.Title style={{ color: 'white', fontWeight: 700 }}>
            {t('Login.loginTitle')}
          </Typography.Title>

          <Typography.Text style={{ color: 'white', fontSize: '18px' }}>
            {t('Login.loginDescription')}
          </Typography.Text>
        </div>
      </Col>

      <Col
        span={12}
        style={{
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          padding: '0 20px',
          gap: '32px',
        }}
      >
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
            height: '100%',
          }}
        >
          <div
            style={{ display: 'flex', alignItems: 'center ', gap: '32px', flexDirection: 'column' }}
          >
            <Typography.Title
              style={{
                fontSize: '24px',
                fontWeight: 700,
                display: 'flex',
              }}
            >
              {t('Auth.Title')}
            </Typography.Title>

            <LoginForm />
          </div>
        </div>

        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            width: '100%',
            marginTop: 'auto',
            paddingBottom: '20px',
          }}
        >
          <a target="_blank" href="https://dynamicsoft.uz">
            <Typography.Text style={{ ...footerAuthColorStyle, marginLeft: '10px' }}>
              {t('Auth.Developed')}&nbsp;Dynamic Soft
            </Typography.Text>
          </a>
        </div>
      </Col>
    </Row>
  );
};

export default Login;
