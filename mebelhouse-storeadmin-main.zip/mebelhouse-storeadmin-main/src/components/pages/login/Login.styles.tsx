import { CSSProperties } from 'react';

export const rightSideStyle: CSSProperties = {
  background: 'var(--color-secondary)',
  width: '100%',
  borderTop: '5px solid var(--color-primary)',
  padding: '50px',
  display: 'flex',
  flexDirection: 'column',
  gap: '24px',
};

export const footerAuthColorStyle: CSSProperties = {
  color: 'var(--color-secondary)',
};
