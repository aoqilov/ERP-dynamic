import MyContent from '../layout/MyContent';
import ReturnIndex from './ReturnIndex';

export const ReturnPage = () => (
  <MyContent>
    <ReturnIndex />
  </MyContent>
);
