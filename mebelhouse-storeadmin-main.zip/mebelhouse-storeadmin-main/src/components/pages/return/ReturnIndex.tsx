import { ISearch } from '@/components/svgs/svgs';
import MyRangePicker from '@/components/ui/my-date-picker/MyDatePicker';
import MyInput from '@/components/ui/my-input/MyInput';
import MyTableBox from '@/components/ui/tables';
import { useDebounce } from '@/lib/hooks/useDebounce';
import useQueryParams from '@/lib/hooks/useQueryParams';
import { useAppSelector } from '@/store/reduxHooks';
import { useGetAllProductsReturnQuery } from '@/store/services/return/return.api';
import { Flex, Tabs } from 'antd';
import { t } from 'i18next';
import { ChangeEvent, FC, useEffect, useState } from 'react';
import ReturnColumns from './ReturnColumns';

export type TabsTypeReturn = 'products' | 'set';

const ReturnIndex: FC = () => {
  const { token } = useAppSelector((state) => state.auth);
  const { setParams, getParam } = useQueryParams();
  const [search, setSearch] = useState('');
  const [period, setPeriod] = useState<[number | null, number | null] | null>();
  const [tab, setTab] = useState<TabsTypeReturn>('products');
  // const [dataSource, setDataSource] = useState<TReturnList>([]);

  const debouncedSearch = useDebounce(search, 500);

  const { data, isLoading } = useGetAllProductsReturnQuery({
    sets: tab === 'set',
    token,
    page: +(getParam('current_page') || 1),
    page_size: +(getParam('page_size') || 10),
    search: debouncedSearch,
    created_at_from: String(period?.[0] || ''),
    created_at_to: String(period?.[1] || ''),
  });

  useEffect(() => {
    setParams({
      total_elements: String(data?.total_elements || 10),
      from: String(data?.from || 1),
      to: String(data?.to || 10),
      current_page: String(data?.current_page || 1),
    });
  }, [data?.data]);

  const handleSearchChange = (e: ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
  };

  const columns = ReturnColumns({ data: data!, isLoading, tab });

  const tabItems: { label: string; key: TabsTypeReturn }[] = [
    {
      label: t('Products.Products'),
      key: 'products',
    },
    {
      label: t('Products.Sets'),
      key: 'set',
    },
  ];

  const onTabChange = (tab: string) => {
    setTab(tab as TabsTypeReturn);
    setParams({ current_page: String(1) });
  };

  const header = (
    <>
      <Flex gap={16} style={{ marginBottom: 24 }}>
        <MyInput
          onChange={handleSearchChange}
          isFormItem={false}
          size="large"
          placeholder={t('Common.SearchByName')}
          suffix={<ISearch />}
        />
        <MyRangePicker setDates={setPeriod} rangePickerProps={{ width: '60%' }} />
      </Flex>
      <Tabs
        style={{ fontWeight: 700 }}
        onChange={onTabChange}
        defaultActiveKey="1"
        items={tabItems}
      />
    </>
  );

  return (
    <>
      <MyTableBox
        isCollapse={true}
        collapseItems={columns}
        tableProps={{ loading: isLoading }}
        dataSource={data?.data!}
        paginationProps={{ total: 10, current: 5 }}
        columns={columns}
        tableTitles={{
          title: t('Return.Return'),
          subTitle: t('Return.ListOfProducts'),
        }}
        header={header}
      />
    </>
  );
};

export default ReturnIndex;
