import MyPopup from '@/components/ui/my-pop-up/MyPopup';
import MyTable from '@/components/ui/tables/MyTable/MyTable';
import { formatCurrency } from '@/lib/utils/formatters/currencyFormatter';
import { formatTimestamp } from '@/lib/utils/formatters/dateFormatter';
import { formatNumberWithSpaces } from '@/lib/utils/formatters/formatNumberWithSpaces';
import { alphabeticalSort } from '@/lib/utils/sorters/alphabeticalSort';
import { TGetAllReturnResponse, TReturnProductsType } from '@/store/services/return/return.type';
import { Flex, Space, TableProps } from 'antd';
import Paragraph from 'antd/es/typography/Paragraph';
import { CollapseProps } from 'antd/lib';
import { t } from 'i18next';
import { Typography } from 'antd';
import { TabsTypeReturn } from './ReturnIndex';

type Props = {
  data: TGetAllReturnResponse;
  isLoading: boolean;
  tab?: TabsTypeReturn;
};

const ReturnColumns = ({ data, isLoading, tab }: Props) => {
  const columns: TableProps<TReturnProductsType>['columns'] = [
    {
      dataIndex: 'product_name_ru',
      key: 'product_name_ru',
      title: <p style={{ textWrap: 'nowrap' }}>{t('Common.Product')}</p>,
      ellipsis: true,
      sorter: (a, b) => alphabeticalSort(a?.product_name_ru, b?.product_name_ru),
      render: (_, record) => record?.product_name_ru,
    },
    {
      dataIndex: 'quantity',
      key: 'quantity',
      width: 150,
      align: 'center',
      title: <p style={{ textWrap: 'nowrap' }}>{t('Products.Quantity')}</p>,
      render: (_, record) => {
        return (
          <Space size={[10, 10]}>
            <MyPopup data={record?.quantities} keyLabel="colour_name_ru" keyNumber="quantity" />
            {record?.quantities && record?.quantities.length > 0
              ? record?.quantities.reduce((acc, item) => acc + +item.quantity, 0)
              : t('Common.NotInStock')}
          </Space>
        );
      },
    },
    {
      dataIndex: 'category',
      key: 'category',
      ellipsis: true,
      title: <p style={{ textWrap: 'nowrap' }}>{t('CategoriesPage.Category')}</p>,
      render: (_, record) => record?.category_name_ru,
    },
    // {
    //   dataIndex: 'sub_category',
    //   key: 'sub_category',
    //   ellipsis: true,
    //   title: <p style={{ textWrap: 'nowrap' }}>{t('CategoriesPage.SubCategory')}</p>,
    //   render: (_, record) => record.subcategory_name_ru,
    // },
    {
      dataIndex: 'barcode',
      key: 'barcode',
      ellipsis: true,
      title: <p style={{ textWrap: 'nowrap' }}>{t('Products.BarCode')}</p>,
      render: (_, record) => (
        <Paragraph style={{ marginBottom: '0' }} copyable>
          {record?.bar_code}
        </Paragraph>
      ),
    },
    {
      dataIndex: 'return_product_price',
      key: 'return_product_price',
      ellipsis: true,
      title: <p style={{ textWrap: 'nowrap' }}>{t('Products.SalePrice')}</p>,
      render: (value) => formatNumberWithSpaces(value),
    },
  ];

  const collapseItems: CollapseProps['items'] = data?.data?.map((item) => ({
    key: item.id,
    headerClass: 'flex-x-center',
    label: (
      <>
        <Flex justify="space-between">
          <div style={{ display: 'flex', gap: 10 }}>
            <span>
              <span style={{ fontWeight: 700 }}>{t('Return.Cashier')}:</span>{' '}
              {item.cashier.first_name}&nbsp;{item.cashier.last_name}
            </span>
            {tab === 'set' && <span style={{ fontWeight: 700 }}>СЭТ {item?.set?.name}</span>}
            &nbsp;|&nbsp;
            <div>
              <span style={{ fontWeight: 700 }}>{t('Return.CashReg')}:</span>
              {item.cash_register.name}
            </div>
            {/* <span style={{ fontWeight: 700 }}>№{item?.order_number}</span> */}
            <p>{formatTimestamp(+item.created_at)}</p>
          </div>
          <span style={{ fontWeight: 700 }}>{formatCurrency(+item.return_total_price)}</span>
        </Flex>
        <Typography.Text style={{ marginTop: 16 }}>
          <Typography.Text style={{ fontWeight: 700, color: 'var(--color-red)' }}>
            {' '}
            {t('Return.Reason')}
          </Typography.Text>
          : {item.reason}
        </Typography.Text>
      </>
    ),
    children: (
      <MyTable
        tableProps={{
          loading: isLoading,
          size: 'middle',
          scroll: { x: 'max-content' },
          rowKey: 'id',
        }}
        columns={columns}
        dataSource={item.items}
      />
    ),
  }));

  return collapseItems;
};

export default ReturnColumns;
