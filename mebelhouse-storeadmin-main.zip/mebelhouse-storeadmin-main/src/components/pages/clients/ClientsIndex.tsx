import { ISearch } from '@/components/svgs/svgs';
import MyInput from '@/components/ui/my-input/MyInput';
import MyTableBox from '@/components/ui/tables';
import { useDebounce } from '@/lib/hooks/useDebounce';
import useQueryParams from '@/lib/hooks/useQueryParams';
import { useAppSelector } from '@/store/reduxHooks';
import { useGetAllClientsQuery } from '@/store/services/clients/clients.api';
import { TClientsList } from '@/store/services/clients/clients.type';
import { Flex } from 'antd';
import { ChangeEvent, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import MyContent from '../layout/MyContent';
import ClientColumns from './ClientColumns';

const ClientsIndex = () => {
  const [searchName, setSearchName] = useState('');
  const {
    auth: { token },
  } = useAppSelector((state) => state);

  const { getParam, setParams } = useQueryParams();
  const debounceSearchName = useDebounce(searchName, 300);

  const { data: clientsData, isLoading } = useGetAllClientsQuery(
    {
      search: debounceSearchName,
      token: token,
      page_size: +(getParam('page_size') || 10),
      page: +(getParam('current_page') || 1),
    },
    { skip: !token },
  );

  useEffect(() => {
    setParams({
      total_elements: String(clientsData?.total_elements || 10),
      from: String(clientsData?.from || 1),
      to: String(clientsData?.to || 10),
      current_page: String(clientsData?.current_page || 1),
    });
  }, [clientsData?.data]);

  const { t } = useTranslation();

  const handleSearchChange = (e: ChangeEvent<HTMLInputElement>) => {
    setSearchName(e.target.value);
  };

  const header = (
    <Flex gap={16} style={{ marginBottom: 24 }}>
      <MyInput
        onChange={handleSearchChange}
        isFormItem={false}
        size="large"
        placeholder={t('Common.SearchByName')}
        suffix={<ISearch />}
      />
    </Flex>
  );

  return (
    <MyContent>
      <MyTableBox
        paginationProps={{ total: 10, current: 5 }}
        columns={ClientColumns()}
        dataSource={clientsData?.data as TClientsList}
        tableTitles={{
          title: t('Clients.Clients'),
          subTitle: t('Clients.ListOfClients'),
        }}
        tableProps={{ loading: isLoading }}
        header={header}
      />
    </MyContent>
  );
};

export default ClientsIndex;
