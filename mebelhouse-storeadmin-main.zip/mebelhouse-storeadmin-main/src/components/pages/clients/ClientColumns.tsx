import { formatPhoneNumber } from '@/lib/utils/formatters/phoneNumberFormatter';
import { alphabeticalSort } from '@/lib/utils/sorters/alphabeticalSort';
import { TClientsItem } from '@/store/services/clients/clients.type';
import { TableColumnsType, Typography } from 'antd';
import { useTranslation } from 'react-i18next';

const ClientColumns = () => {
  const { t } = useTranslation();

  let columns: TableColumnsType<TClientsItem> = [
    {
      dataIndex: 'name',
      key: 'name',
      title: `${t('Clients.Name')}`,
      sorter: (a: TClientsItem, b: TClientsItem) => alphabeticalSort(a.name!, b.name!),
      width: 300,
    },
    {
      dataIndex: 'phone_number',
      key: 'phone_number',
      title: `${t('Clients.PhoneNumber')}`,
      width: 200,
      render: (value) => (
        <Typography.Link copyable href={`tel:${value}`}>
          {formatPhoneNumber({
            phoneNumber: value,
            customPattern: '+NNN NN NNN-NN-NN',
          })}
        </Typography.Link>
      ),
    },
    {
      dataIndex: 'description',
      key: 'description',
      title: `${t('Clients.ExtraInfo')}`,
    },
  ];

  return columns;
};

export default ClientColumns;
