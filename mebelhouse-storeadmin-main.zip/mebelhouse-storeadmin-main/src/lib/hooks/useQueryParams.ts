import { useLocation, useNavigate } from 'react-router-dom';

function useQueryParams() {
  const navigate = useNavigate();
  const { search, pathname } = useLocation();

  // Получение параметров как объект URLSearchParams
  const getParams = () => {
    return new URLSearchParams(search);
  };

  // Добавление или обновление нескольких параметров
  const setParams = (newParams: Record<string, string>) => {
    const params = getParams();

    // Обновляем или добавляем каждый новый параметр
    Object.keys(newParams).forEach((key) => {
      params.set(key, newParams[key]);
    });

    navigate(`${pathname}?${params.toString()}`, { replace: true });
  };

  // Удаление параметра
  const removeParam = (key: string) => {
    const params = getParams();
    params.delete(key);
    navigate(`${pathname}?${params.toString()}`, { replace: true });
  };

  return {
    getParam: (key: string) => getParams().get(key),
    setParams, // Обновленная функция для изменения нескольких параметров
    removeParam,
    getParams,
  };
}

export default useQueryParams;
