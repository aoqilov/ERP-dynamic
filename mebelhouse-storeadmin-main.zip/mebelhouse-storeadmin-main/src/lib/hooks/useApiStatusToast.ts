import { message } from 'antd';
import { useEffect } from 'react';

interface ApiStatus {
  isSuccess?: boolean;
  isError?: boolean;
  statusMessage?: string;
}

const useApiStatusToast = (statuses: ApiStatus[]) => {
  useEffect(() => {
    statuses.forEach(({ isSuccess, isError, statusMessage }) => {
      if (isSuccess) {
        message.success(statusMessage || 'Operation successful');
      }

      if (isError) {
        message.error(statusMessage || 'An error occurred');
      }
    });
  }, [statuses]);
};

export default useApiStatusToast;
