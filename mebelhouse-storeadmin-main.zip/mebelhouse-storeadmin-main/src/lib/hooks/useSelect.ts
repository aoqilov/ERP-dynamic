import { useAppDispatch } from '@/store/reduxHooks';
import { setSelectData } from '@/store/slices/select-data.slice';
import { useEffect } from 'react';
import { convertDataForSelect } from '../utils/convertDataForSelect';

export const useSelect = (data: Record<string, unknown>[]) => {
  const dispatch = useAppDispatch();
  useEffect(() => {
    dispatch(setSelectData({ data: convertDataForSelect({ label: 'name_ru', data: data || [] }) }));
  }, [data]);
};
