// import { usePathname, useRouter, useSearchParams } from 'next/navigation';
// import { createQueryParams, QueryParams } from 'utils/formatters/formatter-url/query-param-builder';

// function useUpdateQueryParams() {
//   const router = useRouter();
//   const pathname = usePathname();
//   const searchParams = useSearchParams();

//   const existingQueryParams = new URLSearchParams(searchParams);

//   return {
//     updateQuery: ({ newQueryParams }: { newQueryParams: QueryParams }) => {
//       const currentParams = createQueryParams({ queryParams: newQueryParams });
//       router.push(`?${currentParams.toString()}`);
//     },
//     clearQuery: () => {
//       router.push(pathname);
//     },
//     deleteQuery: (deleteQueryName: string) => {
//       existingQueryParams.delete(deleteQueryName);
//     },
//   };
// }

// export default useUpdateQueryParams;
