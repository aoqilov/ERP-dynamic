import { Locale } from '@/i18n';
import { useTranslation } from 'react-i18next';
import { validateMinMessage } from './validations';

export const Patterns = () => {
  const {
    t,
    i18n: { language },
  } = useTranslation();
  return {
    baseValidation: [
      { required: true, message: t('Common.Required') },
      {
        min: 1,
        message: validateMinMessage(1, language as Locale),
      },
    ],
  };
};
