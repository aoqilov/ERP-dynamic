export const convertToIds = (data: Record<string, unknown>[], key: string) => {
  return data?.map((item) => {
    return item?.[key];
  });
};
