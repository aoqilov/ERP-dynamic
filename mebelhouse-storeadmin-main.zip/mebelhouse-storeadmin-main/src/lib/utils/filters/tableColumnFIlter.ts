import { getNestedValue } from '@/lib/utils/getNestedValue';

type Params<TData = Record<string, string>[]> = {
  filterList: TData;
  fileterItemPath: 'category.name' | 'example' | 'example.name' | (string & {});
};

export const tableColumnFilter = ({ filterList, fileterItemPath }: Params) => {
  const filters = filterList.map((text) => ({ text: text, value: text }));

  const onFilter = (value: string, record: Record<string, any>) => {
    const item = getNestedValue(record, fileterItemPath);
    const filtered = item.indexOf(value as string) === 0;
    return filtered;
  };

  return {
    filters,
    onFilter,
  };
};
