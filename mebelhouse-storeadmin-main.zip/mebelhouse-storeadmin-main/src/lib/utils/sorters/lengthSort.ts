export const lengthSort = (a: string, b: string): number => {
  return a.length - b.length;
};
