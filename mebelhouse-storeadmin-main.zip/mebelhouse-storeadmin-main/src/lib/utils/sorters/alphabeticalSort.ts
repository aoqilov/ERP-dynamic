export const alphabeticalSort = (a: string, b: string): number => {
  return a.localeCompare(b);
};