import { Locale } from '@/i18n';

export const validateMinMessage = (limit: number, locale: Locale = 'ru') => {
  const obj = {
    en: `Should not be less than ${limit} symbols`,
    ru: `Должно быть не менее ${limit} символов`,
    uz: `${limit} simvoldan kam bolmasligi lozim`,
  };

  return obj[locale];
};
