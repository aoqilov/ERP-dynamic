export const removeLastSegments = (url: string, count: number = 1) => {
  const parts = url.split('/'); // Split the URL into parts
  parts.splice(-count, count); // Remove the specified number of elements from the end
  return parts.join('/'); // Reassemble the URL
};
