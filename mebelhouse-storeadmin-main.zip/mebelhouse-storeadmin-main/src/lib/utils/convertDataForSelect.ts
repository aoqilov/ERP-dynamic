// import { DefaultOptionType } from 'antd/es/select';

// export const convertDataForSelect = (
//   label: string,
//   data: DefaultOptionType[] = [],
//   nested?: { nestedItem: string; nestedLabel: string } | null,
//   extraOption?: { label: string; value: string } | null,
//   convertToIds?: boolean,
// ) => {
//   const convertedData = data.map((item) => {
//     let obj: DefaultOptionType = { value: item?.id, label: item?.[label] };

//     if (nested?.nestedItem) {
//       obj.options = item?.[nested?.nestedItem].map((subItem: Record<string, unknown>) => {
//         return {
//           label: subItem?.[nested?.nestedLabel],
//           value: subItem.id,
//           category: item?.id,
//         };
//       });
//     }

//     return obj;
//   });

//   // Append the extraOption at the end of the convertedData array
//   if (extraOption?.label) {
//     convertedData.unshift(extraOption);
//   }

//   if (convertToIds) {
//     return convertedData.map((item) => item.id);
//   }

//   return convertedData;
// };

import { DefaultOptionType } from 'antd/es/select';

type NestedOption = {
  nestedItem: string;
  nestedLabel: string;
};

type ExtraOption = {
  label: string;
  value: string;
};

type ConvertDataOptions = {
  label: string;
  data?: DefaultOptionType[];
  nested?: NestedOption;
  extraOption?: ExtraOption;
  
};

// Adjusted function
export const convertDataForSelect = ({
  label,
  data = [],
  nested,
  extraOption,

}: ConvertDataOptions) => {
  const convertedData = data.map((item) => {
    let obj: DefaultOptionType = { value: item?.id, label: item?.[label] };

    if (nested?.nestedItem) {
      obj.options = item?.[nested.nestedItem]?.map((subItem: Record<string, unknown>) => ({
        label: subItem?.[nested.nestedLabel],
        value: subItem.id,
        category: item?.id,
      }));
    }

    return obj;
  });

  // Append the extraOption at the beginning of the convertedData array
  if (extraOption) {
    convertedData.unshift(extraOption);
  }

  return convertedData; // This returns the options
};
