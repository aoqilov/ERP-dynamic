import { ModalState } from '@/store/slices/modal.slice';

export const getInitialValue = <T>(
  modalType: ModalState['modalType'],
  data: T,
  defaultValue: T | null = null,
) => {
  if (modalType?.manipulation === 'edit') {
    return data;
  }
  return defaultValue;
};
