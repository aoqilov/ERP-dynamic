import { TSalesList } from '@/store/services/sales/sales.type';

export function filterUniqueLocations(data: TSalesList): TSalesList {
  return data?.map((item) => {
    const seen = new Set<string>();
    const uniqueLocations = item.locations.filter((location) => {
      if (!seen.has(location.location_name)) {
        seen.add(location.location_name);
        return true;
      }
      return false;
    });

    return {
      ...item,
      locations: uniqueLocations,
    };
  });
}
