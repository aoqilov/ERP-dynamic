import { Locale } from '@/i18n';
import { ALLOWED_TYPE_PHOTOS, MAX_MB_PHOTOS } from '../consts/common';

export const langConverterActions = (locale: Locale) => {
  const obj = {
    ru: 'Действие',
    en: 'Actions',
    uz: 'Harakatlar',
  };

  return obj[locale];
};

export const langMaxMb = (locale: Locale) => {
  const obj = {
    ru: `Размер изображения не должен превышать ${MAX_MB_PHOTOS}MB`,
    en: `The image size must not exceed ${MAX_MB_PHOTOS}MB.`,
    uz: `Rasm hajmi ${MAX_MB_PHOTOS}MB dan oshmasligi kerak.`,
  };

  return obj[locale];
};

export const langAcceptence = (locale: Locale) => {
  const obj = {
    ru: `Вы можете загрузить только картинки в формате ${ALLOWED_TYPE_PHOTOS.join('/')}`,
    en: `You can only upload images in the format ${ALLOWED_TYPE_PHOTOS.join('/')}`,
    uz: `Siz faqat ${ALLOWED_TYPE_PHOTOS.join('/')} formatidagi rasmlarni yuklashingiz mumkin.`,
  };

  return obj[locale];
};
