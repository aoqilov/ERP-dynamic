export const getErrorMessage = (error: unknown): string => {
  let message: string;

  // First check if it's an instance of Error
  if (error instanceof Error) {
    message = error.message;
  }
  // Check if error is an object and has a 'message' property directly
  else if (error && typeof error === 'object' && 'message' in error) {
    message = String((error as { message: unknown }).message);
  }
  // Check for deeply nested error messages typical in API responses
  else if (error && typeof error === 'object' && 'error' in error) {
    const nestedError = (error as { error: any }).error;
    if (nestedError && typeof nestedError === 'object' && 'data' in nestedError) {
      const errorData = nestedError.data;
      if (errorData && typeof errorData === 'object' && 'message' in errorData) {
        message = String(errorData.message);
      } else {
        message = 'Что то пошло не так!';
      }
    } else {
      message = 'Что то пошло не так!';
    }
  }
  // Fallback if error is a string
  else if (typeof error === 'string') {
    message = error;
  } else {
    message = 'Что то пошло не так';
  }

  return message;
};
