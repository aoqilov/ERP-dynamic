// Utility function to format numbers with spaces for better readability
export const formatNumberWithSpaces = (value: string | number): string => {
  if (typeof value === 'number') {
    value = value.toString();
  }
  // Replace any group of three digits with space separation
  return value?.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
};
