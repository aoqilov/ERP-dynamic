import { Currencies } from '@/lib/types/currency.type';
import { Locale } from '@/lib/types/locales.type';

type Configs = {
  locale?: Locale;
  maximumFractionDigits?: number;
} & (
  | {
      style?: 'currency';
      currency?: Currencies | (string & {});
      format?: 'code' | 'name' | 'symbol';
    }
  | {
      style?: 'decimal';
      currency?: never;
      format?: never;
    }
);

type FormatCurrency = (price: number, configs?: Configs) => string;

const initalCurrencyConfig: Configs = {
  style: 'currency',
  currency: 'UZS',
  format: 'code',
  locale: 'ru-RU',
  maximumFractionDigits: 0,
};

export const formatCurrency: FormatCurrency = (value, { locale: newLocale, ...configs } = {}) => {
  const { locale: initialLocale, ...initialConfigs } = initalCurrencyConfig;
  const currencyFormat = { ...initialConfigs, ...configs };
  const currencyLocale = newLocale || initialLocale;

  const formatter = new Intl.NumberFormat(currencyLocale, currencyFormat);

  return formatter.format(value);
};

// EXAMPLE 📝
// const formattedCurrency = formatCurrency(20000, {
//   currency: 'USD',
//   format: 'code',
//   locale: 'en-US',
// });
// console.log(formattedCurrency) // $ 20 000
