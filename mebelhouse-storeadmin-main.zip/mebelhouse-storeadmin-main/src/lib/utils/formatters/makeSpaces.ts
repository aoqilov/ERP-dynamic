export const makeSpaces = (number: number) => {
  return number?.toLocaleString('ru');
};
