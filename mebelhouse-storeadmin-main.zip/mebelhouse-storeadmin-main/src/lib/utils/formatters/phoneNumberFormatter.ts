const phoneNumberPatterns = {
  US: { code: '1', pattern: '+N (NNN) NNN-NNNN' },
  CA: { code: '1', pattern: '+N (NNN) NNN-NNNN' },
  RU: { code: '7', pattern: '+N (NNN) NNN-NN-NN' },
  KZ: { code: '7', pattern: '+N (NNN) NNN-NN-NN' },
  AU: { code: '61', pattern: '+NN N NNNN NNNN' },
  ZA: { code: '27', pattern: '+NN NN NNN NNNN' },
  FR: { code: '33', pattern: '+NN N NNNN NNNN' },
  ES: { code: '34', pattern: '+NN NNN NNN NNN' },
  IT: { code: '39', pattern: '+NN NN NNNNNNNN' },
  GB: { code: '44', pattern: '+NN NN NNNN NNNN' },
  DE: { code: '49', pattern: '+NN (NNN) NNNNNN' },
  BR: { code: '55', pattern: '+NN (NN) NNNN-NNNN' },
  MX: { code: '52', pattern: '+NN (NNN) NNN-NNNN' },
  CN: { code: '86', pattern: '+NN (NNN) NNN-NNNN' },
  IN: { code: '91', pattern: '+NN NNNN NNNNNN' },
  JP: { code: '81', pattern: '+NN NN NNNN NNNN' },
  KR: { code: '82', pattern: '+NN NN NNN NNNN' },
  UA: { code: '380', pattern: '+NN (0NN) NNN-NN-NN' },
  BY: { code: '375', pattern: '+NNN NN NNN-NN-NN' },
  UZ: { code: '998', pattern: '+NNN (NN) NNN-NN-NN' },
} as const;

type CustomPattern =
  | (typeof phoneNumberPatterns)[keyof typeof phoneNumberPatterns]['pattern']
  | (string & {});

type Params =
  | {
      phoneNumber: string;
      phonePattern: keyof typeof phoneNumberPatterns;
      customPattern?: undefined;
    }
  | {
      phoneNumber: string;
      customPattern?: CustomPattern;
      phonePattern?: undefined;
    };

type FormatPhoneNumber = (params: Params) => string;

export const formatPhoneNumber: FormatPhoneNumber = ({
  phoneNumber,
  customPattern,
  phonePattern = 'UZ',
}) => {
  let phoneNumberSliced = phoneNumber.slice(1, phoneNumber.length);

  let pattern = customPattern ? customPattern : phoneNumberPatterns[phonePattern].pattern;

  const patternNumberCount = [...pattern].reduce(
    (acc, letter) => (letter === 'N' ? ++acc : acc),
    0,
  );

  if (phoneNumberSliced?.length !== patternNumberCount && phonePattern) {
    const findPatternByPhoneCode = Object.values(phoneNumberPatterns).find(({ code }) =>
      phoneNumberSliced.startsWith(code),
    );
    if (!findPatternByPhoneCode) return phoneNumberSliced;
    pattern = findPatternByPhoneCode.pattern;
  } else if (phoneNumberSliced.length !== patternNumberCount && customPattern) {
    return phoneNumberSliced;
  }

  let index = 0;
  const formatedPhoneNumber = pattern.replace(/N/g, () => phoneNumberSliced[index++] || '');

  return formatedPhoneNumber;
};

formatPhoneNumber({ phoneNumber: '998123456789', customPattern: '+NN (0NN) NNN-NN-NN' });
