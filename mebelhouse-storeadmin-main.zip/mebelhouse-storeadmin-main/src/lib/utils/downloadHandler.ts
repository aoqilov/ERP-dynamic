import { saveAs } from 'file-saver';

type Props = {
  data: BlobPart;
  error: unknown;
  fileName: string;
  fileType?: string;
  extension?: 'xlsx';
};

const excelFileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

export const handleDownloadFile = async ({
  data,
  error,
  fileName,
  extension = 'xlsx',
  fileType = excelFileType,
}: Props) => {
  try {
    if (error) {
      console.error('Error downloading the file:', error);
      return;
    }

    if (data) {
      const blob = new Blob([data], {
        type: fileType,
      });

      const url = URL.createObjectURL(blob);

      saveAs(url, `${fileName}.${extension}`);
      URL.revokeObjectURL(url);
    }
  } catch (err) {
    console.error('Error handling download:', err);
  }
};
