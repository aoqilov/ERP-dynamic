import { TTransferInnerItem, TTransferStatus } from '@/store/services/transfer/transfer.type';

type Params = Pick<
  TTransferInnerItem,
  'accepted_quantity' | 'rejected_quantity' | 'requested_quantity'
>;

export const calcTransferQuantity = (
  { accepted_quantity, rejected_quantity, requested_quantity }: Params,
  status: TTransferStatus = 'pending',
) => {
  const num_accepted = Number(accepted_quantity || 0);
  const num_rejected = Number(rejected_quantity || 0);
  const num_requested = Number(requested_quantity || 0);

  if (status === 'pending') return num_requested - (num_accepted + num_rejected);
  else if (status === 'accepted') return num_accepted;
  else if (status === 'cancelled' || status === 'rejected') return num_rejected;
  else return 0;
};
