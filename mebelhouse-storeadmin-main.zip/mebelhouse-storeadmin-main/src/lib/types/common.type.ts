import { TProductsItem } from '@/store/services/products/products.type';
import { Expand } from './custom-utility.type';
import { LangEnum } from './lang.type';

export type TId = string;
export type TToken = string;
export type TUrl = string;

export const enum UrlMethodEnum {
  POST = 'POST',
  GET = 'GET',
  PUT = 'PUT',
  DELETE = 'DELETE',
  PATCH = 'PATCH',
}

export type TBaseRequestParams<TBody = undefined> = {
  id: string;
  pagination?: boolean;
  token: TToken;
  refreshToken: TToken;
  body: Expand<TBody>;
  lang?: LangEnum;
  'Accept-Language'?: LangEnum;
  page?: number;
  page_size?: number;
  limit?: number;
  sort?: string;
  from?: string;
  to?: string;
  filter?: string;
  search?: string;
  orderBy?: string;
  order?: 'asc' | 'desc';
  category?: string;
  subcategory?: string;
  tags?: string[];
  startDate?: string;
  endDate?: string;
  name?: string;
  address?: string;
  phone?: string;
  colors?: boolean;
  status?: string;
  showroom?: number;
  showroom_id?: string;
  search_list: string;
  sub_category_id?: string;
  category_id?: string;
  created_at_from?: string;
  created_at_to?: string;
};

export type ModalStyleType = 'default' | 'singleBtn';

export type TModifiedProduct = {
  colour_name_uz: null;
  colour_name_ru: null;
  category_name_uz: null;
  category_name_ru: null;
  sub_category_name_uz: null;
  sub_category_name_ru: null;
} & Omit<TProductsItem, 'sub_category' | 'category' | 'colours'>;
