import { TBaseApiResponseData } from './base-response.type';

export type PictureItemType = TBaseApiResponseData & {
  id: string;
  file_name: string;
  path: string;
  size: number;
  mime_type: string;
};
