export type TPagination = {
  links: {
    next: number;
    previous: number;
  };
  total_pages: number;
  current_page: number;
  total_elements: number;
  page_size: number;
  from: number;
  to: number;
};
