export enum LangEnum {
  UZ = 'uz',
  RU = 'ru',
  // EN = 'en',
}
