export type TBaseApiResponseData = {
  id: string;
  key: React.Key;
  is_active: boolean;
  is_deleted: boolean;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
};

export type TBaseApiResponseElements = {
  status_code: number;
  message: string;
  total_pages: string;
  total_elements: string;
  current_page: string;
  from: number;
  to: number;
  page_size: number;
};
