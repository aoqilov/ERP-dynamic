export const BREAK_POINTS = {
  sm: 640,
  md: 768,
  lg: 1024,
  xl: 1280,
};

export const MAX_MB_PHOTOS = 2;
export const MAX_MB_FILES = 2;
export const ALLOWED_TYPE_PHOTOS = ['jpeg', 'png', 'svg', 'webp'];

export const ALLOWED_TYPE_FILES = [
  'vnd.ms-excel',
  'vnd.openxmlformats-officedocument.spreadsheetml.sheet',
];
