export const SERVER_URL: string = import.meta.env.VITE_SERVER_URL || '';
export const CLIENT_URL: string = import.meta.env.VITE_CLIENT_URL || '';
export const MEDIA_URL = `${SERVER_URL}/upload/`;
export const CDN_URL = import.meta.env.VITE_CDN_URL || '';

if (!SERVER_URL || !CLIENT_URL) {
  alert('env variable is not defined');
  console.error('env variable is not defined');
  throw new Error('env variable is not defined');
}

export const SERVER_URL_CONFIGS = new URL(SERVER_URL);
