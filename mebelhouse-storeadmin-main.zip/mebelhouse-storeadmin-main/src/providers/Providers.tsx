import AppWrapper from '@/components/AppWrapper';
import { persistor, store } from '@/store/store';
import { ConfigProvider } from 'antd';
import ru from 'antd/locale/ru_RU';
import { FC, ReactNode } from 'react';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';

type Props = {
  children: ReactNode;
};

const Providers: FC<Props> = ({ children }) => {
  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <ConfigProvider
          theme={{
            token: {
              colorPrimary: '#663423',
              colorTextBase: '#111827',
              fontFamily: 'Manrope',
            },
            components: {
              Button: {
                defaultShadow: 'none',
                primaryShadow: 'none',
              },
              Table: {
                rowSelectedBg: '#f5f5f5',
                rowSelectedHoverBg: '',
              },
            },
          }}
          locale={ru}
        >
          <AppWrapper>{children}</AppWrapper>
        </ConfigProvider>
      </PersistGate>
    </Provider>
  );
};

export default Providers;
