import enFlag from './en-flag.svg';
import ruFlag from './ru-flag.svg';
import uzFlag from './uz-flag.svg';

export const flagIcons = {
  en: enFlag,
  ru: ruFlag,
  uz: uzFlag,
};
